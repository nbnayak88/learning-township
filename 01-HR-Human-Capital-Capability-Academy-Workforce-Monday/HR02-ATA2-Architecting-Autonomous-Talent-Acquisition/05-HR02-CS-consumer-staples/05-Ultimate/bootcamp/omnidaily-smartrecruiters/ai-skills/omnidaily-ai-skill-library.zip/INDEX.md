# AI skill library for OmniDaily Consumer Goods Ltd.

18 skills in Claude skill format (folder per skill with SKILL.md). Proposed baseline; fictional enterprise.

- odg-demand-and-requisition-drafting-agent: Demand and requisition drafting agent (Agent skill)
- odg-job-content-and-criteria-drafting-assistant: Job content and criteria drafting assistant (Agent skill)
- odg-sourcing-and-matching-agent: Sourcing and matching agent (Agent skill)
- odg-candidate-screening-summary-assistant: Candidate screening summary assistant (Agent skill)
- odg-interview-scheduling-agent: Interview scheduling agent (Agent skill)
- odg-candidate-q-a-assistant: Candidate Q&A assistant (Agent skill)
- odg-interview-evidence-consistency-checker: Interview evidence consistency checker (Agent skill)
- odg-offer-drafting-and-band-check-assistant: Offer drafting and band-check assistant (Agent skill)
- odg-hire-handoff-reconciliation-agent: Hire handoff reconciliation agent (Agent skill)
- odg-onboarding-readiness-tracking-agent: Onboarding readiness tracking agent (Agent skill)
- odg-fairness-and-adverse-impact-monitoring-agent: Fairness and adverse-impact monitoring agent (Agent skill)
- odg-recruiting-insight-narrative-agent: Recruiting insight narrative agent (Agent skill)
- odg-requirement-writer: Requirement writer (Utility skill)
- odg-user-story-writer: User story writer (Utility skill)
- odg-test-script-writer: Test script writer (Utility skill)
- odg-fit-gap-classifier: Fit-gap classifier (Utility skill)
- odg-activate-deliverable-drafter: SAP Activate deliverable drafter (Utility skill)
- odg-talent-architecture-mapper: Talent architecture mapper (Utility skill)
