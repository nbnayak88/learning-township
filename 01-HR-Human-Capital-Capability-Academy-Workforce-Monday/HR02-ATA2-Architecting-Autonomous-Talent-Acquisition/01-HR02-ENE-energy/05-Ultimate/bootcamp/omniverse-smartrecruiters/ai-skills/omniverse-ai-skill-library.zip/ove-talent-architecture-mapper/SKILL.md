---
name: ove-talent-architecture-mapper
description: Use to map a designation or job description at OmniVerse Energy Ltd. to a job code, family, grade, band, skills and competencies.
---
# Talent architecture mapper

Case: OmniVerse Energy Ltd. (Energy). Sector populations include: offshore maintenance technicians; grid engineers for renewable and network projects; refinery process operators; pipeline integrity inspectors; renewables project managers; cybersecurity and OT security analysts.

## When to use
Use to map a designation or job description at OmniVerse Energy Ltd. to a job code, family, grade, band, skills and competencies.

## Steps
1. Read the designation and duties.
2. Match to the nearest job in the job classification; give code, family, function, grade, band and ISCO-08 group.
3. List required skills with levels and the competencies expected for the band.
4. Say if the job is safety or regulation critical and which evidence gate applies.
5. If there is no good match, propose a new job and list what is missing.

## Output
Mapping table with rationale and open questions.

## Guardrails
- Use only the inputs supplied; mark anything else as Not provided.
- Do not decide on hiring, pay, employment records or access.
- Do not infer protected characteristics or use proxies.
- Everything is proposed and not tenant-tested.

## Human check
A named human reviews the result against the workbook before it is used.
