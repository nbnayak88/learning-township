# AI skill library for OmniVerse Energy Ltd.

18 skills in Claude skill format (folder per skill with SKILL.md). Proposed baseline; fictional enterprise.

- ove-demand-and-requisition-drafting-agent: Demand and requisition drafting agent (Agent skill)
- ove-job-content-and-criteria-drafting-assistant: Job content and criteria drafting assistant (Agent skill)
- ove-sourcing-and-matching-agent: Sourcing and matching agent (Agent skill)
- ove-candidate-screening-summary-assistant: Candidate screening summary assistant (Agent skill)
- ove-interview-scheduling-agent: Interview scheduling agent (Agent skill)
- ove-candidate-q-a-assistant: Candidate Q&A assistant (Agent skill)
- ove-interview-evidence-consistency-checker: Interview evidence consistency checker (Agent skill)
- ove-offer-drafting-and-band-check-assistant: Offer drafting and band-check assistant (Agent skill)
- ove-hire-handoff-reconciliation-agent: Hire handoff reconciliation agent (Agent skill)
- ove-onboarding-readiness-tracking-agent: Onboarding readiness tracking agent (Agent skill)
- ove-fairness-and-adverse-impact-monitoring-agent: Fairness and adverse-impact monitoring agent (Agent skill)
- ove-recruiting-insight-narrative-agent: Recruiting insight narrative agent (Agent skill)
- ove-requirement-writer: Requirement writer (Utility skill)
- ove-user-story-writer: User story writer (Utility skill)
- ove-test-script-writer: Test script writer (Utility skill)
- ove-fit-gap-classifier: Fit-gap classifier (Utility skill)
- ove-activate-deliverable-drafter: SAP Activate deliverable drafter (Utility skill)
- ove-talent-architecture-mapper: Talent architecture mapper (Utility skill)
