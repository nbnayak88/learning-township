# Business Architecture (Phase B)

> **In brief.** Capabilities, the Hire to Day One value stream, processes and the rules that govern them.

## 10.1 Capability map
Twenty-nine L2 capabilities in seven L1 domains, each with a target maturity and the components that support it.

{{csv:capabilities}}

## 10.2 Value stream
Nine stages, four gates. Partners appear as touchpoints inside stages; they never change the gate rules.

{{img:flow.png|To-be value stream with partner touchpoints and gates}}

{{csv:value_stream}}

## 10.3 Process catalogue
{{csv:processes}}

## 10.4 Business rules
{{csv:business_rules}}

## 10.5 Organisation and roles
Process owner: Head of Global Talent Acquisition. Regional TA leads own local variants. HSE and Occupational Health own clearance rules. Legal and Privacy own consent, retention and AI rules. The Enterprise Architecture Office owns the partner capability interfaces.

## 10.6 RACI
{{csv:raci}}

## 10.7 BIZBOK view
The BIZBOK ten-element example for this programme is in [Chapter 9](09-business-architecture-guild.md).
