# Using This as a Reusable Template

> **In brief.** How to reuse this document for another solution or country in four steps, what stays fixed and what to change.

This repository is a **template**. Use it for any solution, any organisation, any country. The twelve-stream structure, the TOGAF coverage and the framework chapters stay the same. You change the subject, the registers and the local values.

## 18.1 Start in four steps
1. **Create your copy.** On GitHub choose *Use this template*, name the repository, keep it private if it holds real data.
2. **Run the initialiser** (once, in the browser through a Codespace, or on any machine): `python tools/init_template.py --programme "Your Programme" --subject "Your Solution Name" --org "Your Organisation"`. It writes `config.json`, resets the project registers to blank, and replaces chapters 4 to 8 and 10 to 16 with guided starters.
3. **Fill the registers** in `data/` (edit CSV files in the GitHub editor) and the chapters in `docs/`.
4. **Commit.** The site rebuilds and publishes itself.

## 18.2 What is fixed and what you change
| Fixed (reference) | You change (project) |
|---|---|
| Chapters 1 to 3, 9 and 17 to 19 (TOGAF, 12 streams, 9P4V, BA Guild, coverage, template, appendices) | Chapters 0, 4 to 8 and 10 to 16 text |
| `streams`, `togaf_intro`, `togaf_concepts`, `togaf_glossary`, `togaf_acronyms`, `togaf_references`, `bizbok`, `stream_matrix`, `stream_counts`, `stream_lens`, `crosswalk` registers | The 23 project registers: requirements, stakeholders, principles, and so on |
| Build, check, deck and workbook code | `config.json`, `tools/blocklist.txt` |

## 18.3 Configuration
`config.json` holds the values that appear across the site: programme name, subject (the solution), organisation, country or region, version and repository. They are inserted wherever a cfg macro (double curly braces around `cfg:subject`) appears in chapters, and on the home page and title slide.

## 18.4 Adding a stream, register or chapter
- **A register:** add `data/yourname.csv` (header row first) and one line in `TITLES` in `tools/build.py`. It appears in the Workbook automatically.
- **A chapter:** add `docs/NN-name.md` starting with `# Title`. It appears in the sidebar and home list.
- **A stream:** add a row to `data/streams.csv` and a block in `tools/togaf_data.py` if you want it in the matrix.
- **Macros** (wrap in double curly braces): `csv:register|cols=A,B|filter=Col:Value` inserts a table; `img:file.png|Caption` an image; `cfg:subject` a config value.

## 18.5 Keeping it generic
Put client, regulator, vendor or personal names in `tools/blocklist.txt`. The build fails if any appear in `docs/` or `data/`. Use `[bracketed placeholders]` for local values.

## 18.6 Re-using for another solution
Fork or copy, run the initialiser with a new subject, and keep chapters 1 to 3, 9 and 17 to 19. Everything else is yours. The initialiser never touches chapters 1 to 3, 9 and 17 to 19.

## 18.7 Definition of done for a new instance
- Config set; blank registers filled or removed.
- Every requirement has acceptance criteria and a trace.
- Each of the twelve streams has an owner and at least its eight lenses reviewed.
- The check passes; the site shows no empty tables.
