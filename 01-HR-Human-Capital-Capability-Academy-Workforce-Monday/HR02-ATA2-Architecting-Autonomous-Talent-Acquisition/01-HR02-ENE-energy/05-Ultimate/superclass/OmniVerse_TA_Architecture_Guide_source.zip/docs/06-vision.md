# Architecture Vision (Phase A)

> **In brief.** One hiring platform for OmniVerse Energy in 14 countries, with SmartRecruiters at the centre and partners swappable behind clean interfaces. Humans decide; AI advises; candidate data is held in trust.

## 6.1 Problem
OmniVerse Energy hires engineers, technicians, operators and graduates across about 14 countries. Three legacy applicant tracking tools and spreadsheets give each country a different process, uneven candidate experience, slow checks for safety-critical roles and no single view of the funnel. Assessment, interview and verification tools are bought locally, so data, contracts and AI use are not governed.

## 6.2 Vision
> Hire for safety and skill, fast and fairly, on one platform that welcomes the best partners today and lets OmniVerse replace any of them tomorrow.

## 6.3 Objectives
| Objective | Measure (illustrative) |
|---|---|
| One process, local variants by configuration | Parallel ATS tools retired after final wave |
| Faster hiring | Median time to hire down [30]% |
| Safe hiring | Checks and clearance complete before day one for 100% of safety-critical roles |
| Fair and explainable AI | Every AI use registered, tested and advisory |
| Vendor freedom | Exit plan tested yearly for every partner category |
| Clean hand-off | Hire data in the HR core with no re-keying |

## 6.4 Scope
In scope: plan, attract, source, apply, assess, interview, select, verify, offer, sign, pre-board, hand-off and day-one feedback, plus the partner ecosystem and analytics. Out of scope: payroll calculation, performance, learning, and the HR core configuration beyond the hire hand-off.

{{img:context.png|System context: people, hub, partners and enterprise systems}}

## 6.5 Principles
{{csv:principles}}

## 6.6 Stakeholders
{{csv:stakeholders}}

## 6.7 Key decisions at vision stage
SmartRecruiters is the hiring hub; the HR core remains the employee system of record; all partners attach through an integration hub; delivery follows SAP Activate with a pilot first. See the decision register in [Chapter 14](14-strategy-analysis.md).
