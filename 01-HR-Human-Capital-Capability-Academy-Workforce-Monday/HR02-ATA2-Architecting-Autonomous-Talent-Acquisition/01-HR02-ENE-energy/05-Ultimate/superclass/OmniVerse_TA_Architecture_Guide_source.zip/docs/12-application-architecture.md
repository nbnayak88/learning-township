# Application Architecture (Phase C)

> **In brief.** Forty-three building blocks in eleven layers. Each partner category is reached through a capability interface and an adapter, so any vendor can be replaced.

## 12.1 Architecture at a glance
{{img:arch.png|Layered application architecture: experience, hiring hub, partners, integration, data and security}}

## 12.2 Vendor-agnostic method
Each component has an **ABB** (what it must do) and **SBB options** (examples only). A component lists responsibilities, not product features. Choosing an SBB is a selection decision recorded in the decision register.

## 12.3 Components
{{csv:components}}

## 12.4 Interfaces
{{csv:interfaces}}

## 12.5 Application to capability
Every component supports at least one capability in [Chapter 10](10-business-architecture.md) and realises at least one requirement in [Chapter 8](08-requirements.md).

## 12.6 Hub choice and roadmap note
SmartRecruiters is the hiring hub because it connects to many partners and works with SuccessFactors and other HCM systems. SAP has stated an intent to replace the SuccessFactors Recruiting module over time; the architecture keeps the hub behind the capability interfaces so this direction can be followed without redesign.
