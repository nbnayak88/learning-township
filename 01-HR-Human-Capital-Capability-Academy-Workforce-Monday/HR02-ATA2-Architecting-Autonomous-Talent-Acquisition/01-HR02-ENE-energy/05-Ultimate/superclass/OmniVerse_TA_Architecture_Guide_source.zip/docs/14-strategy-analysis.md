# Opportunities and Solutions (Phase E)

> **In brief.** The decisions, gaps, risks and measures that shape the roadmap.

## 14.1 Architecture decisions
{{csv:adr}}

## 14.2 Gap analysis
{{csv:gap_analysis}}

## 14.3 Risks
{{csv:risks}}

## 14.4 Measures
{{csv:kpis}}

## 14.5 Options for the partner model
| Option | Strength | Weakness | Choice |
|---|---|---|---|
| One suite for everything | Fewer contracts | Lock-in, weaker local fit | No |
| Best partner per category, direct to hub | Fast | Many unmanaged integrations | No |
| Best partner per category behind capability interfaces | Replaceable, governed | Adapter effort | Yes |
