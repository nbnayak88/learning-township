# Responsible AI, Privacy and Compliance (Requirements Management)

> **In brief.** AI advises and humans decide. Consent, minimum data, regional storage and tested retention apply to every partner.

## 22.1 AI use in hiring
AI appears in chat assistants, matching, screening support, interview summaries and partner tools. Several jurisdictions treat hiring AI as high risk. The design therefore keeps AI advisory, logs it, tests it and allows regional switches.

## 22.2 Controls
{{csv:ai_controls}}

## 22.3 Candidate rights
Notice of AI use, a route to a human, explanation on request, access, correction and deletion, and accessible alternatives for assessments and video interviews.

## 22.4 Regional data and retention (illustrative)
| Region | Storage | Retention default | Notes |
|---|---|---|---|
| Europe | EU region | [6 to 12] months after close, longer only with consent | Works-council and AI-rule checks |
| Middle East | In-country or approved region | [12] months | Local residency rules apply |
| Asia Pacific | Regional | [12] months | Per-country privacy law |
| Americas | Regional | [12 to 24] months | State and provincial rules |
| Africa | Approved region | [12] months | Per-country law |

Values are placeholders; Legal and Privacy confirm each country.

## 22.5 Check results
Outcome and date only are kept in the hub. Detail stays with the provider. Adverse-action steps follow local law and always involve a human.

## 22.6 Partner privacy duties
Data-processing agreement, sub-processor list, region of processing, deletion on request and on exit, breach notice period, audit right.

## 22.7 Evidence
Consent log, AI register, bias test reports, retention job logs and exit test results are produced from the registers and the audit log for auditors.
