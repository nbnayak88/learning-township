# Paperless Architecture Initiative (Preliminary Phase)

> **In brief.** How this guide is kept: Markdown and CSV in one repository, built into four views, checked on every change. No uploads or downloads in normal use.

## 4.1 Principle
Docs as code: **Markdown chapters** and **CSV registers** are the only source of truth. One build produces the **Document**, **Deck**, **Workbook** and **Handbook** views. This keeps the architecture reviewable, versioned and free of copies drifting apart.

{{img:pipeline.png|Build pipeline: Markdown and CSV to four online views}}

## 4.2 Working rules for this programme
- A change to a requirement, component, interface or partner is made in the register once; every chapter that shows it updates on the next build.
- A partner is added by adding a row to the partner registers, a capability-interface contract and an exit plan, never by editing a diagram first.
- Each pull request runs the checker for broken links, missing requirement fields and banned terms before it can publish.
- No personal data, real client names or secrets appear in the repository.

## 4.3 Roles
| Role | Duty |
|---|---|
| Enterprise Architecture Office | Owns the repository, standards and design authority |
| Domain owners | Keep their chapters and registers current |
| Reviewers | Business owner, security and privacy sign off changes that touch them |
| Delivery lead | Links work packages and Activate gates to the registers |

## 4.4 Preliminary phase outputs
Architecture principles ([Chapter 6](06-vision.md)), the governance model ([Chapter 16](16-governance.md)), the tailored method (this chapter and Chapter 23) and the repository itself.
