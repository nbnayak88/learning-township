# The Twelve Architecture Streams

> **In brief.** Twelve architecture streams give twelve lenses on one solution. Each stream has principles, building blocks, views, deliverables, standards, gates, risks and measures.

TOGAF names four architecture domains. Real programmes need more. This template organises all architecture work into **twelve streams**, in a fixed order, so every concept, register and chapter can be placed in one of them. A stream is a lane of work with an owner, artefacts, standards and gates. Streams overlap on purpose; the stream matrix in the Workbook shows each TOGAF concept's primary stream (P) and supporting streams (S).

{{csv:streams|cols=ID,Stream,Purpose,Key artefacts,TOGAF ADM phases,Typical owner}}

## The ADM cycle across the twelve streams
**P** means the stream leads or contributes substantially in that phase; **S** means the stream supports every phase. The chapters column shows where the phase is worked in this document.
{{csv:adm_streams}}

## How to read a stream
Each stream below is described with the same eight lenses taken from TOGAF: principle, building block, view and viewpoint, deliverable, standard, governance gate, typical risk and measure. Use them as a checklist when you add content for a stream.

## 2.1 Enterprise
{{csv:stream_lens|filter=Stream:Enterprise|cols=Lens (TOGAF concept),How it applies}}
Home of vision, principles, roadmap, repository and the architecture practice. Chapters 1, 6, 15 and 16.

## 2.2 Business
{{csv:stream_lens|filter=Stream:Business|cols=Lens (TOGAF concept),How it applies}}
Capabilities, value streams, processes, rules and requirements. Chapters 7, 8, 10 and 14.

## 2.3 Data
{{csv:stream_lens|filter=Stream:Data|cols=Lens (TOGAF concept),How it applies}}
Models, dictionary, quality and the eleven DMBOK areas. Chapter 11.

## 2.4 Application
{{csv:stream_lens|filter=Stream:Application|cols=Lens (TOGAF concept),How it applies}}
Components, services, ABB and SBB. Chapter 12.

## 2.5 Technology
{{csv:stream_lens|filter=Stream:Technology|cols=Lens (TOGAF concept),How it applies}}
Platforms, standards and technology services. Chapter 13.

## 2.6 AI
{{csv:stream_lens|filter=Stream:AI|cols=Lens (TOGAF concept),How it applies}}
Use cases such as document classification, duplicate detection, image analysis or summarisation, each with a human in the loop. Start every AI use case with the data readiness check from the Data stream and a security and privacy review.

## 2.7 Security
{{csv:stream_lens|filter=Stream:Security|cols=Lens (TOGAF concept),How it applies}}
Classification, identity, access, privacy, audit trail and assurance. Chapter 13 and the risks register.

## 2.8 UI/UX
{{csv:stream_lens|filter=Stream:UI/UX|cols=Lens (TOGAF concept),How it applies}}
Personas, journeys, interaction patterns, accessibility and the design system. Mobile capture and public self-service screens are the main journeys here.

## 2.9 Infrastructure
{{csv:stream_lens|filter=Stream:Infrastructure|cols=Lens (TOGAF concept),How it applies}}
Hosting, networks, environments, capacity, resilience and operations.

## 2.10 Integration
{{csv:stream_lens|filter=Stream:Integration|cols=Lens (TOGAF concept),How it applies}}
Interface catalogue, API and event standards. Chapter 12.

## 2.11 Domain
{{csv:stream_lens|filter=Stream:Domain|cols=Lens (TOGAF concept),How it applies}}
Domain glossary, rules and reference model for the subject area, for example network or asset operations.

## 2.12 Industry
{{csv:stream_lens|filter=Stream:Industry|cols=Lens (TOGAF concept),How it applies}}
Sector reference models, regulation and country configuration, so the same architecture works in any country.

## 2.13 Stream ownership
Each stream has one accountable owner and a named steward; see the RACI register. Streams meet in the architecture board at each quality gate ([Chapter 16](16-governance.md)).
