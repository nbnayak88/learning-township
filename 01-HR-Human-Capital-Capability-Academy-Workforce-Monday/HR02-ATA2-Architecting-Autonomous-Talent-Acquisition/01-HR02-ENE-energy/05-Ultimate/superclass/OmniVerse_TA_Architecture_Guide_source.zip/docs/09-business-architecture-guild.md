# Business Architecture Guild, BIZBOK® (Phase B)

> **In brief.** The Business Architecture Guild's BIZBOK Guide applied: ten domains, nine blueprints, the practice guide, alignment with IT architecture, and a worked ten-element example.

The **Business Architecture Guild** publishes the *BIZBOK® Guide* (A Guide to the Business Architecture Body of Knowledge®), the body of knowledge for business architecture. This chapter covers **every part, section and appendix** of the guide's contents and shows where each is applied here. The contents page supplied by the template owner is headed "BA GUILD 15.0" and lists the BIZBOK Guide v14.0 structure; match on titles if your edition numbers differently. All descriptions are written in our own words.

## 9.1 What business architecture is
Business architecture gives a holistic, multi-dimensional view of the business: its **capabilities**, its **end-to-end value delivery**, its **information** and its **organisation**, and how those relate to strategies, products, policies, initiatives and stakeholders. Its value is a shared, abstract picture of the enterprise and its ecosystem that turns strategy into actionable initiatives and supports transformation, complexity, risk and decision making. The one-line pitch: *it enables effective, streamlined strategy execution.*

Two points matter for this template:
- It describes a **business ecosystem**, so customers, partners and outsourced capabilities are in scope, not only internal units.
- It is **not** the operating model. The operating model shows how people, process and technology run the business; business architecture is value-driven, capability-based and ecosystem-wide, and guides operating-model investment.

**Value proposition in one line.** Business architecture gives leaders a shared, business-language picture so strategy, investment and change line up, and so competing or duplicate solutions are seen early. It turns "what do we do, for whom, and what must change" into views that business and IT can both use.

## 9.2 How BIZBOK fits with the other frameworks
| Framework | Question it answers | Used here for |
|---|---|---|
| **BIZBOK (BA Guild)** | What does the business do, create and need? | Blueprints, practice, scenarios, industry models |
| TOGAF | How do we develop and govern architecture end to end? | Method, domains, content, governance |
| BABOK | How do we elicit and manage requirements? | Requirements, analysis, traceability |
| DAMA-DMBOK | How do we manage data? | Data architecture and quality |

TOGAF Phase A and B are where BIZBOK blueprints do most of their work; see section 9.9 for the alignment.

## 9.3 The ten domains
Four **core** domains are relatively stable (a century-old insurer still has claims, policy and customer capabilities). Six **extended** domains change more often.
{{csv:bizbok_domains}}

## 9.4 The framework: blueprints, scenarios, knowledgebase
The guide's framework has three components, none of them prescriptive:
- **Blueprints** are single views of the business built from the shared domains. They give transparency, for example to expose competing solutions built for the same customers.
- **Scenarios** apply the blueprints to a specific business question and end in a roadmap (section 9.8).
- **Knowledgebase** stores the content once, organised in the organisation's own terms. Here it is the Git repository: registers with stable IDs.

## 9.5 Six core principles
{{csv:bizbok_principles}}

## 9.6 The nine blueprints (Part 2)
Foundational views are 2.2 to 2.5; extended views are 2.1, 2.6 to 2.9. Guild advice on where to start: **value mapping or capability mapping** first (value maps are often quicker and give a frame for capabilities), organisation mapping first in complex structures to set scope, and information mapping after the capability map. Clarify goals, scope and governance before mapping.

| Blueprint | Register or place in this template |
|---|---|
| 2.1 Business strategy mapping | Objectives, vision, requirement traces, decision records |
| 2.2 Capability mapping | Capabilities register |
| 2.3 Organisation mapping | Stakeholders, RACI |
| 2.4 Value mapping | Value stream register and diagram |
| 2.5 Information mapping | Data entities, dictionary |
| 2.6 Initiative mapping | Work packages, gap analysis |
| 2.7 Product mapping | Business services in capabilities; add a products register if product-led |
| 2.8 Stakeholder mapping | Stakeholders register |
| 2.9 Policy mapping | Business rules, principles, regulatory obligations |

### Strategy mapping terms (2.1)
{{csv:bizbok_strategy_terms}}

Benefits of mapping strategy: a common language for goals and actions, visible links from strategy to capabilities and initiatives, earlier detection of conflicting objectives, and a defensible basis for prioritisation.

### Strategy mapping in more detail (2.1)
Strategy mapping connects goals, objectives and courses of action to the rest of the architecture. Its principles include that a strategy belongs to a defined *community of interest* (the stakeholders whose value it affects) and that it responds to the external environment. Benefits are organisational alignment, fidelity of objectives as they cascade, and early detection of strategic gaps. Frameworks the guide names, and how each is used here:

| Framework | Use |
|---|---|
| Ansoff product and market grid | Choose growth direction when defining objectives |
| SWOT | Surface internal and external factors in the vision |
| Five Forces | Assess competition, buyers and suppliers; risks |
| Kaplan-Norton strategy map | Link objectives to customers, internal processes and enablers; KPI register |
| Business Motivation Model | Structure ends, means, influencers and directives; principles and rules |
| Hoshin Kanri | Cascade objectives into aligned actions; work packages |

### Worked example: the ten elements at three levels
Each element is described at Level 1 (broad), Level 2 (more detail) and Level 3 (working detail). The table shows a fictional energy company hiring at scale, matching this guide's reference solution. Replace it with your own sector content. The tenth element, **metrics**, completes the model (four core, six extended).
{{csv:bizbok_sector_example}}

Implementation principles: start with the elements the first scenario needs; keep Level 1 stable and let Levels 2 and 3 grow; name every item once and reuse it across views; link elements to each other (a metric to a capability, a policy to a value stage) so impact analysis works.

## 9.7 The practice guide (Part 3)
{{csv:bizbok|filter=Part:Part 3|cols=Section,Topic,What it covers,How this template applies it,Primary stream}}

### Section-by-section detail (Parts 3 and 6)
Key ideas, typical artefact and the question each section answers.
{{csv:bizbok_practice}}

## 9.8 Scenarios, case studies and infrastructure (Parts 4, 5, 7)
The guide's scenarios each end with a roadmap. This template supports them as follows:
{{csv:bizbok_scenarios}}
Part 5 covers the **knowledgebase** (5.1) and **tooling options** (5.2); here, the Git repository and the build pipeline (Chapter 4). Part 7 collects **case studies**; the reference solution is one worked example and your instance should add its own.
{{csv:bizbok|filter=Part:Part 5|cols=Section,Topic,What it covers,How this template applies it}}

## 9.9 BA and IT architecture alignment (Part 6)
{{csv:bizbok|filter=Part:Part 6|cols=Section,Topic,What it covers,How this template applies it,Primary stream}}

| BIZBOK view | TOGAF ADM phase | Template artefact |
|---|---|---|
| Strategy, capability, value, organisation | A, B | Vision, capabilities, value stream |
| Information | C (Data) | Data entities, dictionary |
| Capability to application mapping | C (Application) | Components register |
| Initiatives | E, F | Work packages, roadmap |
| Governance of deployment | G, H | Gates and benefits review |

## 9.10 The strategy execution framework (Part 1, 3.11, B.1)
A five-step path, repeated as business issues arise: **1 Establish business strategy, 2 Assess business impact, 3 Architect business solution, 4 Establish initiative plans, 5 Deploy solution.** Each step has business architecture actions; the table maps each to a template artefact and TOGAF phase.
{{csv:bizbok_strategy_execution}}

## 9.11 Industry reference models (Part 8)
Reference models give a baseline of capabilities, value streams, information and stakeholders for a sector: financial services, manufacturing, healthcare, international development, insurance, a cross-industry common model, transportation, government and telecommunications. Choose one through the **Industry** stream, copy its capabilities into your capability register, and adapt. This template does not reproduce the guild's models.
{{csv:bizbok|filter=Part:Part 8|cols=Section,Topic,What it covers,Coverage}}

## 9.12 Appendices
{{csv:bizbok|filter=Part:Appendix|cols=Section,Topic,What it covers,How this template applies it,Coverage}}

## 9.13 Full coverage table
Every part, section and appendix with its stream and coverage status (**Covered**, **Partly covered**, **Pointer** where you select content for your sector, or **Reference only**).
{{csv:bizbok}}

## 9.14 Gaps to fill in your instance
- A **products register** for product mapping (2.7).
- A **maturity register** for the BA maturity model (3.9, B.3), with your own level definitions.
- **Study questions** (Appendix C): the guide now points to its online study guide; add your own review questions to the deck.
- Your **industry reference model** (Part 8).
- Real **case studies** (Part 7) and **scenarios** (Part 4) from your own programme.
