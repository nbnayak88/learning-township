# Quality Standards (Preliminary Phase)

> **In brief.** The checks every requirement, diagram and decision must pass before it is accepted.

## 5.1 Requirement quality (BABOK)
A requirement is accepted only when it is **necessary, unambiguous, testable, feasible, traceable and prioritised**. Each carries an ID, a level, a MoSCoW rank, acceptance criteria, the component that realises it, the ADM phase and the source.

## 5.2 Architecture quality
| Check | Standard |
|---|---|
| Traceability | Every requirement maps to a component; every component to a capability |
| Consistency | One name per thing; the canonical model and glossary are the reference |
| Vendor neutrality | Each partner category is reached through a capability interface; no component description depends on one brand |
| Security and privacy | Classification, region and retention set for every data entity |
| Testability | Each interface has a contract test; each AI use has a bias and accuracy check |
| Diagram standard | Title, legend, one idea per diagram; text readable at slide size |

## 5.3 Data quality rules
The data-quality register defines completeness, uniqueness, validity, timeliness and consistency rules, each with a threshold, an action on failure and an owner.

{{csv:dq_rules}}

## 5.4 Review gates
Each change passes author check, peer review, and a domain sign-off. Decisions that change a pattern, a partner category or a data flow need a decision record ([Appendix D](19-appendices.md)).
