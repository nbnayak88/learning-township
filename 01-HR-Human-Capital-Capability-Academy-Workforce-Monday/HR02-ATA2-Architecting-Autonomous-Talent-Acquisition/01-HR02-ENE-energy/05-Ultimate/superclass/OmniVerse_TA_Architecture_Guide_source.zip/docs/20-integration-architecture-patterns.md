# Integration Architecture and Patterns (Phases C and D)

> **In brief.** Nine reusable patterns cover every partner category. A new partner reuses a pattern; it does not invent an integration.

## 20.1 Integration principles
Hub and spokes; events by default; one canonical model; scoped credentials; idempotent calls; every failure visible and recoverable ([Chapter 6](06-vision.md)).

## 20.2 Pattern catalogue
{{csv:integration_patterns}}

## 20.3 Order and result (IP-2)
Used by assessment, AI interview, background check, identity and clearance partners.

{{img:patterns.png|Pattern IP-2: order and result between hub, integration hub and partner}}

## 20.4 Interface catalogue
{{csv:interfaces}}

## 20.5 Canonical model and mapping
Each partner adapter maps its codes and statuses to the canonical model: result status (ordered, in progress, complete, failed, expired), band (for example 1 to 5), report link and consent reference. Mappings are versioned tables, so replacing a partner changes the adapter, not the hub or the data platform.

## 20.6 Reliability and security
| Concern | Control |
|---|---|
| Delivery | Retry with back-off, dead-letter queue, daily reconciliation |
| Duplicates | Idempotent order ID per candidate, stage and partner |
| Authentication | OAuth 2.0 client per partner, least scope, vault, rotation |
| Webhooks | Signed, replay-protected, allow-listed source |
| Monitoring | Latency, error rate and volume per partner; alert to the partner owner |
| Change | Contract tests per release; partner notice of breaking change |
