# SAP Activate Case Study: OmniVerse Energy (Phases E to H)

> **In brief.** A 21-day foundation sprint delivers the pilot slice on SAP Activate. Partner categories follow in regional waves using the same cadence.

## 23.1 What this case study shows and does not show
The sprint covers the **pilot slice**: one country, one role family, core hiring from requisition to offer, single sign-on, the HR core hire hand-off, job boards and e-signature. It does **not** claim that a 14-country rollout with all 28 partner categories completes in 21 days. Waves 2 to 4 add partners and regions using the same phases and gates.

{{img:activate.png|21-day foundation sprint mapped to SAP Activate phases and gates}}

## 23.2 Phase map
{{csv:activate_map}}

## 23.3 Fit-to-standard
Standard hub capability is used first. Each gap is resolved in this order: configuration, marketplace connector, integration-hub adapter, extension. Anything outside standard needs a decision record.

## 23.4 Day-by-day plan
{{csv:activate_plan}}

## 23.5 Quality gates
| Gate | After | Test |
|---|---|---|
| 1 | Explore starts | Scope, partners for wave, principles agreed |
| 2 | Explore | Fit-to-standard signed; integration design approved |
| 3 | Realize | End-to-end test and AI controls passed |
| 4 | Deploy | Cutover complete; hypercare and support accepted |

## 23.6 Waves after the sprint
Wave 2 adds assessment, interviewing, checks, clearance and contract partners. Wave 3 adds analytics, planning and surveys. Wave 4 adds mobility, DEI, engagement and offboarding. Each wave reuses the patterns in [Chapter 20](20-integration-architecture-patterns.md) and the scorecard in [Chapter 21](21-partner-ecosystem-vendor-agnostic.md).

## 23.7 Run
Release management, partner reviews, annual exit tests, adoption measures and the AI and privacy review cycle form the steady-state operating rhythm ([Chapter 16](16-governance.md)).
