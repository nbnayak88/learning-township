# Business Analysis Approach (Requirements Management)

> **In brief.** How requirements are found, analysed, agreed and traced, using BABOK practice.

## 7.1 Approach
| Step | What happens | Output |
|---|---|---|
| Plan | Agree stakeholders, techniques, cadence | Analysis plan |
| Elicit | Workshops per hiring stage, regional TA sessions, interviewer and candidate research, legal and works-council input | Needs, pain points |
| Analyse | Fit-to-standard against the hub; gap, rule and data analysis | Requirements, gaps |
| Specify | Write with acceptance criteria; link to components | Requirement register |
| Validate | Walk through with owners; prototype in the sandbox | Signed baseline |
| Manage | Change control, impact analysis, traceability | Updated register |

## 7.2 Techniques used
Process mapping on the value stream, capability mapping, interviews, workshops, document analysis, data profiling of legacy candidate records, prototyping in the sandbox, MoSCoW prioritisation and a stakeholder map.

## 7.3 Value stream as the spine
{{img:flow.png|To-be value stream: Hire to Day One with partner touchpoints and gates}}

{{csv:value_stream}}

## 7.4 Checklist
{{csv:ba_checklist}}
