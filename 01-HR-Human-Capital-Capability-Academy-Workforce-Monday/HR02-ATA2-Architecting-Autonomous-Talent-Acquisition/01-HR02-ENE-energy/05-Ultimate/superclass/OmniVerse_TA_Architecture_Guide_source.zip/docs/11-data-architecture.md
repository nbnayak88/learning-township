# Data Architecture (Phase C)

> **In brief.** A canonical hiring model, named owners, summary-only sensitive data and event streams to the data platform.

## 11.1 Principles applied
Candidate data held in trust; a canonical model that partners map to; summary, not raw sensitive detail; every entity has an owner and a steward ([Chapter 6](06-vision.md)).

## 11.2 Conceptual model
{{img:datamodel.png|Canonical hiring data model: entities and relationships}}

## 11.3 Entities
{{csv:data_entities}}

## 11.4 Data dictionary
{{csv:data_dictionary}}

## 11.5 Data quality
{{csv:dq_rules}}

## 11.6 Systems of record and flow
| Data | System of record | Flows to |
|---|---|---|
| Position, org, cost centre | HR core | Hiring hub (in) |
| Requisition, candidate, application, offer | Hiring hub | Data platform, HR core on hire |
| Assessment and interview result | Partner (detail); hub (status, band, link) | Data platform (summary) |
| Check and clearance | Provider (detail); hub (outcome and date only) | Data platform (outcome) |
| Employee record | HR core | Payroll, IT provisioning |

## 11.7 Data management (DMBOK)
Governance, metadata, quality, privacy, security, integration and analytics are covered by the owners and rules above. Retention and residency are in [Chapter 22](22-responsible-ai-privacy-compliance.md).
