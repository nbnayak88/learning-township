# Partner Ecosystem and Vendor-Agnostic Selection (Phases B to E)

> **In brief.** All 28 marketplace categories mapped to a vendor-neutral capability, an integration pattern, components and a wave. Names are examples only.

## 21.1 Why vendor-agnostic
Hiring tools change fast. OmniVerse defines what each category must do, how it connects and what data it exchanges, then chooses vendors against that definition. A different vendor can take over a category without touching the rest of the architecture.

{{img:ecosystem.png|28 marketplace categories behind capability interfaces}}

## 21.2 The 28 categories
{{csv:partner_categories}}

## 21.3 Partner types
{{csv:partner_types}}

## 21.4 Selection scorecard
Score each candidate vendor from 1 to 5 per criterion and multiply by the weight. Ask for the evidence shown.

{{csv:partner_selection}}

## 21.5 Multi-vendor by design
Assessment, AI interview, job boards and checks are multi-vendor: one global primary plus regional specialists, selected by role family and country. The capability interface and canonical model make this possible without extra hub configuration.

## 21.6 Exit plan per category
| Element | Content |
|---|---|
| Data return | Export of orders, results and reports in an agreed format within [30] days |
| Replacement | Pre-qualified alternative named per category |
| Adapter | Replacement requires a new adapter and mapping only |
| Test | Exit test once a year in the sandbox |
| Contract | Data-exit, audit and sub-processor clauses |

## 21.7 Disclaimer
Partner names in the register are illustrative. OmniVerse runs its own selection. Marketplace listing, certification status and regional availability must be confirmed with the vendor and SmartRecruiters at selection time.
