# Requirements Specification (Requirements Management)

> **In brief.** Business, stakeholder, functional, non-functional and transition requirements, each testable and traced to a component.

## 8.1 How to read the register
IDs: **BR** business, **SR** stakeholder, **FR** functional, **NF** non-functional, **TR** transition. Priority uses MoSCoW. Status is Draft until baselined.

## 8.2 Business and stakeholder requirements
{{csv:requirements|filter=Level:Business}}

{{csv:requirements|filter=Level:Stakeholder}}

## 8.3 Functional requirements
{{csv:requirements|filter=BABOK class:Functional}}

## 8.4 Non-functional requirements
{{csv:requirements|filter=BABOK class:Non-functional}}

## 8.5 Transition requirements
{{csv:requirements|filter=Level:Transition}}

## 8.6 Business rules
{{csv:business_rules}}
