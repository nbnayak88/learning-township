# Migration Planning (Phase F)

> **In brief.** Four transition architectures, delivered pilot first and then region by region.

## 15.1 Transition architectures
| TA | Name | Outcome |
|---|---|---|
| TA0 | Baseline | Requirements, canonical model, governance in place |
| TA1 | Core hiring | Requisition to offer live in the pilot country with job boards and HR core hand-off |
| TA2 | Select and comply | Assessment, interview, checks, clearance, e-signature and AI controls live; regional waves |
| TA3 | Intelligence and scale | Analytics, planning, mobility, referral, DEI insight and run operations |

## 15.2 Work packages
{{csv:work_packages}}

## 15.3 Waves
Wave 1 is the pilot (one country, one role family, core hiring). Waves 2 to 4 add partner categories and regions using the same cadence. Partner onboarding in each wave follows the scorecard in [Chapter 21](21-partner-ecosystem-vendor-agnostic.md).

## 15.4 Cutover and data
Legacy candidate data is migrated by retention rule: open requisitions and active candidates move; closed records are archived or deleted by policy. Dress rehearsal precedes each cutover.

## 15.5 Dependencies
{{img:activate.png|SAP Activate foundation sprint, then regional waves}}
