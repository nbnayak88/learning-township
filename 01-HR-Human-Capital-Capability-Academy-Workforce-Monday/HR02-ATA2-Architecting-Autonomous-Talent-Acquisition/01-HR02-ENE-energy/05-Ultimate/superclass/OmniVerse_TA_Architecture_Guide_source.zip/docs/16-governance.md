# Governance and Change (Phases G and H)

> **In brief.** Who approves what, how partners are managed, and how change is controlled.

## 16.1 Governance bodies
| Body | Decides | Cadence |
|---|---|---|
| Steering group | Scope, waves, budget, partner list | Monthly |
| Architecture review board | Patterns, standards, decision records, exceptions | Fortnightly |
| AI and privacy board | AI register, tests, consent, residency | Monthly |
| Partner council | Scorecard, SLAs, exit tests, renewals | Quarterly |

## 16.2 Compliance reviews
Each work package passes an architecture compliance review before go-live: requirements traced, interfaces tested, data classified, AI use registered, exit plan present.

## 16.3 Change management (Phase H)
A change is classified as standard (new partner in an existing category, configuration), significant (new pattern, new category, new region) or major (hub change). Significant and major changes need a decision record and board approval.

## 16.4 Release rhythm
The hub vendor ships updates on its cycle; OmniVerse tests each release in the sandbox before production. Partners must give notice of breaking API changes.

## 16.5 Partner lifecycle
Select, contract, onboard, monitor, review, renew or exit. Every partner has a data-exit clause, an annual exit test and a named owner.
