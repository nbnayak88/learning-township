# TOGAF Coverage Map

> **In brief.** Proof of completeness: every TOGAF introduction concept, term, glossary entry, acronym and reference is mapped to a stream and to a place in this template.

This chapter proves coverage. It lists every core concept (TOGAF chapter 3), every defined term (chapter 4) and the three appendices (A referenced documents, B supplementary definitions, C acronyms), says where it is covered and which artefact carries it, and places it in the twelve streams.

> **Numbering note.** Numbers follow the list supplied for this template: 18 core-concept topics (3.1 to 3.18) and 89 terms (4.1 to 4.89), including the term *EA Landscape*. Sub-sections (for example 3.5.1) are listed as extra rows. Some editions of the standard number items differently or also have a separate Architecture Repository topic; match on the title if numbers differ.

## 17.1 Coverage at a glance
{{csv:stream_counts}}
*Primary* means the stream owns the concept. *Supporting* means the stream applies or is affected by it. The TOGAF introduction is enterprise-level by nature, so the Enterprise stream owns most generic concepts; streams such as AI, Security and UI/UX appear mainly as supporting streams here and carry their own detail in [Chapter 2](02-architecture-streams.md).

## 17.2 Core concepts (chapter 3)
{{csv:togaf_intro}}

## 17.3 Defined terms (chapter 4)
{{csv:togaf_concepts}}

## 17.4 Appendix B: supplementary definitions
The 44 supplementary terms (B.1 to B.44), each placed in a stream.
{{csv:togaf_glossary}}

## 17.5 Appendix C: acronyms and abbreviations
All 85 acronyms in the Introduction and Core Concepts, with the stream that mostly uses them. Where the standard's own expansion differs from common use (for example API, RAS, SPEM), the table says so.
{{csv:togaf_acronyms}}

## 17.6 Appendix A: referenced documents
The TOGAF Series Guides (A.1), other Open Group publications (A.2) and other referenced documents (A.3), mapped to the stream they feed. Use this as the reading list for each stream.
{{csv:togaf_references}}

## 17.7 The stream matrix
The full matrix (each concept against each of the twelve streams, P = primary, S = supporting) is in the Workbook under **Stream matrix**.

## 17.8 Extra items this template adds
| Item | Why |
|---|---|
| Streams 6 to 12 (AI, Security, UI/UX, Infrastructure, Integration, Domain, Industry) | Modern programmes need them; TOGAF's four domains are the base. |
| Stream lens table | Shows each stream applying the same TOGAF concepts consistently. |
| BABOK, DMBOK, BIZBOK and quality gates | Depth the TOGAF introduction does not cover. |

## 17.9 How to keep it complete
When TOGAF is updated, edit `tools/togaf_data.py` and `tools/togaf_appendices.py` (or the CSVs in `data/`), rebuild, and the Document, Deck and Workbook update together. The build check fails if a term has no stream or no location.
