# Technology Architecture (Phase D)

> **In brief.** Cloud services in approved regions, an integration hub, zero-trust partner access and full observability.

## 13.1 Standards
{{csv:tech_standards}}

## 13.2 Integration platform
An enterprise integration hub (iPaaS) holds partner adapters, the canonical model service and the cross-reference tables. It receives signed webhooks from the hub, calls partner APIs, retries with back-off and writes audit events. The detailed patterns are in [Chapter 20](20-integration-architecture-patterns.md).

## 13.3 Security architecture
- Staff sign in with enterprise SSO; accounts provisioned by SCIM.
- Partner credentials are scoped OAuth 2.0 clients stored in a vault and rotated.
- Webhooks are signed and replay-protected.
- All calls, decisions and exports are written to an immutable audit log.

## 13.4 Non-functional targets
Availability, performance, accessibility and support targets are in the non-functional requirements ([Chapter 8](08-requirements.md)).

## 13.5 Environments
Sandbox, test and production for the hub and the integration hub; partners provide sandboxes for contract tests; no production candidate data in lower environments.
