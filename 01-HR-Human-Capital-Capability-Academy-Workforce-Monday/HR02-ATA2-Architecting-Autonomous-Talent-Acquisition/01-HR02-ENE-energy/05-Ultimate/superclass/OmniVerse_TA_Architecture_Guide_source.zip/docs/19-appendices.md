# Appendices

> **In brief.** Crosswalks, templates, open items and references that support the main chapters.

## Appendix A: Framework crosswalk
One row per stage of work: the TOGAF ADM phase, BABOK v3 knowledge area, DMBOK2 area, artefacts produced and the quality gate.

{{csv:crosswalk}}

## Appendix B: How the frameworks complement each other
| Framework | Strength | Used here for |
|---|---|---|
| TOGAF ADM | Whole-of-enterprise method; architecture domains; governance | Structure of the HLDD (Chapters 6, 10 to 13, 15 and 16) |
| BABOK v3 | Depth in elicitation, requirements and evaluation | Structure of the BRD (Chapters 7, 8 and 14) |
| DAMA-DMBOK2 | Depth in data management | Data architecture and governance (Chapter 11) |
| BIZBOK (Business Architecture Guild) | Business blueprints and practice | Chapters 9 and 10 |
| 9P4V (SuccessLabs Academy) | Transformation spine from vision to venture; nine pillars | Chapter 3, applied to every chapter |
| Quality gates | Day-to-day quality and consistency | Templates, gates, checklists (Chapter 5) |

## Appendix C: Requirements document skeleton (reusable)
1. Introduction: purpose, scope, audience, definitions
2. Business context: problem, objectives, stakeholders
3. Current and future state; gap analysis
4. Business requirements
5. Stakeholder requirements (user stories)
6. Solution requirements: functional, non-functional
7. Transition requirements
8. Data requirements: entities, dictionary, quality, retention
9. Interface requirements
10. Reporting and notification requirements
11. Assumptions, constraints, dependencies
12. Risks and open items
13. Traceability matrix
14. Glossary, sign-off

## Appendix D: ADR template
| Field | Content |
|---|---|
| ID | ADR-nn |
| Title | Short decision |
| Status | Proposed, Accepted, Superseded |
| Context | Forces and constraints |
| Options | At least two, with pros and cons |
| Decision | The choice and why |
| Consequences | Effects, risks, follow-up |
| Date and owner | |

## Appendix E: Open items to confirm locally
- Recruiter, hiring-manager and candidate volumes per country
- Retention periods set by law and by works-council agreements
- Rules on AI in hiring per country and any candidate-notice duties
- Which marketplace partners are certified and available per region
- Hosting model and data-residency constraints
- Existing legacy ATS contracts and end dates
- Cost, timeline, budget source, implementation partner

## Appendix F: Adapting to a country or organisation
| Variable | How to adapt |
|---|---|
| Hiring regulation | Set right-to-work, check scope and consent wording per country as configuration |
| Partner availability | Choose regional partners per category; keep the capability interface unchanged |
| Language and script | Enable local and right-to-left support in the presentation layer |
| Address and geography | Configure local addressing and coordinate system |
| Data residency and privacy | Choose hosting and personal-data controls to match local law |
| Retention | Set classes to the regulator or archive rule |
| Currency and calendar | Set currency, fiscal calendar and working-day calendar for SLAs |

## Appendix G: Glossary
{{csv:glossary}}

## Appendix H: Further reading (public sources)
- The Open Group: TOGAF Standard, 10th Edition
- IIBA: A Guide to the Business Analysis Body of Knowledge (BABOK Guide) v3 and The Business Analysis Standard
- DAMA International: DAMA-DMBOK, Data Management Body of Knowledge, 2nd edition

This document applies the public concepts of these works in its own words and does not reproduce their text.

## Appendix I: Trademarks
TOGAF is a registered trademark of The Open Group. BABOK is a registered trademark of IIBA. DAMA and DMBOK are marks of DAMA International. All other names are the property of their owners.
