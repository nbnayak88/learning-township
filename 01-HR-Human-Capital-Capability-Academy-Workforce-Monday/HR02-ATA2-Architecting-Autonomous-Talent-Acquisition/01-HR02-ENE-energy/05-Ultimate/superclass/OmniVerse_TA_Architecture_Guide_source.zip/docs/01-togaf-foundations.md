# TOGAF Foundations: Core Concepts and Definitions

> **In brief.** A shared vocabulary. The TOGAF core concepts and definitions that every other chapter relies on, in plain words.

This chapter covers every topic in chapter 3 (Core Concepts) and every term in chapter 4 (Definitions) of the TOGAF® Standard, 10th Edition, *Introduction and Core Concepts*. Each section explains the ideas in plain words, then says where this template applies them. Numbers in brackets are the TOGAF section numbers, so you can check against the standard. The full item-by-item table is in [Chapter 17](17-togaf-coverage.md).

## 1.1 Enterprise and architecture
An **enterprise** [4.43] is any collection of organisations sharing goals. It can be a whole company, a government body, or a unit within one. **Architecture** [4.8, 3.2] has two meanings that are both useful: the fundamental structure of something, and the description of that structure and the rules that guide how it changes. The TOGAF Standard deals with four **architecture domains** [4.12, 3.3]: business, data, application and technology. This template keeps those four and adds eight more streams in [Chapter 2](02-architecture-streams.md).

## 1.2 Enterprise Continuum
The **Enterprise Continuum** [3.10, 4.45] classifies assets from generic to specific. It has two halves: the **Architecture Continuum** [4.10] for architecture assets and the **Solutions Continuum** [4.75] for the solutions that implement them. At the generic end sit **foundation architectures** [4.46] and **reference models** [4.64]; at the specific end sit organisation-specific architectures and solutions. A **standards library** [4.77] holds the standards you must or should follow.

| Position | What it contains | Template artefact |
|---|---|---|
| Foundation | Generic principles, standards, patterns | Principles, tech standards, patterns |
| Common systems | Reusable across many organisations in a sector | Domain and industry mapping (streams 11 and 12) |
| Industry | Sector reference models and regulation | Regulatory obligations, country profile |
| Organisation-specific | Your architecture, decisions and plans | Your filled registers |
| Solution | Concrete products and configuration | Components with SBB, hosting model |

## 1.3 ADM, landscape, levels and partitions
The **Architecture Development Method** [3.4, 4.11] is a cycle: Preliminary, A Vision, B Business, C Information Systems, D Technology, E Opportunities and Solutions, F Migration Planning, G Implementation Governance, H Change Management, with Requirements Management at the centre. [Chapter 15](15-migration-planning.md) and the crosswalk show how each gate maps to a phase.

The **architecture landscape** [4.15] is the set of architecture assets in use at a point in time; the **EA landscape** [4.42] is that view across the whole enterprise. Because it is large, work is scoped by **architecture level** [4.16] and split into **partitions** [4.18]:

| Level | Meaning | Where here |
|---|---|---|
| **Strategic architecture** [4.78] | Long-term direction for the whole enterprise | Vision, roadmap |
| **Segment architecture** [4.68] | A detailed slice of the enterprise | Work packages by wave |
| **Capability architecture** [4.34] | One capability, delivered in **capability increments** [4.35] | Work packages |

A **baseline** [4.24] is the current state, a **target architecture** [4.79] the desired state, a **transition architecture** [4.84] a stage between them, and a **gap** [4.48] a difference needing action. A **roadmap** [4.66] orders the change, delivered as **work packages** [4.89], following a **course of action** [4.38] chosen from options. See [Chapter 14](14-strategy-analysis.md) and [Chapter 15](15-migration-planning.md).

## 1.4 Deliverables, artifacts and building blocks
A **deliverable** [4.40] is a formally reviewed work product, an **artifact** [4.23] is a specific model inside it, and a **building block** [4.26] is a reusable piece of capability. [3.6] An **architecture building block (ABB)** [4.9] says *what* is needed; a **solution building block (SBB)** [4.74] says *which product or build* delivers it. In this template each chapter is a deliverable, each register row is an artifact, and the components register carries ABB and SBB columns.

## 1.5 Abstraction levels
**Abstraction** [4.1, 3.7] means leaving out detail to show the essential idea. Four levels are used:

| Level | Question answered | Template artefact |
|---|---|---|
| Contextual [3.7.1] | Why and for whom? | Vision, stakeholders, context diagram |
| Conceptual [3.7.2] | What are the main ideas? | Capability map, conceptual data model, value stream |
| **Logical** [4.53, 3.7.3] | What is needed, regardless of product? | Layered architecture, data dictionary, interface catalogue |
| **Physical** [4.61, 3.7.4] | What is built, on what? | Tech standards, hosting model, environments |

## 1.6 Styles, patterns and services
An **architectural style** [4.7, 3.15] is a family of design approaches, such as layered, service-oriented or event-driven. A **pattern** [4.60] is a proven solution to a recurring problem. **Service orientation** [4.70] designs capability as loosely coupled **services** [4.69]; **service-oriented architecture (SOA)** [4.71] is the style built on it. We distinguish the **business service** [4.32] (an outcome for a customer), the **application service** [4.6] (software functionality) and the **technology service** [4.83] (platform capability such as identity or messaging), together managed in a **service portfolio** [4.72]. The template's principles prefer services behind governed interfaces.

## 1.7 Interoperability and boundaryless information flow
**Interoperability** [4.52, 3.9] is the ability to exchange information and use it meaningfully. **Boundaryless Information Flow** [4.25] is the aim that information moves securely across organisational and system boundaries without costly custom work. Here: the interface catalogue, exchange standards, and the integration stream.

## 1.8 Models, views, viewpoints and the metamodel
A **model** is built by **modeling** [4.17, 4.57]. A **model kind** [4.58] is a type such as catalogue, matrix or diagram. A **view** [4.86, 4.20] is what a stakeholder sees; a **viewpoint** [4.87, 4.21] defines how to build and read that view for their **concerns** [4.37]. A **viewpoint library** [4.88] collects reusable viewpoints and a **taxonomy of architecture views** [4.80] classifies them. The **metamodel** [4.55, 3.11] defines which entities and relationships are allowed; **metadata** [4.54] describes data.

| Stakeholder | Viewpoint | View in this template |
|---|---|---|
| Sponsor | Strategic and benefits | Vision, KPIs, roadmap (deck) |
| Business owner | Capability and process | Capability map, value stream |
| Analyst | Requirements and trace | Requirements register |
| Data steward | Data and quality | Entities, dictionary, DQ rules |
| Architect | Structure and decisions | Components, interfaces, ADRs |
| Security officer | Protection and risk | Classification, access, risks |
| Operations | Run and resilience | Hosting, availability, DR |

**Our metamodel:** capability, process, rule, requirement, data entity, component, interface, risk, work package and decision, each with a stable ID; relationships are trace columns (for example "Realised by"). To extend it, add a column or a register, as described in [Chapter 18](18-using-as-a-template.md).

## 1.9 Digital architecture
**Digital architecture** [4.41] covers the digital capabilities, platforms, data and experiences that run the enterprise. Here that is the combination of data, application, integration, AI, security and UI/UX streams.

## 1.10 Enterprise Architecture services
**Enterprise Architecture services** [4.44, 3.5] are what the architecture function offers the organisation. The six groups [3.5.1 to 3.5.6] and the artefacts that deliver them:

| Service group | Delivered by |
|---|---|
| Enterprise support [3.5.1] | Principles, standards, decisions |
| Design support [3.5.2] | Component catalogue, patterns, building blocks |
| Development support [3.5.3] | Gates, definition of ready and done, QA checklist |
| Requirements elicitation and understanding [3.5.4] | BABOK approach, requirements register |
| Architecture planning [3.5.5] | Gap analysis, work packages, roadmap |
| Practice development [3.5.6] | Governance, RACI, this template |

## 1.11 Repository, capability and governance
The **architecture repository** is the managed store of architecture content; here it is the Git repository. Building the practice [3.12, 3.13] means roles, process, tools and measures; see [Chapter 16](16-governance.md). **Architecture governance** [4.14], **governance** [4.49], **business governance** [4.30], the **architecture principle** [4.19, 3.8] and **principle** [4.62], **role** [4.67], **stakeholder** [4.76] and **communications and stakeholder management** [4.36] are all in Chapters 6, 7 and 16.

## 1.12 Other frameworks, agility and risk
TOGAF is used with other frameworks [3.14, 4.13, 4.47]; the crosswalk aligns TOGAF with BABOK, DAMA-DMBOK, the Business Architecture Guild's BIZBOK and the quality gates. **Enterprise agility** [3.17] means responding to change in small, safe steps; docs-as-code and incremental transitions support it. **Risk management** [3.18] is the risk register with likelihood, impact, score and heat map ([Chapter 14](14-strategy-analysis.md), [Chapter 16](16-governance.md)).

## 1.13 Remaining definitions in one place
**Business architecture** [4.27], **business capability** [4.28], **business function** [4.29], **business model** [4.31], **capability** [4.33], **value stream** [4.85], **objective** [4.59], **requirement** [4.65], **actor** [4.2]: [Chapter 10](10-business-architecture.md) and [Chapter 8](08-requirements.md). **Data architecture** [4.39], **information** [4.50]: [Chapter 11](11-data-architecture.md). **Application architecture** [4.3], **application component** [4.4], **solution architecture** [4.73]: [Chapter 12](12-application-architecture.md). **Technology architecture** [4.81], **technology component** [4.82], **application platform** [4.5], **information technology** [4.51], **product** [4.63]: [Chapter 13](13-technology-architecture.md). **Method** [4.56], **architecture framework** [4.13]: [Chapter 7](07-ba-approach.md).
