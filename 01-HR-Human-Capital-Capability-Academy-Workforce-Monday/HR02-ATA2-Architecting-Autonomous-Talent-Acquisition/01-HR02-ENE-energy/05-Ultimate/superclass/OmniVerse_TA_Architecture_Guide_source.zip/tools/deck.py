# Generates the slide deck from the same data and chapters. Executed by build.py (uses e(), table_html()).
def make_slides(D, stats):
    def cut(s, n): s = str(s); return s if len(s) <= n else s[:n-1].rstrip() + "…"
    def sl(inner, cls=""): return f'<section class="slide {cls}"><div class="sl">{inner}</div></section>'
    def page(k, title, inner, cls=""): return sl(f'<div class="k">{e(k)}</div><h2>{e(title)}</h2>{inner}', cls)
    def tbl(name, cols, limit=None, trunc=None, filt=None, start=0):
        c, rows = D[name]
        if filt: rows = [r for r in rows if r[c.index(filt[0])] == filt[1]]
        rows = rows[start:]
        if limit: rows = rows[:limit]
        idx = [c.index(x) for x in cols]
        out = [[cut(r[i], (trunc or {}).get(c[i], 90)) for i in idx] for r in rows]
        return table_html(cols, out, "")
    def fig(fn): return f'<div class="fig"><img src="assets/{fn}" alt=""></div>'
    def count(name, col): 
        c, rows = D[name]; i = c.index(col); m = {}
        for r in rows: m[r[i]] = m.get(r[i], 0) + 1
        return m
    def bars(m):
        if not m: return '<p>No data yet</p>'
        mx = max(m.values())
        return "".join(f'<div class="bar"><span>{e(k)}</span><i style="width:{max(4,100*v/mx)}%"></i><em>{v}</em></div>' for k, v in m.items())
    S = []
    S.append(sl(f'<img src="assets/logo.png" alt="SuccessLabs Academy logo"><div class="k">{e(PROG)}</div><h1>{e(CFG["subject"])}</h1><p>{e(CFG["tagline"])}</p><p class="k" style="margin-top:2cqw">TOGAF · BABOK · DAMA-DMBOK2 · BIZBOK (BA Guild) · 12 architecture streams · {e(CFG["org"])}</p>', "title"))
    S.append(page("How to use this deck", "Online, from one source", '<div class="cols" style="grid-template-columns:1fr 1fr 1fr"><div class="box"><h4>Document</h4><p>24 chapters: vision, business, requirements, data, application, technology, migration, governance, integration patterns, the 28 partner categories, responsible AI and the SAP Activate case study.</p></div><div class="box"><h4>Deck</h4><p>This presentation. Keys: ← → move, F full screen, O overview.</p></div><div class="box"><h4>Workbook</h4><p>Registers and matrices: search, sort, filter, dashboard.</p></div></div><p style="margin-top:1.2cqw"><b>No client data.</b> Every local value is a [placeholder]. Nothing to upload or download: share a link.</p>'))
    S.append(page("Architecture vision (TOGAF Preliminary and Phase A)", "The problem and the vision",
        '<div class="cols" style="grid-template-columns:1fr 1.2fr"><div><h4 style="color:#a3123c">The problem</h4><ul><li>Three legacy hiring tools and spreadsheets across 14 countries</li><li>Different process and candidate experience in each country</li><li>Assessment, interview and check tools bought locally</li><li>Slow checks for safety-critical roles</li><li>AI use and candidate data not governed</li><li>No single view of the funnel</li></ul></div><div class="pillar"><b>Vision</b><p class="big" style="color:#fff">Hire for safety and skill, fast and fairly, on one platform that welcomes the best partners today and lets OmniVerse replace any of them tomorrow.</p></div></div>'))
    S.append(page("Business objectives", "Seven objectives, each measurable",
        '<div class="grid" style="grid-template-columns:repeat(4,1fr)">' + "".join(f'<div class="chip"><b>{a}</b>{b}</div>' for a, b in [
        ("One platform","One process and one hiring data model"),("Faster hiring","Less admin, shorter time to hire"),("Safe hiring","Checks and clearance before day one"),("Vendor freedom","28 categories behind capability interfaces"),
        ("Fair AI","Advisory only, logged and tested"),("Visibility","Funnel, SLAs, KPIs in one place"),("Governance","Exit plans, audit trail, decision records")]) + '<div class="chip" style="background:#fff4f7"><b>Outcome</b>Faster, safer, fair, replaceable</div></div>'))
    S.append(page("Stakeholders (TOGAF Phase A, BABOK)", "Who cares and how we engage them", tbl("stakeholders", ["Stakeholder","Power","Interest","Engagement approach"], 10, {"Engagement approach":70})))
    pr = D["principles"][1]
    S.append(page("Architecture principles", "Thirteen principles guide every decision",
        '<div class="cols" style="grid-template-columns:repeat(4,1fr)">' + "".join('<div class="box"><h4>%s</h4><ul>%s</ul></div>' % (d, "".join(f'<li>{e(r[2])}</li>' for r in pr if r[1] == d)) for d in ["Business","Data","Application","Technology"]) + '</div>'))
    cap = D["capabilities"][1]; doms = []
    for r in cap:
        if r[0] not in doms: doms.append(r[0])
    S.append(page("Business architecture (TOGAF Phase B)", "Capability map",
        f'<div class="cols" style="grid-template-columns:repeat({max(1,min(len(doms),4))},1fr);grid-auto-rows:min-content">' + "".join('<div class="box"><h4>%s</h4>%s</div>' % (e(d), "".join(f'<div class="chip" style="margin:.4cqw 0">{e(r[1])}</div>' for r in cap if r[0] == d)) for d in doms) + '</div>'))
    S.append(page("Business architecture", "Value stream: Hire to Day One with partner touchpoints", fig("flow.png")))
    cls = count("requirements", "BABOK class"); pri = count("requirements", "MoSCoW")
    S.append(page("Requirements (BABOK v3)", f"{len(D['requirements'][1])} requirements, four BABOK types",
        f'<div class="cols" style="grid-template-columns:1fr 1fr"><div class="box"><h4>By type</h4>{bars(cls)}</div><div class="box"><h4>By priority (MoSCoW)</h4>{bars(pri)}</div></div><p>Every requirement has an ID, acceptance criteria, owner, trace links and status.</p>'))
    S.append(page("Requirements", "Business requirements", tbl("requirements", ["ID","Requirement","MoSCoW"], None, {"Requirement":120}, ("BABOK class","Business"))))
    S.append(page("Requirements", "Key functional requirements", tbl("requirements", ["ID","Requirement","MoSCoW"], 9, {"Requirement":120}, ("BABOK class","Functional"))))
    S.append(page("Requirements", "Non-functional requirements", tbl("requirements", ["ID","Requirement","MoSCoW"], 9, {"Requirement":115}, ("BABOK class","Non-functional"))))
    S.append(page("Application architecture (TOGAF Phase C)", "System context", fig("context.png")))
    S.append(page("Application architecture", "Layered reference architecture", fig("arch.png")))
    S.append(page("Application architecture", "Components (architecture building blocks)", tbl("components", ["ID","Component","Layer","Key responsibilities"], 12, {"Key responsibilities":80})))
    S.append(page("Integration", "Interface catalogue", tbl("interfaces", ["ID","Interface","Direction","Mode","Frequency","Classification"], 11)))
    S.append(page("Data architecture (TOGAF Phase C, DMBOK2)", "Conceptual data model: the Case is the spine", fig("datamodel.png")))
    dm = D["dmbok_areas"][1]
    S.append(page("DAMA-DMBOK2", "All eleven data management areas applied",
        '<div class="grid" style="grid-template-columns:repeat(4,1fr)">' + "".join(f'<div class="chip"><b>{e(r[0])}</b>{e(cut(r[1],60))} · target {e(r[3])}/5</div>' for r in dm) + '</div>'))
    S.append(page("Data quality", "Quality rules at entry, in integration and in reporting", tbl("dq_rules", ["ID","Dimension","Rule","Threshold"], 10, {"Rule":80})))
    S.append(page("Data governance", "Ownership, stewardship, classification",
        '<div class="cols" style="grid-template-columns:1fr 1fr 1fr"><div class="box"><h4>Roles</h4><ul><li>Data owner: accountable per domain</li><li>Data steward: quality and definitions</li><li>AI and privacy board: monthly</li></ul></div><div class="box"><h4>Classification</h4><ul><li>Internal</li><li>Confidential: requisition, offer, candidate</li><li>Restricted: identity, checks, medical clearance</li></ul></div><div class="box"><h4>Lifecycle</h4><ul><li>Collect with consent and purpose</li><li>Retain by region table, then delete</li><li>Check detail stays with the provider</li></ul></div></div>'))
    S.append(page("Technology architecture (TOGAF Phase D)", "Security, resilience, hosting",
        '<div class="cols" style="grid-template-columns:1fr 1fr"><div class="box"><h4>Security</h4><ul><li>Enterprise SSO and SCIM for staff</li><li>Scoped OAuth 2.0 credentials per partner, in a vault</li><li>Signed, replay-protected webhooks</li><li>Immutable audit log</li><li>Contract tests per partner release</li></ul></div><div class="box"><h4>Resilience and hosting</h4><ul><li>Availability [99.5]%; recovery targets per component</li><li>Retry with back-off, dead-letter queue, daily reconciliation</li><li>Vendor cloud in the region set by the residency table</li><li>Exit plan tested yearly per partner category</li></ul></div></div>'))
    S.append(page("Decisions", "Architecture decision records", tbl("adr", ["ID","Decision","Status"], 8, {"Decision":90})))
    S.append(page("TOGAF 10", "The ADM applied", fig("adm.png")))
    wp = D["work_packages"][1]; tas = []
    for r in wp:
        if r[2] not in tas: tas.append(r[2])
    S.append(page("Migration planning (TOGAF Phases E and F)", "Transition architectures and work packages",
        f'<div class="cols" style="grid-template-columns:repeat({max(1,len(tas))},1fr)">' + "".join('<div class="box"><h4>%s</h4>%s</div>' % (e(t), "".join(f'<div class="chip" style="margin:.4cqw 0"><b>{e(r[0])}</b>{e(cut(r[1],48))}</div>' for r in wp if r[2] == t)) for t in tas) + '</div>'))
    S.append(page("Strategy analysis (BABOK)", "Gap analysis", tbl("gap_analysis", ["Domain","Baseline (typical)","Target","Closing work package"], 8, {"Baseline (typical)":55,"Target":55})))
    rk = sorted(D["risks"][1], key=lambda r: -int(r[4]))[:8]
    S.append(page("Risk", "Top risks by score (likelihood × impact)", '<div class="box">' + "".join(f'<div class="bar" style="grid-template-columns:3.2cqw 1fr 3cqw"><span>{e(r[0])}</span><span>{e(cut(r[1],95))}</span><em>{r[4]}</em></div>' for r in rk) + '</div>'))
    S.append(page("Benefits", "KPI catalogue", tbl("kpis", ["ID","KPI","Frequency","Owner"], 12, {"KPI":60})))
    S.append(page("Governance and quality (gates)", "Quality gates from vision to benefit review", tbl("crosswalk", ["Quality gate","Stage","TOGAF 10 ADM","BABOK v3 knowledge area"], 11, {"TOGAF 10 ADM":40,"BABOK v3 knowledge area":50})))
    S.append(page("Paperless Architecture Initiative", "Docs-as-code: author, review, validate, publish, consume", fig("pipeline.png") + '<p>Edit in the browser → pull request → review → merge → site rebuilds. One source, three views: Document, Deck, Workbook.</p>'))
    bd = D["bizbok_domains"][1]
    S.append(page("BA Guild (BIZBOK)", "Ten business architecture domains: four core, six extended",
        '<div class="cols" style="grid-template-columns:1fr 1.5fr"><div class="box"><h4>Core (stable)</h4>' + "".join(f'<div class="chip" style="margin:.4cqw 0"><b>{e(r[0])}</b>{e(cut(r[2],70))}</div>' for r in bd if r[1] == "Core") + '</div><div class="box"><h4>Extended (change more often)</h4><div class="grid" style="grid-template-columns:1fr 1fr">' + "".join(f'<div class="chip"><b>{e(r[0])}</b>{e(cut(r[2],60))}</div>' for r in bd if r[1] == "Extended") + '</div></div></div>'))
    se = D["bizbok_strategy_execution"][1]; steps = []
    for r in se:
        if r[0] not in steps: steps.append(r[0])
    S.append(page("BA Guild (BIZBOK)", "Strategy execution in five steps",
        f'<div class="cols" style="grid-template-columns:repeat({max(1,len(steps))},1fr)">' + "".join('<div class="box"><h4 style="font-size:1.3cqw">%s</h4><ul style="font-size:1.05cqw;margin:0;padding-left:1.2cqw">%s</ul></div>' % (e(s), "".join(f'<li>{e(cut(r[1],30))}</li>' for r in [x for x in se if x[0] == s][:6])) for s in steps) + '</div>'))
    sp = D["p4v_spine"][1]
    S.append(page("9P4V Framework", "Vision, Value, Victory, Venture: the transformation spine",
        '<div class="cols" style="grid-template-columns:repeat(4,1fr);align-items:start">' + "".join(f'<div class="box"><h4>{e(r[0])} {e(r[1])}</h4><p style="font-size:1.5cqw"><i>{e(r[2])}</i></p><p style="font-size:1.4cqw"><b>{e(r[4])}</b></p><p style="font-size:1.2cqw">{e(r[5])}</p></div>' for r in sp) + '</div><p style="font-size:1.4cqw">Venture feeds the next Vision. 12 streams are the lenses; industry is the context.</p>'))
    S.append(page("9P4V Framework", "Nine pillars", tbl("p4v_pillars", ["Pillar","Group","Core question","Typical measure"], 9, {"Core question":60,"Typical measure":40})))
    S.append(page("9P4V Framework", "The 18-stage journey: stages 1 to 9", tbl("p4v_stages", ["Stage","Name","Deliverable","Position"], 9, {"Deliverable":60})))
    S.append(page("9P4V Framework", "The 18-stage journey: stages 10 to 18", tbl("p4v_stages", ["Stage","Name","Deliverable","Position"], 9, {"Deliverable":60}, None, 9)))
    S.append(page("9P4V Framework", "Applied Architecture Score and levels", '<div class="cols" style="grid-template-columns:1fr 1fr"><div class="box">' + tbl("p4v_score", ["Dimension","Weight %"], 10, {}) + '</div><div class="box">' + tbl("p4v_levels_score", ["Score","Capability level"], 5, {}) + '</div></div>'))
    stm = D["streams"][1]
    S.append(page("Reusable template", "Twelve architecture streams",
        '<div class="grid" style="grid-template-columns:repeat(4,1fr)">' + "".join(f'<div class="chip"><b>{e(r[0][1:])}. {e(r[1])}</b>{e(cut(r[2],86))}</div>' for r in stm) + '</div>'))
    S.append(page("Stream ownership", "Who owns each stream and what it produces", tbl("streams", ["Stream","Key artefacts","TOGAF ADM phases","Typical owner"], 12, {"Key artefacts":70})))
    sc = D["stream_counts"][1]
    S.append(page("TOGAF coverage", "Every core concept and term, placed in the streams",
        '<div class="cols" style="grid-template-columns:1fr 1.4fr"><div class="box"><h4>Covered</h4><ul><li>18 core-concept topics plus sub-sections (chapter 3)</li><li>89 defined terms (chapter 4)</li><li>Each with a plain-words meaning, a location, an artefact, a primary and supporting streams</li></ul></div><div class="box"><h4>TOGAF items touched per stream</h4>' + bars({r[1]: int(r[4]) for r in sc}) + '</div></div>'))
    S.append(page("Reusable template", "Use it for any solution, any country",
        '<div class="cols" style="grid-template-columns:repeat(4,1fr)"><div class="box"><h4>1. Copy</h4><p>Use this template on GitHub.</p></div><div class="box"><h4>2. Initialise</h4><p>Run init_template.py with your programme and subject.</p></div><div class="box"><h4>3. Fill</h4><p>Edit registers and chapters online.</p></div><div class="box"><h4>4. Publish</h4><p>Commit: the site rebuilds itself.</p></div></div>'))
    st = "".join(f'<div class="chip"><b>{a}</b>{b}</div>' for a, b in stats)
    S.append(page("Next steps", "Make it local", f'<div class="grid" style="grid-template-columns:repeat(4,1fr)">{st}</div><ul><li>Fill the [placeholders]: users, retention, hosting, regulator format, tax treatment</li><li>Run a fit-gap against your existing platforms</li><li>Agree the data owners and stewards</li><li>Take the baseline KPIs, then plan wave 1</li></ul>'))
    S.append(sl(f'<img src="assets/logo.png" alt="SuccessLabs Academy logo"><div class="k">Thank you</div><h1>Architecting for a Better World</h1><p>{e(CFG["org"])} · {e(PROG)}</p>', "title"))
    return S
