#!/usr/bin/env python3
"""Authors data/togaf_glossary.csv (Appendix B), togaf_acronyms.csv (Appendix C), togaf_references.csv (Appendix A).
Meanings are in our own words. Run after togaf_data.py. Streams use the same 12 names."""
import csv, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def write(name, cols, rows):
    with open(f"{ROOT}/data/{name}.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(cols); w.writerows(rows)
SN = {"S01":"Enterprise","S02":"Business","S03":"Data","S04":"Application","S05":"Technology","S06":"AI","S07":"Security","S08":"UI/UX","S09":"Infrastructure","S10":"Integration","S11":"Domain","S12":"Industry"}
def sn(s): return ", ".join(SN[x] for x in s.split(",")) if s else ""

# ---------- Appendix B: supplementary definitions  (ref|term|meaning|where|primary|supporting)
B = """B.1|Application Software|Software built for a particular business purpose.|Ch 12|S04|S05
B.2|Availability|The likelihood that a system can be used when needed, counting all time including repair and administration.|Ch 13|S09|S05,S07
B.3|Business System|The mix of people, process, policy, standards, software and hardware that together deliver a business capability.|Ch 10|S02|S04,S05
B.4|Catalog|A structured list of architecture outputs of one kind, such as a standards list or application portfolio. Each register here is a catalog.|Ch 1, 9|S01|S03
B.5|Client|A component that asks another component for a service.|Ch 12|S04|S10
B.6|COBIT|A governance and management framework for information and technology from ISACA.|Ch 16|S01|S07
B.7|Configuration Management|Keeping control of what exists and how it changes: identify items, control changes, record status. Also applies to the architecture assets themselves, which is why they live in Git.|Ch 4|S01|S09
B.8|CxO|A chief officer of a business function, for example the CEO or CIO.|Ch 6|S01|S02
B.9|Data Dictionary|A catalogue of data elements and their meaning, format, owner and rules.|Ch 11|S03|S07
B.10|Data Element|The smallest named unit of data that carries meaning.|Ch 11|S03|
B.11|Database|An organised collection of data stored to be used by programs.|Ch 11|S03|S05
B.12|Database Management System|Software that stores, retrieves and changes the data in a database.|Ch 13|S05|S03
B.13|End User|The person who finally uses the application or its output.|Ch 7|S08|S02
B.14|Enterprise Resource Planning (ERP) System|A suite of integrated applications covering major support functions such as finance, HR, purchasing and logistics.|Ch 12|S04|S02,S10
B.15|Hardware|The physical equipment software runs on: servers, workstations, network devices.|Ch 13|S09|S05
B.16|Information Domain|A grouping of data by a criterion such as classification, ownership or location.|Ch 11|S03|S07
B.17|Information System (IS)|The computer-based part of a business system.|Ch 12|S04|S03
B.18|Interaction|A relationship between building blocks that means they communicate or use each other.|Ch 12|S10|S04
B.19|Interaction Model|A view, catalogue or matrix showing one kind of interaction, such as an integration diagram.|Ch 12|S10|S04
B.20|Interface|The connection between people, systems, devices or applications.|Ch 12|S10|S08,S04
B.21|Key Performance Indicator (KPI)|A measure of how well the business or a project is performing.|Ch 14|S02|S01
B.22|Lifecycle|The period from a system's conception until it is no longer available.|Ch 13|S05|S09
B.23|Managing Successful Programs (MSP)|A programme management method from the UK government.|Ch 15|S01|
B.24|Matrix|A grid showing the relationship between two or more architecture elements, for example the stream matrix.|Ch 17|S01|S03
B.25|Metaview|A template from which individual views are made, stating purpose, audience, notation and use.|Ch 1.8|S01|S08
B.26|Open System|A system built on enough open specifications that software is portable, interoperable and usable across environments.|Ch 13|S05|S10
B.27|Operational Governance|Managing how systems perform against agreed service levels, and setting those levels.|Ch 16|S09|S01
B.28|Packaged Services|Services bought from a vendor as off-the-shelf products instead of being built.|Ch 12|S04|S05
B.29|Portability|How easily a system, component or data can move to a different environment.|Ch 13|S05|S09
B.30|Portfolio|A group of programmes, projects or assets managed together, such as an application or service portfolio.|Ch 12, 15|S01|S04
B.31|PRINCE2|A standard project management method.|Ch 15|S01|
B.32|Program|A coordinated set of change projects delivering business benefit.|Ch 15|S01|S02
B.33|Project|A single change effort delivering business benefit.|Ch 15|S01|S02
B.34|Risk Management|Managing risks to the architecture practice and its goals; the register and heat map apply it.|Ch 14, 16|S07|S01
B.35|Scalability|The ability to run on very different sizes of platform and to grow with load.|Ch 13|S09|S05
B.36|Security|Services that protect data's confidentiality, integrity and availability.|Ch 13|S07|S03
B.37|Server|A component that answers requests from clients.|Ch 13|S05|S09
B.38|Service Quality|A preset bundle of non-functional properties assigned to a service or contract.|Ch 8|S04|S09,S10
B.39|SMART|A way of setting targets: specific, measurable, actionable, realistic, time-bound.|Ch 8|S02|S01
B.40|Supplier Management|Managing the suppliers of products and services to the architecture practice, with procurement.|Ch 16|S01|S12
B.41|System|A combination of interacting elements organised for one or more purposes.|Ch 1|S01|S05
B.42|Time Period|The span over which a potential impact is measured.|Ch 14|S07|S02
B.43|Use Case|A view of functionality showing capabilities in the context of the user.|Ch 8|S08|S02
B.44|User|Any person, organisation or unit using an information system.|Ch 7|S08|S02""".split("\n")
rows=[]
for l in B:
    r,t,m,w,p,s=l.split("|"); rows.append((r,t,m,w,SN[p],sn(s)))
write("togaf_glossary",["Ref","Supplementary term (Appendix B)","Meaning in plain words","Where covered","Primary stream","Supporting streams"],rows)

# ---------- Appendix C: acronyms  (acr|expansion|stream)
C = """ABB|Architecture Building Block|S04
ACMM|Architecture Capability Maturity Model|S01
ADM|Architecture Development Method|S01
ANSI|American National Standards Institute|S12
API|Application Platform Interface (as listed; commonly Application Programming Interface)|S10
ARTS|Association for Retail Technology Standards|S12
BMM|Business Motivation Model|S02
BPM|Business Process Management|S02
BPMN|Business Process Model and Notation|S02
BTEP|Canadian Government Business Transformation Enablement Program|S12
CMM|Capability Maturity Models|S01
CMMI|Capability Maturity Model Integration|S01
COBIT|Control Objectives for Information and related Technology|S01
COTS|Commercial Off-The-Shelf applications|S04
CRM|Customer Relationship Management|S04
CRUD|Create, Read, Update, Delete|S03
CSF|Critical Success Factor|S02
DBA|Database Administrator|S03
DBMS|Database Management System|S05
DoC|US Department of Commerce|S12
DoD|US Department of Defense|S12
DoDAF|Department of Defense Architecture Framework|S12
EAI|Enterprise Application Integration|S10
EDIFACT|UN Electronic Data Interchange for Administration, Commerce and Transport|S10
ERP|Enterprise Resource Planning|S04
ETL|Extract, Transform, Load|S10
FICO|Fair Isaac Corporation|S12
FTE|Full-Time Equivalent|S02
GOTS|Government Off-The-Shelf applications|S04
HIPAA|Health Insurance Portability and Accountability Act|S12
ICAM|Integrated Computer Aided Manufacturing|S12
ICOM|Inputs, Controls, Outputs, Mechanisms/Resources|S02
IDEF|ICAM DEFinition|S02
IEC|International Electrotechnical Commission|S12
IEEE|Institute of Electrical and Electronics Engineers|S12
III-RM|Integrated Information Infrastructure Reference Model|S10
IoT|Internet of Things|S09
ISACA|Information Systems Audit and Control Association|S12
ISACF|Information Systems Audit and Control Foundation|S12
ISO|International Organization for Standardization|S12
IT|Information Technology|S05
ITGI|IT Governance Institute|S01
ITIL|Information Technology Infrastructure Library|S09
ITPMF|IT Portfolio Management Facility|S01
J2EE|Java 2 Platform, Enterprise Edition|S05
KPI|Key Performance Indicator|S02
LAN|Local Area Network|S09
MDA|Model-Driven Architecture|S04
MSA|Microservices Architecture|S04
MSP|Managing Successful Programs|S01
MVA|Minimum Viable Architecture|S01
NAF|NATO Architecture Framework|S12
NASCIO|National Association of State Chief Information Officers|S12
OECD|Organisation for Economic Co-operation and Development|S12
OGC|UK Office of Government Commerce|S12
OLA|Operational-Level Agreement|S09
OMB|Office of Management and Budget|S12
OMG|Object Management Group|S12
ORB|Object Request Broker|S10
OSI|Open Systems Interconnection|S09
OSOA|Open Service-Oriented Architecture|S10
PDF|Portable Document Format|S08
PMBOK|Project Management Body of Knowledge|S01
PRINCE|PRojects in Controlled Environments|S01
QoS|Quality of Service|S09
RAS|Remote Access Services (as listed)|S09
RFC|Request For Change|S01
RFI|Request for Information|S02
RFP|Request for Proposal|S02
RM|Reference Model|S12
SBB|Solution Building Block|S04
SCA|Service Component Architecture|S10
SDO|Service Data Objects|S10
SEI|Software Engineering Institute|S12
SGML|Standard Generalized Markup Language|S03
SLA|Service-Level Agreement|S09
SMART|Specific, Measurable, Actionable, Realistic, Time-bound|S02
SOA|Service-Oriented Architecture|S10
SPEM|Software Process Engineering Metamodel (as listed: Software Processing Engineering Metamodel)|S03
SysML|Systems Modeling Language|S04
TAFIM|Technical Architecture Framework for Information Management|S12
TRM|Technical Reference Model|S05
UML|Unified Modeling Language|S04
WAN|Wide Area Network|S09
XML|Extensible Markup Language|S10""".split("\n")
write("togaf_acronyms",["Acronym (Appendix C)","Expansion","Stream"],[(a,e,SN[s]) for a,e,s in (l.split("|") for l in C)])

# ---------- Appendix A: referenced documents (group|title|id|stream|use)
A = """A.1|Applying the ADM Using Agile Sprints|G210|S01|Agile delivery of architecture
A.1|A Practitioners' Approach to Developing Enterprise Architecture Following the TOGAF ADM|G186|S01|Practical ADM
A.1|An Approach to Selecting Building Blocks|G248|S04|ABB and SBB choice
A.1|Architecture Maturity Models|G203|S01|Maturity targets
A.1|Architecture Project Management|G188|S01|Delivery control
A.1|Architecture Roles and Skills|G249|S01|RACI and skills
A.1|Architecture Skills Framework (superseded)|G198|S01|Skills
A.1|Business Capabilities|G211|S02|Capability map
A.1|Business Capability Planning|G233|S02|Capability planning
A.1|Business Models|G18A|S02|Business model
A.1|Business Scenarios|G176|S02|Requirements scenarios
A.1|Digital Technology Adoption: Readiness Assessment and Roadmap|G212|S06|Digital and AI readiness
A.1|Enabling Enterprise Agility|G20F|S01|Agility
A.1|Environmentally Sustainable Information Systems|G242|S09|Sustainability
A.1|Information Architecture: Business Intelligence and Analytics|G238|S03|Analytics
A.1|Information Architecture: Customer Master Data Management|G21B|S03|Master data
A.1|Information Architecture: Metadata Management|G234|S03|Metadata
A.1|Information Mapping|G190|S03|Information mapping
A.1|Integrating Risk and Security within a TOGAF Enterprise Architecture|G152|S07|Risk and security
A.1|Organization Mapping|G206|S02|Organisation mapping
A.1|The TOGAF Integrated Information Infrastructure Reference Model (III-RM)|G179|S10|Boundaryless information flow
A.1|The TOGAF Leader's Guide to Establishing and Evolving an EA Capability|G184|S01|Practice building
A.1|The TOGAF Technical Reference Model (TRM)|G175|S05|Technology reference
A.1|Using the TOGAF Framework to Define and Govern Service-Oriented Architectures|G174|S10|SOA
A.1|Value Streams|G178|S02|Value stream
A.2|A Practical Approach to Application Portfolio Consolidation|G18B|S04|Application portfolio
A.2|Archi Banking Group case study (BIAN, ArchiMate, TOGAF)|Y201|S12|Industry reference example
A.2|ArchiMate 3.2 Specification|C226|S01|Modelling notation
A.2|Digital Practitioner Body of Knowledge (DPBoK)|C196|S06|Digital practice
A.2|Exploring Synergies between TOGAF and Frameworx|W114|S12|Telecom industry
A.2|Information Architecture: BI and Metadata Management Reference Models|G201|S03|Data reference models
A.2|Open Risk Analysis (O-RA)|C20A|S07|Risk analysis
A.2|Open Risk Taxonomy (O-RT)|C20B|S07|Risk taxonomy
A.2|The Open Agile Architecture Standard|C208|S01|Agile architecture
A.2|IT4IT Standard|C24A|S09|IT operations value chain
A.2|TOGAF 9 and DoDAF 2.0|W105|S12|Defence frameworks
A.2|TOGAF and SABSA Integration|W117|S07|Security architecture
A.2|Architecture Compliance Review Checklists|G253|S01|Compliance review
A.3|PMBOK Guide (Project Management Institute)||S01|Project management
A.3|Process re-use opportunities to enhance the operating model (IEEM 2011)||S02|Process reuse
A.3|Analysis Patterns, M. Fowler||S04|Patterns
A.3|ANSI/IEEE Std 1471-2000, architectural description||S01|Architecture description
A.3|A Pattern Language, C. Alexander||S04|Patterns
A.3|Business Motivation Model (OMG)||S02|Motivation
A.3|BPMN Specification (OMG)||S02|Process notation
A.3|Business Transformation Enablement Program (BTEP)||S12|Government reference
A.3|COBIT 4.0 (IT Governance Institute)||S01|IT governance
A.3|Corporate Governance, R. Naidoo||S01|Governance
A.3|Design Patterns, Gamma, Helm, Johnson, Vlissides||S04|Design patterns
A.3|Enterprise Architecture as Strategy, Ross, Weill, Robertson||S01|Strategy
A.3|Enterprise Architecture Capability Maturity Model (US DoC)||S01|Maturity
A.3|Enterprise Architecture Maturity Model (NASCIO)||S01|Maturity
A.3|Enterprise Architecture Planning, Spewak and Hill||S01|Planning
A.3|Air Force Principles for Information Management||S03|Information principles
A.3|ISO/IEC 20000:2011 IT Service Management||S09|Service management
A.3|ISO/IEC/IEEE 15288:2015 Systems and software life cycle processes||S05|Life cycle
A.3|ISO/IEC/IEEE 42010:2022 Architecture description||S01|Architecture description
A.3|IT Portfolio Management Facility (OMG)||S01|Portfolio
A.3|Manifesto for Agile Software Development||S01|Agile
A.3|Merriam-Webster Collegiate Dictionary||S01|Term source
A.3|Model-Driven Architecture (OMG)||S04|Model driven
A.3|OECD Principles of Corporate Governance||S12|Governance
A.3|Organigraphs, Mintzberg and Van der Heyden||S02|Organisation views
A.3|Pattern-Oriented Software Architecture, Buschmann et al.||S04|Patterns
A.3|Patterns and Software: Essential Concepts and Terminology, B. Appleton||S04|Patterns
A.3|Re-usable Asset Specification (OMG)||S04|Reuse
A.3|Service Component Architecture Specification (OSOA)||S10|SOA
A.3|Service Data Objects Specification (OSOA)||S10|SOA data
A.3|Software Process Engineering Metamodel (OMG)||S03|Metamodel
A.3|Systems Modeling Language (SysML)||S04|Systems modelling
A.3|The Art of Systems Architecting, Rechtin and Maier||S01|Systems architecture
A.3|The Oregon Experiment, C. Alexander||S04|Patterns
A.3|The Timeless Way of Building, C. Alexander||S04|Patterns
A.3|The Zachman Framework||S01|Architecture framework
A.3|UML Profile and Metamodel for Services (UPMS) RFP||S10|Services modelling
A.3|Unified Modeling Language (UML) Specification||S04|Modelling""".split("\n")
write("togaf_references",["Group","Referenced document (Appendix A)","Open Group ID","Stream","What this template uses it for"],
      [(g,t,i,SN[s],u) for g,t,i,s,u in (l.split("|") for l in A)])
print(len(B),"glossary;",len(C),"acronyms;",len(A),"references")
