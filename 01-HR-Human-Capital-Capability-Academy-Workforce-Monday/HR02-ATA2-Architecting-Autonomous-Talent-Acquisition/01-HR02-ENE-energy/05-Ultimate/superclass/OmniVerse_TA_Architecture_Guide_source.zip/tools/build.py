#!/usr/bin/env python3
"""Paperless Architecture Initiative: build the online Document, Deck and Workbook from Markdown + CSV.
Run from the repository root:  python tools/build.py
Source of truth: docs/*.md (text) and data/*.csv (registers). Output: site/"""
import csv, html, json, os, re, shutil, datetime, sys
import markdown

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
REPO = os.environ.get("PAI_REPO", "nbnayak88/paperless-architecture-initiative")
CFG = json.load(open("config.json", encoding="utf-8")) if os.path.exists("config.json") else {}
CFG.setdefault("programme","Paperless Architecture Initiative"); CFG.setdefault("subject","Solution"); CFG.setdefault("org","SuccessLabs Academy"); CFG.setdefault("tagline",""); CFG.setdefault("region",""); CFG.setdefault("version","v3.0")
VERSION = CFG["version"]
PROG = CFG["programme"]
BUILD = datetime.date.today().isoformat()
SITE = "site"

# ---------------------------------------------------------------- data
def seed():
    ns = {}
    exec(open("tools/data.py", encoding="utf-8").read(), ns)
    os.makedirs("data", exist_ok=True)
    for name, (cols, rows) in ns["D"].items():
        with open(f"data/{name}.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f); w.writerow(cols); w.writerows(rows)

if not os.path.exists("data/requirements.csv"):
    seed()
TITLES = {
 "requirements":"Requirements","stakeholders":"Stakeholders","principles":"Principles","capabilities":"Capabilities",
 "value_stream":"Value stream","processes":"Processes","business_rules":"Business rules","data_entities":"Data entities",
 "data_dictionary":"Data dictionary","dq_rules":"DQ rules","dmbok_areas":"DMBOK areas","components":"Components",
 "interfaces":"Interfaces","tech_standards":"Tech standards","adr":"Decisions (ADR)","kpis":"KPIs","risks":"Risks",
 "work_packages":"Work packages","gap_analysis":"Gap analysis","raci":"RACI","crosswalk":"Crosswalk",
 "integration_patterns":"Integration patterns","partner_categories":"Partner categories (28)","partner_types":"Partner types","partner_selection":"Partner selection scorecard","ai_controls":"Responsible-AI controls","activate_plan":"SAP Activate 21-day plan","activate_map":"SAP Activate phase map",
 "ba_checklist":"QA checklist","glossary":"Glossary",
 "streams":"12 streams","stream_lens":"Stream lens","togaf_intro":"TOGAF core concepts","togaf_concepts":"TOGAF terms",
 "stream_matrix":"Stream matrix","stream_counts":"Stream counts",
 "togaf_glossary":"TOGAF glossary (App B)","togaf_acronyms":"TOGAF acronyms (App C)","togaf_references":"TOGAF references (App A)","chapter_map":"Chapter map: ADM phase and streams","adm_streams":"ADM phases by architecture stream","bizbok":"BA Guild (BIZBOK)","bizbok_domains":"BIZBOK domains","p4v_shocks":"9P4V transformation shocks","p4v_spine":"9P4V stages","p4v_pillars":"9P4V pillars","p4v_stages":"9P4V 18-stage journey","p4v_pack":"9P4V transformation pack","p4v_skills":"9P4V skills ledger","p4v_score":"9P4V score","p4v_levels_score":"9P4V capability levels","p4v_levels":"9P4V learning levels","p4v_gate":"9P4V quality gate","p4v_streams":"9P4V by stream","p4v_example":"9P4V worked example","p4v_lens":"9P4V chapter lens","bizbok_practice":"BIZBOK practice and alignment detail","bizbok_sector_example":"BIZBOK ten-element example","bizbok_strategy_terms":"BIZBOK strategy terms","bizbok_principles":"BIZBOK principles","bizbok_strategy_execution":"BIZBOK strategy execution","bizbok_scenarios":"BIZBOK scenarios"}
D = {}
for name in TITLES:
    with open(f"data/{name}.csv", newline="", encoding="utf-8") as f:
        r = list(csv.reader(f))
    D[name] = (r[0], r[1:])

def e(s): return html.escape(str(s), quote=True)

# ---------------------------------------------------------------- html bits
def pill(col, v):
    if col == "MoSCoW": return f'<span class="pill m-{e(v)}">{e(v)}</span>'
    if col == "Status": return f'<span class="pill s-{e(v.replace(" ","-"))}">{e(v)}</span>'
    if col == "Score" and v.isdigit():
        n = int(v); c = "hi" if n >= 15 else "md" if n >= 8 else "lo"
        return f'<span class="pill r-{c}">{n}</span>'
    if v in ("P","S") and col not in ("ID","Ref"): return f'<span class="pill x-{v}">{v}</span>'
    return None
def table_html(cols, rows, cls="dt"):
    h = "".join(f"<th>{e(c)}</th>" for c in cols)
    body = ""
    for r in rows:
        tds = ""
        for c, v in zip(cols, r):
            p = pill(c, v)
            tds += f"<td>{p if p else (e(v) if str(v).strip() else '<span class=\"na\">n/a</span>')}</td>"
        body += f"<tr>{tds}</tr>"
    return f'<div class="tablewrap"><table class="{cls}"><thead><tr>{h}</tr></thead><tbody>{body}</tbody></table></div>'

def macro(m):
    kind, arg = m.group(1), m.group(2)
    if kind == "cfg": return e(CFG.get(arg.strip(), arg))
    parts = arg.split("|")
    if kind == "img":
        fn = parts[0]; cap = parts[1] if len(parts) > 1 else ""
        return f'\n\n<figure><img src="assets/{e(fn)}" alt="{e(cap)}" loading="lazy"><figcaption>{e(cap)}</figcaption></figure>\n\n'
    name = parts[0]; opts = {}
    for p in parts[1:]:
        k, _, v = p.partition("="); opts[k.strip()] = v
    cols, rows = D[name]
    if "filter" in opts:
        fc, _, fv = opts["filter"].partition(":")
        i = cols.index(fc); rows = [r for r in rows if r[i] == fv]
    if "cols" in opts:
        want = [c.strip() for c in opts["cols"].split(",")]
        idx = [cols.index(c) for c in want]
        rows = [[r[i] for i in idx] for r in rows]; cols = want
    return "\n\n" + table_html(cols, rows) + "\n\n"

# ---------------------------------------------------------------- layout
CSS = open("tools/site.css", encoding="utf-8").read()
def layout(title, body, active, sidebar="", extra_head="", cls=""):
    nav = "".join(f'<a href="{h}" class="{"on" if active==k else ""}">{t}</a>' for k, h, t in
                  [("home","index.html","Home"),("doc","00-about.html","Document"),("deck","deck.html","Deck"),("wb","workbook.html","Workbook"),("hb","handbook.html","Handbook")])
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{e(title)} · {e(PROG)}</title><link rel="icon" href="assets/favicon.png"><style>{CSS}</style>{extra_head}</head>
<body class="{cls}"><header class="top"><a class="brand" href="index.html"><img src="assets/logo.png" alt="SuccessLabs Academy logo"><span><b>{e(PROG)}</b><small>{e(CFG["org"])}</small></span></a>
<button class="menu" aria-label="Menu" onclick="document.body.classList.toggle('navopen')">☰</button><nav>{nav}<a href="https://github.com/{REPO}" target="_blank" rel="noopener">Repository ↗</a></nav></header>
{body}
<footer class="foot"><span>{e(CFG["org"])} · Reusable architecture template · No client data</span><span>{VERSION} · built {BUILD}</span></footer>
<script>{open("tools/site.js", encoding="utf-8").read()}</script></body></html>"""

# ---------------------------------------------------------------- document
files = sorted(f for f in os.listdir("docs") if re.match(r"\d\d-.*\.md$", f))
chapters = []
for f in files:
    txt = open(f"docs/{f}", encoding="utf-8").read()
    t = re.search(r"^# (.+)$", txt, re.M).group(1)
    chapters.append((f, f[:-3] + ".html", f[:2], t))

os.makedirs(SITE, exist_ok=True)
for f in os.listdir(SITE):
    if f.endswith(".html"): os.remove(os.path.join(SITE, f))
CMAP = {r[0]: r for r in D["chapter_map"][1]}
def sidebar(active):
    li = ""; part = None
    for _, h, n, t in chapters:
        pt = CMAP.get(n, ["", "", ""])[2]
        if pt != part:
            li += f'<div class="sidehead">{e(pt)}</div>'; part = pt
        li += f'<a class="{"on" if h==active else ""}" href="{h}"><i>{n if n!="00" else "·"}</i>{e(t)}</a>'
    return f'<aside class="side">{li}<div class="sidehead">Also online</div><a href="deck.html"><i>▶</i>Slide deck</a><a href="workbook.html"><i>▦</i>Workbook</a></aside>'
NOTES = '<div class="notes"><h4>Notes</h4><div class="nl"></div><div class="nl"></div><div class="nl"></div><div class="nl"></div></div>'
def ctx(n):
    r = CMAP.get(n)
    if not r or n == "00": return ""
    return ('<div class="ctx"><span><b>ADM phase</b> ' + e(r[3]) + '</span><span><b>Lead streams</b> ' + e(r[4]) + '</span><span><b>Supporting</b> ' + e(r[5]) +
            '</span><span><b>9P4V</b> ' + e(r[6]) + '</span><span><b>Standards</b> ' + e(r[7]) + '</span></div>')
for i, (f, out, n, t) in enumerate(chapters):
    txt = open(f"docs/{f}", encoding="utf-8").read()
    txt = re.sub(r"\{\{(csv|img|cfg):([^}]*)\}\}", macro, txt)
    txt = re.sub(r"\]\((\d\d-[a-z-]+)\.md(#[^)]*)?\)", r"](\1.html\2)", txt)
    md = markdown.Markdown(extensions=["tables", "fenced_code", "toc", "sane_lists"], extension_configs={"toc": {"toc_depth": "2-3"}})
    body = md.convert(txt)
    body = re.sub(r"<h1[^>]*>.*?</h1>", "", body, count=1, flags=re.S)
    prev = f'<a class="pn" href="{chapters[i-1][1]}">← {e(chapters[i-1][3])}</a>' if i else "<span></span>"
    nxt = f'<a class="pn r" href="{chapters[i+1][1]}">{e(chapters[i+1][3])} →</a>' if i < len(chapters) - 1 else "<span></span>"
    toc = f'<details class="otp"><summary>On this page</summary>{md.toc}</details>' if len(md.toc_tokens) > 2 else ""
    main = f'<main class="doc"><div class="crumb">Chapter {n if n!="00" else "0"} · <a href="https://github.com/{REPO}/edit/main/docs/{f}" target="_blank" rel="noopener">Edit this page online ↗</a></div><h1>{e(t)}</h1>{ctx(n)}{toc}{body}{NOTES}<div class="pnav">{prev}{nxt}</div></main>'
    open(f"{SITE}/{out}", "w", encoding="utf-8").write(layout(t, f'<div class="wrap">{sidebar(out)}{main}</div>', "doc"))

# ---------------------------------------------------------------- handbook (verbatim, own tab)
if os.path.exists("handbook/handbook.md"):
    hmd = markdown.Markdown(extensions=["tables", "sane_lists", "toc"], extension_configs={"toc": {"toc_depth": "1-2"}})
    hbody = hmd.convert(open("handbook/handbook.md", encoding="utf-8").read())
    side = "".join(f'<a href="#{t["id"]}"><i>·</i>{e(re.sub(r"<[^>]+>", "", t["name"]))}</a>' for t in hmd.toc_tokens)
    pdf = "handbook.pdf" if os.path.exists("handbook/SuccessLabs_Global_Architect_Handbook.pdf") else ""
    bar = ('<div class="hbbar"><span>SuccessLabs Academy · Global Architect Handbook · Edition 1.0</span>' +
           (f'<a class="btn" href="{pdf}" download>Download as PDF</a>' if pdf else "") + '<button class="btn" onclick="window.print()">Print</button></div>')
    hmain = f'<main class="doc hb">{bar}{hbody}<div class="notes"><h4>Notes</h4><div class="nl"></div><div class="nl"></div><div class="nl"></div><div class="nl"></div></div></main>'
    open(f"{SITE}/handbook.html", "w", encoding="utf-8").write(layout("Global Architect Handbook", f'<div class="wrap"><aside class="side"><div class="sidehead">Handbook</div>{side}</aside>{hmain}</div>', "hb"))
    if pdf: shutil.copy("handbook/SuccessLabs_Global_Architect_Handbook.pdf", f"{SITE}/handbook.pdf")

# ---------------------------------------------------------------- stats
def n(name): return len(D[name][1])
req = D["requirements"][1]
stats = [(len(D["streams"][1]), "architecture streams"), (len(D["togaf_concepts"][1]) + len([r for r in D["togaf_intro"][1] if r[0].count(".") == 1]), "TOGAF items covered"), (len(req), "requirements"), (n("components"), "components"), (n("data_entities"), "data entities"), (n("dq_rules"), "quality rules"),
         (n("interfaces"), "interfaces"), (n("risks"), "risks")]

# ---------------------------------------------------------------- home
cards = [("Document", "00-about.html", f"Business requirements and high-level architecture, {len(chapters)} chapters aligned to TOGAF, BABOK and DAMA-DMBOK2, with all 12 architecture streams.", "Read"),
         ("Deck", "deck.html", "Slide deck in the browser. Arrow keys to move, F for full screen, O for overview.", "Present"),
         ("Workbook", "workbook.html", "Registers and matrices you can search, sort and filter, with a live dashboard.", "Explore"),
         ("Handbook", "handbook.html", "The SuccessLabs Academy Global Architect Handbook, read online. A PDF copy is available on the page.", "Read")]
home = f"""<main class="home"><section class="hero"><img src="assets/logo.png" alt="SuccessLabs Academy logo"><div><h1>{e(PROG)}</h1>
<p class="lead">Architecture created, reviewed, approved and used <b>online</b>, from one versioned source. Nothing to upload. Nothing to download.</p>
<p class="sub">Reference subject: <b>{e(CFG["subject"])}</b>. {e(CFG["tagline"])}</p></div></section>
<section class="cards">{"".join(f'<a class="card" href="{h}"><h3>{t}</h3><p>{d}</p><span>{b} →</span></a>' for t, h, d, b in cards)}</section>
<section class="stats">{"".join(f'<div><b>{a}</b><span>{b}</span></div>' for a, b in stats)}</section>
<section class="fw"><h2>Built on recognised standards</h2><div class="badges"><span>TOGAF® 10 ADM</span><span>BABOK® v3 · IIBA Business Analysis Standard</span><span>DAMA-DMBOK2 (11 knowledge areas)</span><span>Business Architecture Guild BIZBOK® · quality gates, DoR/DoD</span><span>9P4V Framework · Vision, Value, Victory, Venture (Nayak, 2025)</span><span>TOGAF Introduction: all 18 core concepts, 89 terms and Appendices A to C covered across 12 streams</span></div></section>
<section class="streams"><h2>9P4V: the transformation spine</h2><div class="sgrid" style="grid-template-columns:repeat(4,1fr)">{"".join(f'<a href="03-9p4v-framework.html" title="{e(r[2])}"><i>{e(r[0])}</i><span><b>{e(r[1])}</b><br><small>{e(g)}</small></span></a>' for r, g in zip(D["p4v_spine"][1], ["Policy · Portfolio · Program","Platform · Product · Process","People · Practice · Project","Sustain · Scale · Replicate"]))}</div></section>
<section class="streams"><h2>Twelve architecture streams</h2><div class="sgrid">{"".join(f'<a href="02-architecture-streams.html" title="{e(r[2])}"><i>{e(r[0][1:])}</i>{e(r[1])}</a>' for r in D["streams"][1])}</div></section>
<section class="chap"><h2>Chapters</h2><ol>{"".join(f'<li><a href="{h}"><i>{nn}</i>{e(t)}</a></li>' for _, h, nn, t in chapters)}</ol></section></main>"""
open(f"{SITE}/index.html", "w", encoding="utf-8").write(layout("Home", home, "home"))

# ---------------------------------------------------------------- workbook
sheets = {k: {"title": TITLES[k], "cols": D[k][0], "rows": D[k][1]} for k in TITLES}
wb = f"""<main class="wb"><div class="wbbar"><div id="tabs" role="tablist"></div></div><div id="sheet"></div></main>
<script>window.WB={json.dumps(sheets, ensure_ascii=False)};window.REPO={json.dumps(REPO)};</script><script>{open("tools/workbook.js", encoding="utf-8").read()}</script>"""
open(f"{SITE}/workbook.html", "w", encoding="utf-8").write(layout("Workbook", wb, "wb", cls="wbpage"))

# ---------------------------------------------------------------- deck
exec(open("tools/deck.py", encoding="utf-8").read())
slides = make_slides(D, stats)
deck = f"""<main class="deck"><div id="stage">{"".join(slides)}</div><div class="dbar"><button id="prev" aria-label="Previous">◀</button><span id="count"></span><button id="next" aria-label="Next">▶</button><button id="ov" title="Overview (O)">▦</button><button id="fs" title="Full screen (F)">⛶</button></div><div id="prog"></div></main>
<script>{open("tools/deck.js", encoding="utf-8").read()}</script>"""
open(f"{SITE}/deck.html", "w", encoding="utf-8").write(layout("Deck", deck, "deck", cls="deckpage"))

# ---------------------------------------------------------------- data copy + housekeeping
shutil.rmtree(f"{SITE}/data", ignore_errors=True); shutil.copytree("data", f"{SITE}/data")
shutil.rmtree(f"{SITE}/assets", ignore_errors=True); shutil.copytree("assets", f"{SITE}/assets")
open(f"{SITE}/.nojekyll", "w").close()
print(f"built {len(chapters)} chapters, deck ({len(slides)} slides), workbook ({len(sheets)} sheets) -> {SITE}/")
