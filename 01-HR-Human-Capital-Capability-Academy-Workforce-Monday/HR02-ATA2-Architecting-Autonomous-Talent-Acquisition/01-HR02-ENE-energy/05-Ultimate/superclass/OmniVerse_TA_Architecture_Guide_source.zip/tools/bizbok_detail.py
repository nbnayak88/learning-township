#!/usr/bin/env python3
"""Authors the detailed BA Guild (BIZBOK) registers: domains, principles, strategy execution, scenarios.
Own-words descriptions based on the guide's Part 1 and section 2.1. Run after bizbok_data.py."""
import csv, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SN = {"S01":"Enterprise","S02":"Business","S03":"Data","S04":"Application","S05":"Technology","S06":"AI","S07":"Security","S08":"UI/UX","S09":"Infrastructure","S10":"Integration","S11":"Domain","S12":"Industry"}
def sn(s): return ", ".join(SN[x] for x in s.split(",") if x)
def write(name, cols, rows):
    with open(f"{ROOT}/data/{name}.csv","w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(cols); w.writerows(rows)

# domain|kind|meaning|section|template register|primary|supporting
DOM = """Capabilities|Core|What the business can do, independent of who does it or how.|2.2|capabilities|S02|S01,S11
Organization|Core|Business units, roles, partners and locations that perform capabilities.|2.3|stakeholders; raci|S02|S01
Information|Core|Business concepts the business needs to know about, independent of systems.|2.5|data_entities; data_dictionary|S03|S02
Value Streams|Core|End-to-end series of stages that deliver value to a stakeholder.|2.4|value_stream|S02|S11
Stakeholders|Extended|Customers, partners and internal parties who give or receive value.|2.8|stakeholders|S02|S01
Strategies|Extended|Goals, objectives and courses of action the business pursues.|2.1|principles; requirements (business level)|S01|S02
Policies|Extended|Rules and regulations that constrain or steer the business.|2.9|business_rules|S12|S11,S07
Products|Extended|What the business offers, with entitlements.|2.7|capabilities (add a products register)|S02|S12
Initiatives|Extended|Change efforts that move the business toward its objectives.|2.6|work_packages; gap_analysis|S01|S02
Metrics|Extended|Measures of performance tied to objectives and capabilities.|3.7|kpis|S02|S01""".split("\n")
write("bizbok_domains",["Domain","Kind","Meaning in plain words","BIZBOK section","Template register","Primary stream","Supporting streams"],
      [(d,k,m,s,r,SN[p],sn(x)) for d,k,m,s,r,p,x in (l.split("|") for l in DOM)])

PR = """1|Business architecture is about the business.|Describe capabilities, value and information in business terms; do not start from systems.|Chapters 7, 8, 10 and 14 are written in business language; technology comes later.|S02
2|Business architecture's scope is the scope of the business.|Include the whole ecosystem, with customers, partners and outsourced capabilities, not just internal units.|Stakeholders and value stream cover external parties.|S01
3|Business architecture is not prescriptive.|The guide gives a framework to adapt, not a fixed method or tool.|The template is configurable; add or drop registers.|S01
4|Business architecture is iterative.|Build in passes and refine; do not wait for completeness.|Versioned registers, definition of done, gates.|S01
5|Business architecture is reusable.|Content built once serves many scenarios and initiatives.|One knowledgebase feeds document, deck and workbook.|S01
6|Business architecture is not about the deliverables.|The value is shared understanding and better decisions, not the diagrams themselves.|Gates test whether decisions were made, not only whether artefacts exist.|S01""".split("\n")
write("bizbok_principles",["No.","Core principle","Meaning in plain words","How this template applies it","Stream"],
      [(n,t,m,a,SN[s]) for n,t,m,a,s in (l.split("|") for l in PR)])

# step|action|template artefact|TOGAF ADM phase|stream
SE = """1 Establish business strategy|Business performance assessment|KPI register baseline|Preliminary, A|S02
1 Establish business strategy|Strategy definition|Vision chapter|A|S01
1 Establish business strategy|Objective definition|Business requirements, objectives|A|S02
1 Establish business strategy|Metric definition|KPI register|A|S02
1 Establish business strategy|Course of action definition|Gap analysis options|A, E|S01
1 Establish business strategy|Objective and metric matching|Requirements to KPI trace|A|S02
1 Establish business strategy|Objective and course of action matching|Requirements to work package trace|A, E|S01
1 Establish business strategy|Objective trade-off analysis|Decision records (ADR)|A|S01
1 Establish business strategy|Objective prioritisation|MoSCoW priority in requirements|A|S02
1 Establish business strategy|Strategy dissemination|Deck and document|A|S01
2 Assess business impact|Business scenario definition|Scope statement|A|S02
2 Assess business impact|Value stream impact analysis|Value stream register|B|S02
2 Assess business impact|Capability impact analysis|Capabilities register|B|S02
2 Assess business impact|Information impact analysis|Data entities|C (Data)|S03
2 Assess business impact|Business unit impact analysis|Stakeholders and RACI|B|S02
2 Assess business impact|Product impact analysis|Capabilities and services|B|S02
2 Assess business impact|Business and IT architecture impact analysis|Components and interfaces|C, D|S04
2 Assess business impact|Current state architecture visualisation|Baseline in gap analysis; context diagram|B, C, D|S01
3 Architect business solution|Architecture change analysis|Gap analysis|B, C, D|S01
3 Architect business solution|Target state architecture visualisation|Layered architecture, capability map|B, C, D|S01
3 Architect business solution|Business-driven IT architecture definition|Components, tech standards|C, D|S04
3 Architect business solution|Target state option analysis and finalisation|Decision records|E|S01
3 Architect business solution|Case management design|Business rules and case lifecycle|B|S11
3 Architect business solution|Business process design|Processes register|B|S02
3 Architect business solution|Current to target transformation analysis|Transition architectures|E, F|S01
4 Establish initiative plans|Initiative definition|Work packages|E, F|S01
4 Establish initiative plans|Initiative measurement criteria|KPIs and acceptance criteria|F|S02
4 Establish initiative plans|Objective to initiative mapping|Requirements to work package trace|F|S01
4 Establish initiative plans|Initiative trade-off and decision definition|Decision records|F|S01
4 Establish initiative plans|Initiative mapping|Roadmap by wave|F|S01
5 Deploy solution|Deployment team engagement|RACI and governance|G|S01
5 Deploy solution|Deliverable deployment|Implementation governance gates|G|S01
5 Deploy solution|Transformation management|Change management gate|H|S01
5 Deploy solution|Success evaluation|Benefits review gate and KPIs|H|S02""".split("\n")
write("bizbok_strategy_execution",["Step","Business architecture action","Template artefact","TOGAF ADM phase","Stream"],
      [(a,b,c,d,SN[s]) for a,b,c,d,s in (l.split("|") for l in SE)])

# scenario|what it asks|template support|primary|supporting
SC = """Investment analysis|Which initiatives give most value for cost?|Gap analysis, work packages, KPIs|S01|S02
Shift to customer-centric business model|How do we organise around customer value?|Value stream, journeys, capabilities|S08|S02
Merger and acquisition analysis|How do two capability sets and organisations combine?|Capability and organisation maps, gap analysis|S01|S02,S12
New product or service rollout|Which capabilities and policies does it need?|Capabilities, requirements, policy rules|S02|S12
Globalisation|What changes by country?|Country profile, regulatory obligations|S12|S02
Capability outsourcing|Which capabilities can a partner run?|Capability map, interfaces, RACI|S02|S10
Supply chain streamlining|Where do value stages waste time?|Value stream, KPIs|S02|S11
Divestiture|What can be separated cleanly?|Capability and data ownership|S01|S03
Regulatory compliance|Which obligations apply to which capabilities?|Policy mapping, business rules|S12|S07
Change management|Who and what is affected?|Stakeholders, impact analysis|S02|S01
Operational cost reduction|Which capabilities cost most for least value?|Capability heat map, KPIs|S02|S01
Joint venture deployment|How do partners fit the value stream?|Stakeholders, interfaces, governance|S01|S10
IT portfolio investment analysis|Which applications support which capabilities?|Components to capabilities map|S04|S01
Digital transformation|Which capabilities become digital and how?|Digital streams: AI, UI/UX, integration|S01|S06,S08,S10
Digital twin deployment|What must be modelled to mirror the business?|Capability, value and information models|S06|S03,S05""".split("\n")
write("bizbok_scenarios",["Scenario (guide Part 4)","Question it answers","Template support","Primary stream","Supporting streams"],
      [(a,b,c,SN[p],sn(x)) for a,b,c,p,x in (l.split("|") for l in SC)])
print("domains",len(DOM),"principles",len(PR),"strategy actions",len(SE),"scenarios",len(SC))
