#!/usr/bin/env python3
"""Authors data/streams.csv, togaf_intro.csv, togaf_concepts.csv and the derived stream_matrix.csv / stream_counts.csv.
Definitions are written in our own words (no copied text). Numbering follows the official TOGAF Standard, 10th Edition,
Introduction and Core Concepts: chapter 3 (Core Concepts) and chapter 4 (Definitions). Edit here or edit the CSVs directly."""
import csv, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.makedirs(f"{ROOT}/data", exist_ok=True)

STREAMS = [
 ("S01","Enterprise","Align strategy, capabilities, change and governance across the whole organisation.","Vision, principles, capability map, roadmap, governance, repository, architecture practice.","Architecture vision; principles catalogue; capability map; roadmap; governance model","Preliminary, A, E, F, G, H","Chief or enterprise architect","01, 06, 10, 15, 16"),
 ("S02","Business","Describe what the organisation does: capabilities, value streams, processes, rules, organisation and information needs.","Business model, value streams, capabilities, processes, business rules, stakeholders, requirements.","Capability map; value stream; process catalogue; business rules; requirements","A, B, Requirements","Business architect or analyst","07, 08, 10, 14"),
 ("S03","Data","Define how data is modelled, owned, governed, secured, integrated and used for decisions.","Conceptual and logical data model, dictionary, quality rules, master and reference data, metadata, lifecycle.","Data entities; data dictionary; DQ rules; DMBOK area targets","C (Data), Requirements","Data architect, data owner","05, 11"),
 ("S04","Application","Define the applications and components that deliver business capabilities, and how they fit together.","Component model, services, application portfolio, building blocks, solution design.","Component catalogue; ABB/SBB list; context and layered diagrams","C (Application), E","Application or solution architect","12"),
 ("S05","Technology","Define the technology platforms, standards and services that applications and data run on.","Technology standards, platforms, services, patterns, lifecycle of technology choices.","Technology standards; platform services; decision records","D, E","Technology architect","13"),
 ("S06","AI","Define when and how machine learning, analytics and generative AI are used responsibly.","Use-case selection, model lifecycle, data readiness, human oversight, evaluation, AI risk and ethics.","AI use-case register; model lifecycle; AI principles; evaluation criteria","B, C, D, G","AI architect, data scientist","02, 11"),
 ("S07","Security","Protect information, services and people: identity, access, privacy, resilience, assurance.","Security principles, classification, access model, controls, threat and risk view, audit trail.","Classification scheme; access matrix; controls; security risks","All phases","Security architect","02, 13, 16"),
 ("S08","UI/UX","Design how people experience the solution: journeys, interfaces, accessibility, content and feedback.","Personas, journeys, interaction patterns, accessibility, design system, usability testing.","Personas; journey map; UX standards; accessibility criteria","B, C, Requirements","UX architect or designer","02, 08"),
 ("S09","Infrastructure","Provide the hosting, networks, compute, storage, resilience and operations the solution runs on.","Environments, hosting options, networks, capacity, availability, disaster recovery, operations.","Environment and hosting model; availability targets; capacity plan","D, E, G","Infrastructure architect","13"),
 ("S10","Integration","Connect systems, partners and data reliably: interfaces, APIs, events, messaging and exchange standards.","Interface catalogue, integration patterns, API standards, data exchange, interoperability.","Interface catalogue; integration patterns; API standards","C, D","Integration architect","12"),
 ("S11","Domain","Capture domain-specific rules, vocabulary and reference content for one functional area, for example network operations or regulation.","Domain reference models, rules, glossaries, standards, domain-specific building blocks.","Domain glossary; business rules; domain reference model","B, C","Domain architect or subject expert","08, 10"),
 ("S12","Industry","Apply sector-level reference models, regulation, standards and practices so the architecture fits the industry and country.","Industry reference architectures, regulatory obligations, country configuration, sector patterns.","Regulatory obligations; country profile; industry reference mapping","Preliminary, A, B","Industry architect","04, 06"),
]

SC = {s[0]: s[1] for s in STREAMS}
ORDER = [s[0] for s in STREAMS]

# --------------------------------------------------------------- chapter 3: Core Concepts  (ref, topic, meaning, how applied, where, primary, supporting)
INTRO = [
 ("3.1","What is the TOGAF Standard?","A shared framework of method, content and guidance for designing and governing enterprise architecture.","This template is structured around it: chapters follow the ADM and registers follow the content framework.","Ch 0, 1","S01","S02,S03,S04,S05"),
 ("3.2","What is Architecture in the Context of the TOGAF Standard?","Architecture means both the structure of an enterprise or system and the description of that structure over time.","Every chapter describes structure (what is) and a plan for change (what will be).","Ch 1","S01","S02,S03,S04,S05,S10"),
 ("3.3","What Kind of Architecture Does the TOGAF Standard Deal With?","Four architecture domains: business, data, application and technology, plus the content that describes them.","Chapters 10 to 13 hold the four domains; chapter 2 adds eight more streams.","Ch 2, 10, 11, 12, 13","S01","S02,S03,S04,S05"),
 ("3.4","Architecture Development Method","A repeatable cycle from vision to governance, with requirements management at the centre.","Chapter 15 and the lifecycle diagram show the ADM applied; the crosswalk ties gates to phases.","Ch 1, 5, 15","S01","S02,S03,S04,S05,S10"),
 ("3.5","Enterprise Architecture Services","The set of services an architecture team offers the organisation, from support to planning to practice building.","Chapter 1 lists each service with the template artefact that delivers it.","Ch 1, 18","S01","S02,S12"),
 ("3.5.1","Enterprise Support Services","Services that keep the enterprise aligned: strategy support, standards, reuse and portfolio advice.","Principles, standards and decision records supply this service.","Ch 1, 6, 13","S01","S05,S12"),
 ("3.5.2","Design Support Services","Services that help projects design solutions that fit the architecture.","Component catalogue, patterns and building blocks are the design support kit.","Ch 1, 12","S04","S05,S10,S08"),
 ("3.5.3","Development Support Services","Services that guide build teams: standards, reviews and compliance checks.","Quality gates, definition of ready and done, and the QA checklist.","Ch 5, 16","S04","S05,S07,S10"),
 ("3.5.4","Requirements Elicitation and Understanding Services","Services that draw out, structure and validate what stakeholders need.","The BABOK approach, requirements register and stakeholder analysis.","Ch 7, 8","S02","S08,S11"),
 ("3.5.5","Architecture Planning Services","Services that turn the target into a prioritised plan of change.","Gap analysis, work packages, transition architectures and roadmap.","Ch 14, 15","S01","S02,S09"),
 ("3.5.6","Enterprise Architecture Practice Development Support Services","Services that build and mature the architecture function itself.","Governance, RACI, maturity targets, and this template as a starter kit.","Ch 16, 18","S01","S12"),
 ("3.6","Deliverables, Artifacts, and Building Blocks","Deliverables are contracted outputs; artifacts are the models inside them; building blocks are reusable pieces.","Register rows are artifacts; each chapter is a deliverable; components are building blocks.","Ch 1, 12","S01","S04,S03"),
 ("3.7","Architecture Abstraction","Describing the same thing at increasing levels of detail: contextual, conceptual, logical, physical.","Section 1.5 maps each template artefact to its abstraction level.","Ch 1","S01","S03,S04,S05"),
 ("3.7.1","Contextual Abstraction Level","The setting: drivers, scope, actors and boundaries, before any design.","Vision, stakeholders and context diagram.","Ch 6, 12","S01","S02,S12"),
 ("3.7.2","Conceptual Abstraction Level","The main ideas and relationships, free of technology.","Capability map, conceptual data model, value stream.","Ch 10, 11","S02","S03,S11"),
 ("3.7.3","Logical Abstraction Level","A solution-neutral design: components, entities and rules without product choice.","Layered architecture, data dictionary, interface catalogue.","Ch 11, 12","S04","S03,S10"),
 ("3.7.4","Physical Abstraction Level","The concrete implementation: products, platforms, hosting, configuration.","Technology standards, hosting model, environments.","Ch 13","S05","S09,S10"),
 ("3.8","Architecture Principles","Short, durable rules that guide decisions, each with rationale and implications.","The principles register carries 13 principles across four domains.","Ch 6","S01","S02,S03,S04,S05,S07"),
 ("3.9","Interoperability","The ability of systems and organisations to exchange and use information.","Interface catalogue, exchange standards and integration patterns.","Ch 1, 12","S10","S03,S04,S12"),
 ("3.10","Enterprise Continuum","A way to classify architecture assets from generic to specific, and architecture to solution.","Section 1.2 positions every template artefact on the continuum.","Ch 1, 18","S01","S12,S04"),
 ("3.11","TOGAF Content Framework and Enterprise Metamodel","A structure for what architecture content exists and how the pieces relate.","Section 1.8 and the crosswalk register define our metamodel.","Ch 1","S01","S03"),
 ("3.11.1","Overview (Content Framework and Metamodel)","Why content needs a shared structure so views stay consistent.","Registers use stable IDs and trace columns.","Ch 1","S01","S03"),
 ("3.11.2","Content Framework","The catalogue of deliverables, artifacts and building blocks across the ADM.","Chapter 17 lists every artefact and its register.","Ch 1, 17","S01","S02,S03,S04,S05"),
 ("3.11.3","Enterprise Metamodel","The entities and relationships used to model an enterprise.","Entities: capability, process, data entity, component, interface, requirement, risk, work package; links by ID.","Ch 1","S03","S01,S02"),
 ("3.11.4","Developing the Enterprise Metamodel","Tailoring the metamodel to the organisation's needs.","Add columns or registers in data/, then extend the stream matrix.","Ch 18","S03","S01"),
 ("3.12","Establishing and Maintaining an Enterprise Architecture Capability","Setting up people, process, tools and governance to run architecture continuously.","Governance chapter, RACI, maturity targets, review cadence.","Ch 16, 18","S01","S12"),
 ("3.13","Establishing the Architecture Capability as an Operational Entity","Running architecture as an ongoing service with defined roles, funding and measures.","Operating model, KPIs and the paperless pipeline.","Ch 4, 16","S01","S09"),
 ("3.14","Using the TOGAF Standard with Other Frameworks","Combining TOGAF with BABOK, DAMA-DMBOK, ITIL, ArchiMate and others.","Crosswalk register aligns TOGAF, BABOK, DMBOK and BA-guild gates.","Ch 0, 1, 5","S01","S02,S03"),
 ("3.15","Using the TOGAF Framework with Different Architecture Styles","Applying the framework to styles such as service-oriented, event-driven, cloud-native and agile.","Section 1.6 covers styles and patterns, with SOA and service orientation.","Ch 1","S04","S05,S10"),
 ("3.16","Architecture Views and Viewpoints","Views show the architecture to specific stakeholders; viewpoints define how a view is built.","Section 1.8 lists viewpoints per stakeholder; deck and workbook are views.","Ch 1, 2","S01","S08,S02"),
 ("3.17","Enterprise Agility","Responding to change in small, safe, frequent steps while staying aligned.","Docs-as-code, incremental transitions and definition of done support agility.","Ch 4, 15","S01","S04,S09"),
 ("3.18","Risk Management","Identifying, assessing and treating risks to architecture work and its outcomes.","Risk register with likelihood, impact, score and heat map.","Ch 14, 16","S07","S01,S02,S06"),
]

# --------------------------------------------------------------- chapter 4: Definitions (ref, term, meaning, where, artefact, primary, supporting)
CON = [
 ("4.1","Abstraction","Leaving out detail so the essential idea is clear.","Ch 1.5","Four abstraction levels","S01","S03,S04,S05"),
 ("4.2","Actor","A person, team or system that takes part in a process.","Ch 10, 12","Stakeholders; context diagram","S02","S04,S08"),
 ("4.3","Application Architecture","The applications, their relationships and how they support the business.","Ch 12","Components; context and layered diagrams","S04","S10,S03"),
 ("4.4","Application Component","A modular, replaceable part of an application with defined interfaces.","Ch 12","Components register","S04","S10"),
 ("4.5","Application Platform","The technology on which applications are built and run.","Ch 13","Tech standards","S05","S04,S09"),
 ("4.6","Application Service","Functionality an application exposes to be used by others.","Ch 12","Components; interfaces","S04","S10"),
 ("4.7","Architectural Style","A family of design approaches sharing key traits, such as layered or event-driven.","Ch 1.6","Principles; ADR","S04","S05,S10"),
 ("4.8","Architecture","The fundamental structure of a system or enterprise and the rules guiding its change.","Ch 1.1","All registers","S01","S02,S03,S04,S05"),
 ("4.9","Architecture Building Block (ABB)","A reusable piece defined by required capability, not by product.","Ch 1.4, 12","Components (ABB column)","S04","S01,S05"),
 ("4.10","Architecture Continuum","The architecture side of the continuum, from foundation to organisation-specific.","Ch 1.2","Continuum table","S01","S12"),
 ("4.11","Architecture Development Method (ADM)","The step-by-step method for developing and governing architecture.","Ch 1.3, 15","Lifecycle; crosswalk","S01","S02,S03,S04,S05"),
 ("4.12","Architecture Domain","A major division of architecture: business, data, application, technology.","Ch 1.3, 2","Streams register","S01","S02,S03,S04,S05"),
 ("4.13","Architecture Framework","A foundation of structures and methods for building architectures.","Ch 0, 1","Crosswalk","S01","S12"),
 ("4.14","Architecture Governance","Directing and controlling architecture work and compliance.","Ch 16","RACI; gates","S01","S07,S06"),
 ("4.15","Architecture Landscape","A view of the architecture assets in use at a point in time.","Ch 1.3","Components; capabilities","S01","S04,S05"),
 ("4.16","Architecture Level","A level of detail used when scoping architecture work: strategic, segment, capability.","Ch 1.3","Scope table","S01","S02"),
 ("4.17","Architecture Model","A representation of part of the architecture for analysis or communication.","Ch 1.8","Diagrams; registers","S01","S02,S03,S04"),
 ("4.18","Architecture Partition","A split of the landscape to keep it manageable, by ownership or scope.","Ch 1.3","Streams; domains","S01","S11,S12"),
 ("4.19","Architecture Principle","An enduring rule guiding decisions, with rationale and implications.","Ch 6","Principles register","S01","S02,S03,S04,S05,S07,S06"),
 ("4.20","Architecture View","A representation of the architecture for a set of stakeholder concerns.","Ch 1.8","Document, deck, workbook views","S01","S08"),
 ("4.21","Architecture Viewpoint","The conventions that define how a view is constructed and read.","Ch 1.8","Viewpoint table","S01","S08"),
 ("4.22","Architecture Vision","A high-level picture of the target and the case for change.","Ch 6","Vision chapter; vision slide","S01","S02,S12"),
 ("4.23","Artifact","A specific architectural work product: catalogue, matrix or diagram.","Ch 1.4, 17","Each register and diagram","S01","S02,S03,S04"),
 ("4.24","Baseline","The current state used as the starting point for change.","Ch 14","Gap analysis","S02","S01,S05"),
 ("4.25","Boundaryless Information Flow","Information moving freely and securely across organisational boundaries.","Ch 1.7","Interfaces; exchange standards","S10","S03,S07,S12"),
 ("4.26","Building Block","A package of functionality defined to meet a need, reusable and combinable.","Ch 1.4","Components","S04","S05"),
 ("4.27","Business Architecture","The business strategy, governance, organisation and key processes.","Ch 10","Capabilities; processes; rules","S02","S11,S12"),
 ("4.28","Business Capability","What the business can do, independent of how or who.","Ch 10","Capabilities register","S02","S01,S11"),
 ("4.29","Business Function","A grouping of behaviour by a chosen criterion such as skill or ownership.","Ch 10","Capability map","S02","S11"),
 ("4.30","Business Governance","How the business is directed, controlled and held accountable.","Ch 16","RACI; policies","S02","S01,S07"),
 ("4.31","Business Model","How the organisation creates, delivers and captures value.","Ch 6, 10","Vision; value stream","S02","S01,S12"),
 ("4.32","Business Service","A service the business offers to customers or internally, with defined outcome.","Ch 10","Value stream; capabilities","S02","S04,S11"),
 ("4.33","Capability","An ability an organisation has, made of people, process and technology.","Ch 10","Capabilities register","S01","S02"),
 ("4.34","Capability Architecture","A detailed architecture for one capability, used for planning increments.","Ch 1.3","Work packages","S01","S02,S04"),
 ("4.35","Capability Increment","A distinct improvement step delivering part of a capability.","Ch 15","Work packages","S01","S02"),
 ("4.36","Communications and Stakeholder Management","Planning how to inform and involve stakeholders.","Ch 7","Stakeholders register","S02","S01,S08"),
 ("4.37","Concern","An interest a stakeholder has that the architecture must address.","Ch 1.8, 7","Stakeholders; viewpoints","S08","S02,S01"),
 ("4.38","Course of Action","A directed path chosen to reach a goal, linked to strategy.","Ch 14","Gap analysis; options","S01","S02"),
 ("4.39","Data Architecture","Structure of logical and physical data assets and their management.","Ch 11","Entities; dictionary; DQ rules","S03","S11,S07,S06"),
 ("4.40","Deliverable","A formally reviewed work product agreed with stakeholders.","Ch 1.4, 17","Chapters; gates","S01","S02"),
 ("4.41","Digital Architecture","Architecture of digital capabilities, platforms, data and experiences that run the enterprise.","Ch 1.9","AI, UI/UX, integration streams","S01","S06,S08,S10"),
("4.42","EA Landscape","The enterprise architecture landscape: the architecture assets across the whole enterprise, seen together.","Ch 1.3","Components; capabilities; streams","S01","S02,S04,S05,S12"),
 ("4.43","Enterprise","A collection of organisations with a common set of goals.","Ch 1.1, 6","Scope statement","S01","S12"),
 ("4.44","Enterprise Architecture Service","A service the architecture function provides to the organisation.","Ch 1.10","Services table","S01","S02"),
 ("4.45","Enterprise Continuum","The classification of architecture and solution assets from generic to specific.","Ch 1.2","Continuum table","S01","S12"),
 ("4.46","Foundation Architecture","Generic building blocks and standards usable by any organisation.","Ch 1.2","Tech standards","S01","S05"),
 ("4.47","Framework","A structure for building or organising something.","Ch 0","Crosswalk","S01","S12"),
 ("4.48","Gap","A difference between baseline and target needing action.","Ch 14","Gap analysis","S01","S02,S04"),
 ("4.49","Governance","The system by which an organisation is directed and controlled.","Ch 16","RACI","S01","S07"),
 ("4.50","Information","Data given meaning and context so it can be used.","Ch 11","Data dictionary","S03","S02"),
 ("4.51","Information Technology (IT)","Computing and communications used to handle information.","Ch 13","Tech standards","S05","S09"),
 ("4.52","Interoperability","The ability to exchange information and use it meaningfully.","Ch 1.7","Interfaces","S10","S03,S12"),
 ("4.53","Logical","A level of description independent of specific products.","Ch 1.5","Logical models","S04","S03,S05"),
 ("4.54","Metadata","Data that describes other data, including meaning, owner and quality.","Ch 11","Data dictionary","S03","S07,S06"),
 ("4.55","Metamodel","A model of the model: the entities and relationships allowed.","Ch 1.8","Crosswalk; column definitions","S03","S01"),
 ("4.56","Method","A defined way of doing something with steps and outputs.","Ch 7, 15","ADM; BABOK approach","S01","S02"),
 ("4.57","Modeling","Creating representations to understand and communicate a subject.","Ch 1.8","Diagrams","S01","S02,S03,S04"),
 ("4.58","Model Kind","A category of model, such as catalogue, matrix or diagram.","Ch 1.8","Register types","S01","S03"),
 ("4.59","Objective","A measurable aim that supports a goal.","Ch 6","Objectives slide; KPIs","S02","S01"),
 ("4.60","Pattern","A proven, reusable solution to a recurring design problem.","Ch 1.6","ADR; integration patterns","S04","S10,S05,S06"),
 ("4.61","Physical","A level of description tied to real products and infrastructure.","Ch 1.5","Tech standards; hosting model","S09","S05"),
 ("4.62","Principle","A qualitative rule guiding decisions.","Ch 6","Principles register","S01","S02,S03,S04,S05"),
 ("4.63","Product","A packaged offering that implements building blocks.","Ch 13","Tech standards","S05","S04"),
 ("4.64","Reference Model (RM)","A generic model describing a domain, reused to build specific architectures.","Ch 1.2","Domain and industry mapping","S12","S11,S01"),
 ("4.65","Requirement","A statement of need that a solution must meet.","Ch 8","Requirements register","S02","S08,S11"),
 ("4.66","Roadmap","A time-sequenced plan of change toward the target.","Ch 15","Work packages","S01","S02"),
 ("4.67","Role","The part an individual or group plays in a process or governance.","Ch 16","RACI","S02","S01,S07"),
 ("4.68","Segment Architecture","A detailed architecture of a part of the enterprise.","Ch 1.3","Work packages","S01","S02"),
 ("4.69","Service","A repeatable unit of function with defined interface and outcome.","Ch 1.6","Components; interfaces","S04","S10,S02"),
 ("4.70","Service Orientation","An approach that designs capability as loosely coupled services.","Ch 1.6","Principles; ADR","S04","S10"),
 ("4.71","Service-Oriented Architecture (SOA)","An architecture style built on service orientation.","Ch 1.6","Interfaces; patterns","S10","S04"),
 ("4.72","Service Portfolio","The managed set of services and their lifecycle.","Ch 1.6","Components; interfaces","S04","S10,S01"),
 ("4.73","Solution Architecture","The architecture of a specific solution meeting defined requirements.","Ch 12","Layered architecture","S04","S05,S10"),
 ("4.74","Solution Building Block (SBB)","A concrete, product-level building block that realises an ABB.","Ch 12, 13","Components (SBB column); tech standards","S04","S05"),
 ("4.75","Solutions Continuum","The solution side of the continuum, from common to implemented.","Ch 1.2","Continuum table","S04","S05"),
 ("4.76","Stakeholder","A person or group with an interest in the architecture.","Ch 7","Stakeholders register","S02","S01,S08"),
 ("4.77","Standards Library","A catalogue of standards the architecture must or should follow.","Ch 13","Tech standards","S05","S07,S10"),
 ("4.78","Strategic Architecture","A high-level, long-term view directing the organisation.","Ch 1.3","Vision; roadmap","S01","S12"),
 ("4.79","Target Architecture","The desired future state to be reached.","Ch 14, 15","Gap analysis","S01","S02,S04"),
 ("4.80","Taxonomy of Architecture Views","A classification of the kinds of architecture views.","Ch 1.8","Viewpoint table","S01","S08"),
 ("4.81","Technology Architecture","Logical software, hardware and network capabilities that support applications and data.","Ch 13","Tech standards","S05","S09,S07"),
 ("4.82","Technology Component","A specific technology building block, such as a database or runtime.","Ch 13","Tech standards","S05","S09"),
 ("4.83","Technology Service","Technical capability needed to support applications, such as messaging or identity.","Ch 13","Tech standards","S05","S07,S10"),
 ("4.84","Transition Architecture","An intermediate state between baseline and target.","Ch 15","Work packages","S01","S09"),
 ("4.85","Value Stream","An end-to-end series of steps that creates value for a stakeholder.","Ch 10","Value stream","S11","S02,S12"),
 ("4.86","View","What a given stakeholder sees of the architecture.","Ch 1.8","Document, deck, workbook","S01","S08"),
 ("4.87","Viewpoint","The pattern for building a view for a set of concerns.","Ch 1.8","Viewpoint table","S01","S08"),
 ("4.88","Viewpoint Library","A collection of reusable viewpoints.","Ch 1.8","Viewpoint table","S01","S08"),
 ("4.89","Work Package","A set of actions delivering part of a capability increment.","Ch 15","Work packages","S01","S02,S04"),
]

def write(name, cols, rows):
    with open(f"{ROOT}/data/{name}.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(cols); w.writerows(rows)

def names(ids): return ", ".join(SC[i] for i in ids.split(",") if i)

write("streams", ["ID","Stream","Purpose","Scope","Key artefacts","TOGAF ADM phases","Typical owner","Chapters"], STREAMS)
write("togaf_intro", ["Ref","Core concept (chapter 3)","Meaning in plain words","How this template applies it","Where","Primary stream","Supporting streams"],
      [(r, t, m, a, w, SC[p], names(s)) for r, t, m, a, w, p, s in INTRO])
write("togaf_concepts", ["Ref","Term (chapter 4)","Meaning in plain words","Where covered","Template artefact","Primary stream","Supporting streams"],
      [(r, t, m, w, a, SC[p], names(s)) for r, t, m, w, a, p, s in CON])

# derived matrix: every concept x every stream, P = primary, S = supporting
mx = []
for src, rows in (("Core concept", INTRO), ("Term", CON)):
    for r in rows:
        ref, title, prim, sup = r[0], r[1], r[5], r[6]
        cells = ["P" if s == prim else "S" if s in sup.split(",") else "" for s in ORDER]
        mx.append([ref, src, title] + cells)
write("stream_matrix", ["Ref","Kind","Item"] + [SC[s] for s in ORDER], mx)
cnt = []
for s in ORDER:
    ci = 3 + ORDER.index(s)
    p = sum(1 for r in mx if r[ci] == "P"); sp = sum(1 for r in mx if r[ci] == "S")
    cnt.append([s, SC[s], p, sp, p + sp,
                sum(1 for r in mx if r[ci] == "P" and r[1] == "Term"), sum(1 for r in mx if r[ci] == "P" and r[1] == "Core concept")])
write("stream_counts", ["ID","Stream","Primary","Supporting","Total touched","Terms as primary","Core concepts as primary"], cnt)

# --------------------------------------------------------------- stream lens: how the core TOGAF concepts show up in each stream
LENSES = ["Principle","Building block","View and viewpoint","Deliverable","Standard to follow","Governance gate","Typical risk","Measure"]
LENS = {
 "S01":["Every change traces to a strategic objective and a capability.","Capability, work package, transition architecture.","Executive view of vision, roadmap and benefits.","Vision, principles catalogue, roadmap, governance model.","TOGAF ADM, enterprise architecture repository rules.","G0 mandate, G1 vision, G8 migration, G9 benefits review.","Architecture drifts from strategy; shelfware.","Share of projects with an architecture review; benefits realised."],
 "S02":["Business need drives technology, never the reverse.","Business capability, value-stream stage, process, rule.","Business owner view: capability map, value stream, process.","Business requirements, capability map, process catalogue, rules.","BABOK v3 requirement classes; BPMN notation.","G2 scope, G3 requirements baseline.","Unclear scope; unmanaged change requests.","Requirements traced and signed off; cycle-time reduction."],
 "S03":["Data is a managed asset with an owner and a steward.","Data entity, reference data set, quality rule.","Data steward view: dictionary and quality dashboard.","Conceptual and logical model, dictionary, DQ rules, lifecycle.","DAMA-DMBOK2 knowledge areas; data classification scheme.","G4 data model approved; DQ threshold met before go-live.","Poor quality data; unclear ownership.","DQ score by dimension; percentage of entities with an owner."],
 "S04":["Reuse before buy, buy before build.","Architecture building block and solution building block.","Developer and solution view: component and context diagrams.","Component catalogue, solution design, application portfolio.","Service-oriented design; API-first principle.","G5 design review; component compliance check.","Duplicate functionality; tight coupling.","Reuse rate; components with a named owner and lifecycle."],
 "S05":["Standard platforms over bespoke technology.","Technology component and technology service.","Platform engineer view: technology standards and decisions.","Technology standards, platform catalogue, decision records.","Approved technology standards list; lifecycle policy.","G5 design review; exception approval by decision record.","Technology lock-in; unsupported versions.","Share of workloads on standard platforms; exceptions open."],
 "S06":["Human accountability for AI outputs; no unexplained high-impact decisions.","Model, feature set, prompt or evaluation set, human review step.","Product owner and risk view: use cases, data readiness, oversight.","AI use-case register, model lifecycle, evaluation report.","Responsible-AI principles; model documentation; privacy law.","AI use-case approval before build; evaluation before release.","Bias, drift, hallucination, data leakage.","Accuracy and fairness against threshold; human override rate."],
 "S07":["Security and privacy by design; least privilege.","Identity service, access control, encryption, audit log.","Security officer view: classification, access matrix, controls.","Classification scheme, access matrix, controls, security risks.","Recognised security and privacy standards and local law.","Security review at design; penetration test before go-live.","Unauthorised access; data loss; weak audit trail.","Open findings by severity; access reviews completed on time."],
 "S08":["People first: simple, accessible, consistent.","Design-system component, pattern, journey step.","User and service-owner view: personas, journeys, prototypes.","Personas, journey map, UX standards, accessibility criteria.","Accessibility guidelines (WCAG); design system.","Usability test before release; accessibility check.","Low adoption; exclusion of users; inconsistent screens.","Task success rate; satisfaction score; accessibility defects."],
 "S09":["Resilient by design; automate environments.","Environment, network zone, compute and storage tier.","Operations view: environments, capacity, availability, recovery.","Hosting model, environment plan, capacity plan, DR plan.","Availability and recovery targets; operations standards.","Operational readiness review before go-live.","Outage; capacity shortfall; unrecoverable data.","Availability; recovery time and point objectives met."],
 "S10":["Integrate through governed interfaces, not point-to-point shortcuts.","Interface, API, event, message, adapter.","Integration view: interface catalogue and flow diagram.","Interface catalogue, integration patterns, API standards.","API and message standards; exchange formats.","G5 interface design review; contract test before release.","Broken interfaces; undocumented dependencies.","Interface availability; failed message rate; interfaces documented."],
 "S11":["Use the domain's own language and rules.","Domain rule, domain reference model, glossary term.","Subject-expert view: glossary, rules, domain reference.","Domain glossary, business rules, domain reference model.","Domain standards and rules, for example network or regulatory practice.","Subject-expert review of rules and vocabulary.","Misread domain rules; inconsistent terms.","Rules validated by experts; glossary coverage."],
 "S12":["Comply with the sector and the country by configuration, not redesign.","Regulatory obligation, country profile, industry reference mapping.","Regulator and sector view: obligations, country configuration.","Regulatory obligations register, country profile, reference mapping.","Industry reference architectures; sector and local regulation.","Compliance check before submission and before go-live.","Regulatory change; local rules missed.","Obligations mapped to controls; submissions on time."],
}
write("stream_lens", ["Stream","Lens (TOGAF concept)","How it applies"], [(SC[s], l, LENS[s][i]) for s in ORDER for i, l in enumerate(LENSES)])

assert len(CON) == 89 and len(INTRO) == 32, (len(CON), len(INTRO))
print(f"streams {len(STREAMS)}, core concepts {len(INTRO)} (18 topics + 14 sub-sections), terms {len(CON)}")
