document.querySelectorAll("table.dt").forEach(function(t){
  var ths=t.querySelectorAll("th");
  ths.forEach(function(th,i){th.title="Click to sort";th.addEventListener("click",function(){
    var asc=!th.classList.contains("asc");ths.forEach(function(x){x.classList.remove("asc","desc")});th.classList.add(asc?"asc":"desc");
    var tb=t.tBodies[0],rows=[].slice.call(tb.rows);
    rows.sort(function(a,b){var x=a.cells[i].innerText.trim(),y=b.cells[i].innerText.trim(),nx=parseFloat(x),ny=parseFloat(y);
      var c=(!isNaN(nx)&&!isNaN(ny)&&/^[\d.]+$/.test(x)&&/^[\d.]+$/.test(y))?nx-ny:x.localeCompare(y,undefined,{numeric:true});return asc?c:-c});
    rows.forEach(function(r){tb.appendChild(r)})})});});
document.querySelectorAll(".side a,.top nav a").forEach(function(a){a.addEventListener("click",function(){document.body.classList.remove("navopen")})});
