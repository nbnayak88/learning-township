#!/usr/bin/env python3
"""Build-time checks: broken internal links/images, requirement fields, and a client-term scan.
Add words to BLOCK to keep client, vendor-specific or personal details out of the reference artefacts."""
import os, re, csv, sys
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BLOCK = [w for w in open("tools/blocklist.txt", encoding="utf-8").read().split("\n") if w.strip() and not w.startswith("#")] if os.path.exists("tools/blocklist.txt") else []
bad = 0
for f in sorted(os.listdir("site")):
    if not f.endswith(".html"): continue
    t = open(f"site/{f}", encoding="utf-8").read()
    for m in re.finditer(r'(?:href|src)="([^"#:]+)(?:#[^"]*)?"', t):
        p = m.group(1)
        if p.startswith(("http", "mailto")): continue
        if not os.path.exists(os.path.join("site", p)): print(f"BROKEN LINK in {f}: {p}"); bad += 1
rows = list(csv.reader(open("data/requirements.csv", encoding="utf-8")))
h = rows[0]
for r in rows[1:]:
    for col in ("ID", "Requirement", "MoSCoW", "Acceptance criteria"):
        if not r[h.index(col)].strip(): print(f"EMPTY {col} in {r[0]}"); bad += 1
ids = [r[0] for r in rows[1:]]
if len(ids) != len(set(ids)): print("DUPLICATE requirement IDs"); bad += 1
import csv as _c
for fn in ("togaf_concepts","togaf_intro"):
    rr=list(_c.reader(open(f"data/{fn}.csv",encoding="utf-8")))
    for r in rr[1:]:
        if not r[2].strip() or not r[-2].strip(): print(f"TOGAF item without meaning or stream: {r[0]} {r[1]}"); bad += 1
cn=len(list(_c.reader(open("data/togaf_concepts.csv",encoding="utf-8"))))-1
if cn!=89: print(f"WARNING: {cn} TOGAF terms (expected 89 for the supplied list)")
text = ""
for root in ("docs", "data"):
    for f in os.listdir(root): text += open(f"{root}/{f}", encoding="utf-8").read().lower()
for w in BLOCK:
    if w.lower() in text: print(f"BLOCKED TERM found: {w}"); bad += 1
print("checks passed" if not bad else f"{bad} problem(s)")
sys.exit(1 if bad else 0)
