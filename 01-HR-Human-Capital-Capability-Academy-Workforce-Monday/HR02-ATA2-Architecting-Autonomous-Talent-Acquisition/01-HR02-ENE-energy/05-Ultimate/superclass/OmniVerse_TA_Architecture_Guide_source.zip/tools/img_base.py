import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

NAVY="#101820"; BLUE="#4E8F1D"; LIGHT="#EEF6E4"; GOLD="#E9527F"; GREY="#5B6770"

# ---- architecture diagram
fig=plt.figure(figsize=(13,9.2),dpi=170); ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,130); ax.set_ylim(0,92); ax.axis("off")
def box(x,y,w,h,txt,fc=LIGHT,ec=BLUE,tc=NAVY,fs=8.5,bold=False,lw=1.2):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0,rounding_size=0.8",fc=fc,ec=ec,lw=lw))
    ax.text(x+w/2,y+h/2,txt,ha="center",va="center",color=tc,fontsize=fs,fontweight="bold" if bold else "normal",linespacing=1.25)
def layer(y,h,title):
    ax.add_patch(FancyBboxPatch((2,y),92,h,boxstyle="round,pad=0,rounding_size=1",fc="white",ec=NAVY,lw=1.4))
    ax.add_patch(FancyBboxPatch((2,y),13,h,boxstyle="round,pad=0,rounding_size=1",fc=NAVY,ec=NAVY))
    ax.text(8.5,y+h/2,title,color="white",fontsize=8.5,fontweight="bold",ha="center",va="center",linespacing=1.3)
ax.text(65,89,"Generic High-Level Architecture – Infrastructure Encroachment Management Platform",ha="center",fontsize=13,fontweight="bold",color=NAVY)

# layers (top->bottom)
layer(74,11,"1. Users &\nChannels")
for i,t in enumerate(["Field Officers\n(mobile / tablet)","Case Creators &\nReviewers","Approvers &\nFinal Approver","Finance &\nCollections","Legal &\nRegulatory Affairs","Executives\n& Admins"]):
    box(16.5+i*12.9,75.5,12,8,t,fs=7.3)
layer(62,10,"2. Presentation")
for i,t in enumerate(["Responsive Web Portal\n(role-based, bilingual)","Offline-capable\nMobile / PWA","Embedded Dashboards\n& Reports","Notification Centre\n(in-app / email / SMS)"]):
    box(16.5+i*19.4,63.5,18,7,t,fs=7.8)
layer(40,20,"3. Application\n& Workflow\nServices")
svc=["Case Management\n& Register","Workflow &\nApproval Engine","Classification &\nRouting Rules","Cost & Lost-Benefit\nCalculation Engine","Regulatory Checklist\n& Readiness Validator","Claims &\nCollections Service","Regulatory Submission\n& Decision Tracker","SLA, Escalation &\nNotification Service"]
for i,t in enumerate(svc):
    box(16.5+(i%4)*19.4,50.2-(i//4)*9.6,18,8.2,t,fs=7.6)
layer(28,10,"4. Integration\nLayer")
for i,t in enumerate(["API Gateway\n(REST / SOAP)","Enterprise Service Bus\n/ iPaaS","Secure File Transfer\n& Connectors","ETL / Data Quality\nServices"]):
    box(16.5+i*19.4,29.5,18,7,t,fs=7.8)
layer(14,12,"5. Data &\nContent")
for i,t in enumerate(["Operational Database\n(cases, workflow, audit)","Data Lake / Warehouse\n(analytics, history)","Document & Evidence\nRepository (DMS)","Geospatial Store\n(map layers, geotags)"]):
    box(16.5+i*19.4,16,18,8,t,fs=7.8)
# cross-cutting
ax.add_patch(FancyBboxPatch((2,1.5),92,10,boxstyle="round,pad=0,rounding_size=1",fc="#FDECF1",ec=GOLD,lw=1.4))
ax.text(48,9.4,"Cross-Cutting: Security, Governance & Operations",ha="center",fontsize=8.8,fontweight="bold",color=NAVY)
for i,t in enumerate(["Identity & Access\n(SSO, RBAC, MFA)","Encryption &\nKey Management","Immutable Audit\nTrail & Logging","Monitoring, Backup\n& DR","Hosting: On-prem /\nPrivate / Sovereign Cloud"]):
    box(4+i*17.6,2.4,16.4,5.6,t,fc="white",ec=GOLD,fs=7)
# external systems right
ax.add_patch(FancyBboxPatch((98,14),30,71,boxstyle="round,pad=0,rounding_size=1",fc="#F3F5F7",ec=GREY,lw=1.4,ls="--"))
ax.text(113,82,"Enterprise & External Systems",ha="center",fontsize=9,fontweight="bold",color=NAVY)
ext=["Asset / GIS System\n(network assets, maps)","ERP – Finance (AR)\n(invoice, payment, tax)","CRM / Field Service /\nExisting Case Systems","Excavation & Permit\nRegistry","Customer / Utility\nData Platform","Regulator Portal\n(external, secure channel)","Identity Provider\n(Directory / SSO)","Email / SMS Gateway"]
for i,t in enumerate(ext):
    box(100.5,74-i*8.4,25,6.6,t,fc="white",ec=GREY,fs=7.6)
# arrows
for y in (28.5,):
    pass
ax.add_patch(FancyArrowPatch((94,33),(98,33),arrowstyle="<->",mutation_scale=14,color=NAVY,lw=1.6))
for ya,yb in ((74,72),(62,60),(40,38),(28,26)):
    ax.add_patch(FancyArrowPatch((48,ya),(48,yb),arrowstyle="<->",mutation_scale=11,color=BLUE,lw=1.2))
fig.savefig("assets/arch.png"); plt.close(fig)

# ---- process flow diagram
fig=plt.figure(figsize=(13,3.6),dpi=170); ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,130); ax.set_ylim(0,36); ax.axis("off")
steps=["1. Detect &\nRegister Case\n(field / desk)","2. Validate &\nRoute to Owner","3. Assess Cost &\nLost Benefit","4. Review &\nApprove","5. Issue\nFinancial Claim","6. Collect &\nFollow Up","7. Regulatory\nSubmission","8. Decision, Appeal\n& Closure"]
w=14.2;g=2.1
for i,t in enumerate(steps):
    x=2+i*(w+g)
    box(x,12,w,14,t,fc=NAVY if i in (0,7) else LIGHT,tc="white" if i in (0,7) else NAVY,fs=8,ec=NAVY)
    if i<7: ax.add_patch(FancyArrowPatch((x+w,19),(x+w+g,19),arrowstyle="-|>",mutation_scale=12,color=GOLD,lw=2))
ax.text(65,32,"End-to-End Case Lifecycle (generic to-be flow)",ha="center",fontsize=11,fontweight="bold",color=NAVY)
ax.text(65,5,"Automated controls throughout: mandatory-data checks · SLA timers & escalation · role-based approvals · notifications · immutable audit trail · real-time dashboards",ha="center",fontsize=8.5,color=GREY,style="italic")
fig.savefig("assets/flow.png"); plt.close(fig)
