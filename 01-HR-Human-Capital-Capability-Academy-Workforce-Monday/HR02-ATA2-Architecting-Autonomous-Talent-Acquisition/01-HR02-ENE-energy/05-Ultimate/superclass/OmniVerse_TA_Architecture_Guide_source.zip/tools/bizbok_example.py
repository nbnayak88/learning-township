import csv
def w(name, head, rows):
    with open(f"data/{name}.csv","w",newline="",encoding="utf-8") as f:
        c=csv.writer(f); c.writerow(head); c.writerows(rows)

EX=[
("Strategy","L1","Vision and mission","Reliable, safe, sustainable service for all communities","Objectives, vision"),
("Strategy","L2","Strategic objectives","Cut service interruptions; protect assets from third-party damage; improve customer trust","Objectives register"),
("Strategy","L3","Courses of action","Digital asset register; permit and notification workflow; field verification","Work packages"),
("Capability","L1","Plan and design network","Demand forecasting; network planning; engineering design","Capabilities register"),
("Capability","L1","Build and maintain assets","Construction; inspection; preventive maintenance","Capabilities register"),
("Capability","L1","Operate and monitor","Network monitoring; incident response; field dispatch","Capabilities register"),
("Capability","L1","Serve customers and the public","Service requests; billing; complaints and notices","Capabilities register"),
("Capability","L1","Govern and enable","Risk and compliance; finance; workforce; data management","Capabilities register"),
("Capability","L2","Asset protection (under Operate and monitor)","Detect encroachment; assess risk; enforce corrective action","Capabilities register"),
("Capability","L3","Detect encroachment","Satellite and drone review; citizen report intake; patrol findings","Capabilities register"),
("Organization","L1","Executive and governance","Board, steering committee, architecture board","Stakeholders, RACI"),
("Organization","L1","Operating units","Planning, operations, maintenance, customer service, legal","Stakeholders, RACI"),
("Organization","L1","External parties","Regulators, municipalities, contractors, landowners, public","Stakeholders"),
("Organization","L2","Roles on a case","Case owner, field inspector, legal officer, approver","RACI"),
("Value","L1","Deliver reliable service","Request service, connect, supply, restore","Value stream register"),
("Value","L1","Protect and maintain assets","Detect, assess, resolve, verify, close","Value stream register"),
("Value","L2","Resolve an encroachment","Detect; classify; notify; negotiate or enforce; verify; close","Value stream register"),
("Value","L3","Stakeholder value per stage","Owner knows status; public gets clear notice; regulator gets evidence","Value stream register"),
("Information","L1","Core business objects","Asset, location, parcel, party, case, permit, notice","Data entities"),
("Information","L2","Attributes and relations","Case belongs to asset and parcel; notice belongs to case","Data dictionary"),
("Information","L3","Quality rules","Every case has a location, a status and an owner","Data dictionary, DMBOK"),
("Initiative","L1","Programmes","Asset digitisation; case management; analytics","Work packages"),
("Initiative","L2","Initiative to capability impact","Case management raises Detect, Resolve and Verify maturity","Gap analysis"),
("Initiative","L3","Roadmap waves","Wave 1 foundation; wave 2 workflow; wave 3 analytics","Roadmap"),
("Product","L1","Services offered","Connection, supply, permit to work near assets, public notices","Capabilities (business services)"),
("Product","L2","Service variants","Standard permit; emergency permit; temporary permit","Add a products register"),
("Stakeholder","L1","Groups","Customers, public, regulator, landowners, contractors, employees","Stakeholders register"),
("Stakeholder","L2","Interests and influence","Regulator: compliance evidence; public: safety and clarity","Stakeholders register"),
("Policy","L1","Policy areas","Safety, permitting, data protection, enforcement","Business rules, principles"),
("Policy","L2","Rules","No structure within the protected corridor without a permit","Business rules"),
("Policy","L3","Rule to capability link","The permit rule governs Detect and Resolve","Traceability"),
("Metrics","L1","Outcome measures","Interruptions caused by third-party damage; case cycle time","KPI register"),
("Metrics","L2","Capability measures","Detection lead time; share of cases closed on time","KPI register"),
("Metrics","L3","Data measures","Share of cases with verified location","KPI register"),
]
w("bizbok_sector_example",["Element","Level","Item","Generic example (infrastructure operator)","Template register"],EX)

TERMS=[
("Goal","A broad, qualitative outcome the business wants to reach.","Vision, objectives"),
("Objective","A specific, measurable target that supports a goal.","Objectives register, KPIs"),
("Course of action","A chosen way to reach objectives, such as a strategy, initiative or policy.","Work packages, decisions"),
("Change","What must differ in the business for the course of action to work.","Gap analysis, impact assessment"),
("Strategy justification","Evidence, ecosystem factors and stakeholder needs behind a strategy.","Decision records"),
("Strategy interpretation","Turning a strategy into objectives and actions each unit can act on.","Requirement traces"),
("Planning approach","Top-down and sequential: set strategy, then cascade to units.","Programme method"),
("Design approach","Iterative: use blueprints to test options with the business.","Architecture sprints"),
("Business Model Canvas","One-page view of value proposition, segments, channels, resources and costs.","Vision and value chapters"),
]
w("bizbok_strategy_terms",["Term","Meaning in plain words","Where it lands in this template"],TERMS)
