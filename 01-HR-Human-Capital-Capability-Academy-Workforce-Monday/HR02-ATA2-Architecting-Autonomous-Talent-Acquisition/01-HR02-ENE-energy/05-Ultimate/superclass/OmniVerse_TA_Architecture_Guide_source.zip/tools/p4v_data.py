"""9P4V Framework registers (SuccessLabs Academy; Nayak, 2025). Written to data/p4v_*.csv"""
import csv
def w(n,h,rows):
    for r in rows: assert len(r)==len(h),(n,r)
    with open(f"data/{n}.csv","w",newline="",encoding="utf-8") as f:
        c=csv.writer(f); c.writerow(h); c.writerows(rows)

w("p4v_spine",["Stage","Name","Question","Definition","Guided or delivered by","Case outputs","Template application"],[
("V1","Vision","Where are we going?","The shared, aspirational future state and strategic direction.","Policy, Portfolio, Program","Vision statement; strategic intent; transformation North Star; policy alignment; transformation portfolio; program structure","Chapters 6 and 14: vision, principles, objectives, business case; registers: principles, kpis"),
("V2","Value","What meaningful value are we creating?","Tangible, measurable benefits for customers, employees, organisations, ecosystems and society.","Platform, Product, Process","Value proposition; value tree; capability and value map; platform strategy; product and service design; process and value-stream transformation; value metrics","Chapters 10 to 13: capabilities, value stream, data, applications, technology; registers: capabilities, value_stream, components"),
("V3","Victory","What tangible outcomes and momentum have we achieved?","Measurable milestones and small wins that build confidence, trust, adoption and momentum.","People, Practice, Project","Change and adoption plan; new practices; project execution plan; milestone and KPI dashboard; benefits realisation; victory evidence","Chapters 5, 15 and 16: migration, governance, quality; registers: work_packages, raci, kpis"),
("V4","Venture","How do we sustain, scale, replicate and evolve the transformation?","The mature, repeatable, sustainable realisation of the original vision.","Institutionalise, sustain, scale, replicate, productise, build ecosystems, innovate","Venture and scale model; operating model; governance; sustainability model; replication playbook; continuous-improvement loop","Chapters 4 and 18: paperless operating model and the reusable template; feedback loop to the next V1"),
])

w("p4v_pillars",["Pillar","Group","Core question","Template register or chapter","Primary streams","Typical measure"],[
("Policy","V1 Vision","What rules, regulations, standards, principles and strategic directives shape the transformation?","principles; business_rules; Chapters 6.7, 10.6 and 16.4","Enterprise, Security, Industry","Share of decisions traced to a principle or rule"),
("Portfolio","V1 Vision","Which investments and initiatives should be prioritised, sequenced, funded or stopped?","gap_analysis; work_packages; Chapters 14.8 and 15.2","Enterprise, Business","Benefit per unit of investment; share of initiatives with an owner"),
("Program","V1 Vision","How should related projects be orchestrated to achieve strategic outcomes?","Roadmap (15.3); governance (Chapter 16)","Enterprise, Business","Milestones met; dependency conflicts open"),
("Platform","V2 Value","What shared digital and physical capabilities enable scale?","components; interfaces; tech_standards; Chapters 12 and 13","Application, Technology, Infrastructure, Integration","Reuse rate; platform availability"),
("Product","V2 Value","What tangible product, service, capability or outcome is delivered?","capabilities (business services); requirements; Chapter 10.4","Business, Domain, UI/UX","Adoption of each service; satisfaction"),
("Process","V2 Value","Which end-to-end value streams and operating processes must change?","value_stream; processes; Chapters 8.7 and 10.3","Business, Domain, Data","Cycle time; rework rate; straight-through share"),
("People","V3 Victory","Who must lead, execute, adopt, operate and benefit?","stakeholders; raci; Chapters 15.7 and 16.2","Enterprise, Business, UI/UX","Adoption; trained share; stakeholder confidence"),
("Practice","V3 Victory","What repeatable behaviours, methods, skills and ways of working must change?","ba_checklist; quality gates (Chapter 5); ways of working (4.5)","Enterprise, Data, AI","Gate pass rate; practice maturity"),
("Project","V3 Victory","What time-bound intervention creates or changes a capability?","work_packages; implementation, test, cutover (15.4 to 15.6)","Application, Integration, Technology","On-time, on-budget delivery; defects at go-live"),
])

STG=[
("01","Industry Context","Establish the external environment.","Industry Opportunity and Threat Map","Before V1","All","Industry; Enterprise"),
("02","Enterprise Context","Organisation, business model, geography, scale, stakeholders, strategy, technology landscape.","Enterprise Context Canvas","Before V1","All","Enterprise; Business"),
("03","Transformation Trigger","The event that creates urgency.","Transformation Trigger Statement","Before V1","Policy","Enterprise; Industry"),
("04","V1 Vision","Define the future ambition.","Vision Canvas","V1","Policy, Portfolio, Program","Enterprise; Business"),
("05","Problem Framing","What is happening, why, root cause, what if nothing changes, who owns it.","Problem Statement and Issue Tree","V1","Policy","Business; Enterprise"),
("06","Discovery and Diagnosis","Analyse the current state.","Current-state, capability map, stakeholder map, process and value-stream, technology and data, maturity assessments","V1","Process, People","Business; Data; Application; Technology"),
("07","9P4V Assessment","Map the challenge across the nine pillars and find the current V1 to V4 position.","9P4V Transformation Canvas","V1 to V4","All nine","Enterprise"),
("08","Experience Discovery","Customer, employee, partner, manager, executive or citizen experience.","Experience Journey and Pain Point Map","V2","Product, Process","UI/UX; Business"),
("09","12-Stream Architecture","Future-state architecture across the relevant streams.","Target architecture and one deliverable per stream","V2","Platform, Product, Process","All twelve streams"),
("10","Strategic Options","Three or four credible alternatives, each judged on fit, value, cost, risk, feasibility, experience, time, scalability.","Options evaluation","V1 to V2","Portfolio","Enterprise; Business"),
("11","Trade-Offs","Explicit decisions: cost vs experience, speed vs quality, innovation vs risk, standardisation vs customisation, AI autonomy vs human control, short-term ROI vs long-term value, complexity vs flexibility.","Trade-off record","V2","Policy, Portfolio","Enterprise; AI; Security"),
("12","Experiment","Test the highest-risk assumptions.","Experiment and MVP Canvas","V2 to V3","Project, Practice","AI; Application; UI/UX"),
("13","Decision Room","Simulate the executive boardroom (CEO, CFO, CIO, COO, CHRO, CISO, business leader, customer or employee representative, enterprise architect).","Executive Recommendation","V1 to V3","Portfolio, Program","Enterprise"),
("14","Transformation Roadmap","Initiatives, dependencies, milestones, waves, resources, governance, change, risks, benefits.","Roadmap","V3","Program, Project","Enterprise; Integration"),
("15","Transformation Shock","An unexpected disruption forces a revised plan.","Re-Architecture Decision","V3","Program, People","Enterprise; Security"),
("16","V3 Victory","Prove measurable progress: outcomes, adoption, benefits, KPIs, milestones, stakeholder confidence.","Victory Dashboard","V3","People, Practice, Project","Business; Data"),
("17","V4 Venture","Make the transformation sustainable and scalable.","Venture and scale model, operating model, governance, replication playbook, sustainability model, innovation pipeline","V4","All nine","Enterprise; Industry"),
("18","Reflection and Next Vision","What worked, failed, changed, was learned, should be re-architected, and what new opportunity emerged.","Reflection and Next-Vision Canvas","V4 to V1","Policy, Portfolio","Enterprise"),
]
w("p4v_stages",["Stage","Name","What happens","Deliverable","Position","Pillars used","Lead streams"],STG)

PACK=[
("1","Executive Brief","Executive summary on the home page and Chapter 0"),("2","Industry Analysis","Chapter 6.1 and 14.1; industry stream (2.12)"),
("3","Problem Statement","Chapter 6.2 and 14.4 root causes"),("4","Stakeholder Map","stakeholders register; Chapter 6.6"),
("5","Vision","Chapter 6.3"),("6","9P4V Assessment","Chapter 3.6 canvas and the p4v_lens register"),
("7","Current-State Architecture","Chapters 10.7 and 14.1"),("8","Capability Assessment","capabilities register; Chapter 10.2"),
("9","Experience Architecture","Chapter 3.9; UI/UX stream"),("10","Target Architecture","Chapters 10 to 13"),
("11","12-Stream Architecture","Chapter 2; stream_matrix"),("12","Strategic Options","Chapter 14.5"),
("13","Trade-Off Analysis","Chapter 14.5 and decision register (adr)"),("14","Business Case","Chapter 14.8"),
("15","AI and Technology Strategy","AI and Technology streams (14.5, 14.6); Chapter 13.9"),("16","Experiment and MVP","Chapter 3.10; Chapter 15.4 pilot"),
("17","Transformation Roadmap","Chapter 15.3.1"),("18","Risk and Governance","risks register; Chapter 16"),
("19","Change and Adoption Plan","Chapters 15.7 and 16.7"),("20","Value Realisation Model","Chapters 14.9 and 15.8; kpis register"),
("21","Victory Dashboard","Workbook dashboard and kpis register"),("22","Venture and Scale Model","Chapter 4.9 and Chapter 18"),
("23","Reflection","Chapter 16.9 continuous improvement"),("24","Next-Vision Recommendation","Chapter 3.4 feedback loop"),
]
w("p4v_pack",["No.","Artefact","Where it lives in this template"],PACK)

w("p4v_skills",["Skill","Evidence","Level scale"],[
(s,e,"Developing / Practitioner / Advanced") for s,e in [
("Analytical Thinking","Root-cause analysis"),("Systems Thinking","Cross-stream architecture"),("AI Literacy","AI use case or agent design"),
("Leadership","Executive simulation"),("Negotiation","Stakeholder conflict resolution"),("Creativity","Strategic alternatives"),
("Communication","Executive presentation"),("Adaptability","Response to transformation shock"),("Collaboration","Team architecture workshop"),
("Ethical Judgment","Risk and AI governance decision")]])

SC=[("Industry Insight",10),("Strategic Problem Solving",10),("12-Architecture Integration",20),("9P4V Application",15),("Transformation Design",15),("Experience Architecture",10),("21st-Century Skills",10),("Executive Communication",5),("Value and Victory Measurement",5)]
assert sum(x for _,x in SC)==100
w("p4v_score",["Dimension","Weight %"],[(a,str(b)) for a,b in SC]+[("Total","100")])
w("p4v_levels_score",["Score","Capability level"],[("0 to 49","Explorer"),("50 to 64","Practitioner"),("65 to 79","Architect"),("80 to 89","Advanced Architect"),("90 to 100","Architecture Leader")])

w("p4v_levels",["Level","Purpose","Duration","Streams","Features"],[
("Bronze: Pre-Foundation","Understand","60 to 90 minutes","3 to 4","Guided case; basic 9P4V mapping; awareness-level deliverable"),
("Silver: Foundation","Analyse","2 to 3 hours","5 to 7","Structured ambiguity; strategic options; practical architecture artefact"),
("Gold: Essentials","Architect","4 to 6 hours","8 to 10","Experimentation; executive simulation; transformation shock; full transformation pack"),
("Diamond: Advanced","Transform","1 to 2 days","All 12","Full 9P4V journey; industry complexity; multiple stakeholder conflicts; experimentation; implementation challenge; value realisation; venture and scale strategy; executive defence"),
("Quantum: Ultimate","Incubate and build","Programme","As needed","Incubation through guided experimentation; a precise council for guidance and decisions; proximity to the founder"),
])

GATE=[("Industry","Realistic industry context; industry-specific driver; relevant regulation and economics; technology and AI implications"),
("9P4V","V1 vision explicit; policy, portfolio and program addressed; V2 value measurable; platform, product and process addressed; V3 victory has visible milestones; people, practice and project addressed; V4 venture covers sustainability and scale; feedback loop creates the next vision"),
("Architecture","Relevant streams applied; decisions connected; no stream treated as a silo"),
("Experience","Stakeholder experience explicit; pain points identified; future experience designed; outcomes measurable"),
("Transformation","Current state; future state; roadmap; governance; change and adoption; risk; benefits realisation"),
("Professional practice","MBB-style problem structuring; Big 4-style transformation discipline; business-school decision tension; experimentation; executive communication"),
("Skills","Skills observable; evidence captured; assessment based on behaviour and artefacts"),
("Practicality","Learner builds something, makes decisions, handles uncertainty, defends recommendations; the case produces portfolio evidence")]
w("p4v_gate",["Area","Check before publishing"],GATE)

# 12 streams x V1..V4
S=[("Enterprise","Sets direction and coherence","Aligns portfolio to value","Governs cross-stream decisions","Institutionalises the operating model"),
("Business","Frames strategy, capabilities, objectives","Maps value streams and services","Measures outcomes and adoption","Scales the business model"),
("Data","Defines data policy and ownership","Designs entities, quality and analytics","Measures with trusted data","Reuses data products across units"),
("Application","Sets application principles","Designs the solution and components","Delivers releases that users adopt","Standardises for replication"),
("Technology","Sets standards and constraints","Selects platforms","Operates and supports the build","Industrialises the platform"),
("AI","Sets responsible-AI policy","Designs AI use cases and agents","Proves benefit with pilots","Scales AI under governance"),
("Security","Sets privacy and risk appetite","Designs identity, controls and audit","Evidences compliance","Embeds controls in the repeatable model"),
("UI/UX","States the experience ambition","Designs journeys and interaction","Measures experience and adoption","Packages the experience pattern"),
("Infrastructure","Sets resilience and sustainability goals","Sizes environments and recovery","Runs to service levels","Scales capacity cost-effectively"),
("Integration","Sets interoperability principles","Designs interfaces, events and APIs","Proves end-to-end flows","Opens the ecosystem to partners"),
("Domain","States domain outcomes","Designs functional rules and processes","Proves domain results","Replicates across domains"),
("Industry","Reads regulation and economics","Applies industry reference models","Benchmarks results","Extends across the sector")]
w("p4v_streams",["Stream","V1 Vision","V2 Value","V3 Victory","V4 Venture"],S)

# worked example, generic
w("p4v_example",["Pillar","Group","Generic reference solution (infrastructure encroachment platform)"],[
("Policy","V1 Vision","One governed case platform; permit and protected-corridor rules; evidence retention rule"),
("Portfolio","V1 Vision","Fund detection, case workflow and analytics in value order; stop duplicate local tools"),
("Program","V1 Vision","Three waves under one steering committee, with shared milestones"),
("Platform","V2 Value","Shared case, geospatial and notification services reused by every unit"),
("Product","V2 Value","Permit, notice, inspection and closure services with published service levels"),
("Process","V2 Value","Detect, assess, notify, resolve, verify, close as one value stream"),
("People","V3 Victory","Named case owners; trained inspectors; sponsor and unit leads engaged"),
("Practice","V3 Victory","Evidence-first inspection practice; weekly case review; gate checks"),
("Project","V3 Victory","Work packages with dates, owners and benefits; pilot then rollout"),
("Venture (V4)","V4 Venture","Repeat for other protected asset classes and regions; template reused; ecosystem partners join"),
])

# chapters through the lens
L=[("0 About","V1","Policy","Purpose, scope, frameworks, document control"),
("6 Vision","V1","Policy, Portfolio","Vision, objectives, principles, value proposition"),
("10 Business","V2","Product, Process","Capabilities, value stream, services, rules"),
("7 BA approach","V1 to V3","Practice","Analysis approach, elicitation, traceability"),
("8 Requirements","V2","Product, Process","Requirement register and process catalogue"),
("14 Strategy analysis","V1","Portfolio, Policy","Gaps, options, business case, success measures"),
("11 Data","V2","Platform, Practice","Entities, dictionary, data governance"),
("12 Application","V2","Platform, Product","Components, interfaces, design decisions"),
("13 Technology","V2","Platform","Standards, deployment, resilience, roadmap"),
("15 Migration","V3","Program, Project, People","Work packages, roadmap, testing, training"),
("16 Governance","V3 to V4","Program, People, Practice","Governance, RACI, KPIs, change"),
("5 Quality","V3","Practice","Gates, checklists, quality metrics"),
("4 Paperless","V4","Practice, Platform","Operating model for an online practice"),
("1 TOGAF foundations","All","Policy","Shared vocabulary"),
("2 Streams","All","All nine","The lenses"),
("17 TOGAF coverage","All","Practice","Completeness evidence"),
("18 Template","V4","Practice, Platform","Replication playbook"),
("9 Business Architecture Guild","V1 to V2","Policy, Process, Product","Blueprints and practice guide"),
("3 9P4V Framework","All","All nine","The transformation spine"),
("19 Appendices","All","Practice","Crosswalks, templates, references")]
w("p4v_lens",["Chapter","9P4V stage","Main pillars","What it contributes"],L)

w("p4v_shocks",["Transformation shock","Typical architectural response"],[
("Budget cut of 20 to 25 percent","Re-scope waves; protect highest-value capabilities"),
("Programme delayed","Re-sequence dependencies; renegotiate milestones"),
("Critical integration fails","Fallback interface; contract and design review"),
("Security concern emerges","Pause release; risk assessment; remediation plan"),
("Regulatory requirement changes","Update policy and rules; assess impact on requirements"),
("Employee adoption drops","Change and training response; practice redesign"),
("AI pilot underperforms","Pivot or persevere decision, based on evidence"),
("Executive sponsor changes","Re-engage sponsor; re-confirm vision and benefits"),
("Competitor launches a disruptive solution","Revisit options and the value proposition"),
])
