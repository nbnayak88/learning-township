import csv
R=[
("3.1","Common Approaches for Getting Started","Start from a real business issue; pick value mapping or capability mapping first; build only what the first scenario needs; show results early.","First blueprint set plus a short roadmap","Where do we begin without boiling the ocean?"),
("3.2","Business Architecture Governance","Decision rights, standards for content, review of changes, ownership of the knowledgebase, links to enterprise and IT governance.","Governance charter, change log","Who may change the blueprints and how is quality kept?"),
("3.3","BA and Business Models","Business models describe how value is created and captured; blueprints make the model concrete and testable.","Business model view linked to capabilities and value streams","Does our model match what the business can actually do?"),
("3.4","BA and Business Process Management","Value streams and capabilities frame process work; processes detail how capabilities are performed.","Process inventory mapped to value stages","Which processes serve which stage and capability?"),
("3.5","BA, Case Management and Dynamic Rules-Based Routing","Case-based work follows rules not fixed paths; routing maps show how a case moves by conditions.","Routing map, rule set","How does a case move when the path is not fixed?"),
("3.6","BA and Lean Six Sigma","Blueprints show where to target improvement; Lean Six Sigma then fixes the process at that point.","Improvement targets tied to value stages","Where will improvement effort pay off most?"),
("3.7","BA Metrics: Improving Business Performance Management","Metrics attach to capabilities, value stages and initiatives so performance is read in business terms.","Metrics mapped to blueprint elements","How do we measure the business, not just projects?"),
("3.8","BA and Requirements Alignment","Requirements trace to capabilities, value stages and policies; blueprints give context and scope.","Requirement traceability to blueprint items","Which requirement serves which capability?"),
("3.9","BA Maturity Model","Staged model for the maturity of a business architecture practice, used to plan growth of the practice.","Maturity assessment and improvement plan","How mature is our practice and what next?"),
("3.10","The Role of the Business Architect","Architect as translator between strategy and execution: builds blueprints, facilitates, aligns business and IT.","Role description and competency profile","What does the business architect do and need?"),
("3.11","BA and Strategy Execution","Five steps: establish strategy, assess impact, architect solution, plan initiatives, deploy.","Impact assessment and initiative plans","How does strategy turn into funded change?"),
("3.12","BA and Operating Models","Business architecture guides the operating model: how capabilities, people, process and technology are organised to run.","Operating model options linked to capabilities","Which operating model best serves the strategy?"),
("3.13","BA and Customer Experience Design","Customer journeys connect to value streams and capabilities so experience gaps trace to causes.","Journey to value stream map","Which capabilities shape the customer experience?"),
("6.1","BA and IT Architecture Alignment Overview","Business architecture gives IT the business context; IT architecture shows how business needs are supported.","Alignment map across views","How do business and IT views fit?"),
("6.2","BA and Enterprise Architecture Framework Alignment","Blueprints feed framework phases such as TOGAF vision and business architecture.","Crosswalk to the framework","Where do blueprints enter the EA method?"),
("6.3","BA and Systems Development Lifecycle","Blueprints supply scope and requirements context at the front of development.","Link from initiative to project scope","How does business context reach delivery teams?"),
("6.4","BA and Application Portfolio Management","Map applications to capabilities to expose overlap, gaps and retire candidates.","Capability to application map","Which applications serve which capabilities?"),
("6.5","BA and Service-Oriented Architecture Alignment","Business services derive from capabilities, so IT services follow business needs.","Business service catalogue","Which services should exist, and why?"),
("6.6","Business Information and Data Architecture Alignment","Information map gives business meaning for data models and definitions.","Information to data entity map","What does each data entity mean in business terms?"),
("6.7","BA and Solution Architecture","Solution designs stay inside the capability, value and policy boundaries set by blueprints.","Solution scope statement","Does this solution fit the business architecture?"),
("6.8","BA and IT Architecture Transformation","Blueprints guide transformation sequencing and show business impact of IT change.","Transformation roadmap with impact view","What changes first and who is affected?"),
]
with open("data/bizbok_practice.csv","w",newline="",encoding="utf-8") as f:
    c=csv.writer(f); c.writerow(["Section","Topic","Key ideas","Typical artefact","Question it answers"]); c.writerows(R)
