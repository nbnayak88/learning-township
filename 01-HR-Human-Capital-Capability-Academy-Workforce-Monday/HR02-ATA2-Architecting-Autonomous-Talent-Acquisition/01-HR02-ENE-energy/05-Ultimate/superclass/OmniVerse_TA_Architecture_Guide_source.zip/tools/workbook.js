(function(){
var WB=window.WB,REPO=window.REPO,tabs=document.getElementById("tabs"),sheet=document.getElementById("sheet"),names=["dashboard"].concat(Object.keys(WB));
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function pill(col,v){if(col==="MoSCoW")return '<span class="pill m-'+esc(v)+'">'+esc(v)+'</span>';if(col==="Status")return '<span class="pill s-'+esc(v.replace(/ /g,"-"))+'">'+esc(v)+'</span>';
 if((v==="P"||v==="S")&&col!=="ID"&&col!=="Ref")return '<span class="pill x-'+v+'">'+v+'</span>';if(col==="Score"&&/^\d+$/.test(v)){var n=+v;return '<span class="pill r-'+(n>=15?"hi":n>=8?"md":"lo")+'">'+n+'</span>'}return esc(v)}
function countBy(name,col){var t=WB[name],i=t.cols.indexOf(col),m={},o=[];t.rows.forEach(function(r){var k=r[i]||"(blank)";if(!(k in m)){m[k]=0;o.push(k)}m[k]++});return o.map(function(k){return[k,m[k]]})}
function bars(list){if(!list.length)return "<p class=meta>No data yet</p>";var mx=Math.max.apply(null,list.map(function(x){return x[1]}));return list.map(function(x){return '<div class="bar"><span>'+esc(x[0])+'</span><i style="width:'+Math.max(4,100*x[1]/mx)+'%"></i><em>'+x[1]+'</em></div>'}).join("")}
function heat(){var t=WB.risks,L=t.cols.indexOf("Likelihood (1-5)"),I=t.cols.indexOf("Impact (1-5)"),H="<div class=heat><div class=ax></div>";
 for(var i=1;i<=5;i++)H+="<div class=ax>I"+i+"</div>";
 for(var l=5;l>=1;l--){H+="<div class=ax>L"+l+"</div>";for(var im=1;im<=5;im++){var s=l*im,c=s>=15?"#ffd5de":s>=8?"#fff1cc":"#e0f3cc";
  var ids=t.rows.filter(function(r){return +r[L]===l&&+r[I]===im}).map(function(r){return "<b>"+esc(r[0])+"</b>"}).join("");H+='<div style="background:'+c+'">'+ids+"</div>"}}return H+"</div>"}
function dash(){var req=WB.requirements.rows,must=req.filter(function(r){return r[4]==="Must"}).length;
 var k=[[WB.streams.rows.length,"architecture streams"],[WB.togaf_concepts.rows.length+WB.togaf_intro.rows.filter(function(r){return r[0].split(".").length===2}).length,"TOGAF items covered"],[req.length,"requirements"],[must,"must-haves"],[WB.components.rows.length,"components"],[WB.data_entities.rows.length,"data entities"],[WB.dq_rules.rows.length,"quality rules"],[WB.interfaces.rows.length,"interfaces"],[WB.risks.rows.length,"risks"]];
 return '<div class=kpis>'+k.map(function(x){return '<div><b>'+x[0]+'</b><span>'+x[1]+'</span></div>'}).join("")+'</div><div class=dash>'+
 '<div class=panel><h4>TOGAF items touched per stream (primary + supporting)</h4>'+bars(WB.stream_counts.rows.map(function(r){return[r[1],+r[4]]}))+'</div>'+
 '<div class=panel><h4>Requirements by type</h4>'+bars(countBy("requirements","BABOK class"))+'</div>'+
 '<div class=panel><h4>Requirements by priority (MoSCoW)</h4>'+bars(countBy("requirements","MoSCoW"))+'</div>'+
 '<div class=panel><h4>Requirements by TOGAF ADM phase</h4>'+bars(countBy("requirements","TOGAF ADM phase"))+'</div>'+
 '<div class=panel><h4>Risk heat map (likelihood × impact)</h4>'+heat()+'</div>'+
 '<div class=panel><h4>Data quality rules by dimension</h4>'+bars(countBy("dq_rules","Dimension"))+'</div>'+
 '<div class=panel><h4>Components by layer</h4>'+bars(countBy("components","Layer"))+'</div>'+
 '<div class=panel><h4>Data entities by classification</h4>'+bars(countBy("data_entities","Classification"))+'</div>'+
 '<div class=panel><h4>Work packages by transition architecture</h4>'+bars(countBy("work_packages","Transition architecture"))+'</div></div>'}
function show(n){location.hash=n.replace(/_/g,"-");[].forEach.call(tabs.children,function(b){b.classList.toggle("on",b.dataset.n===n)});
 if(n==="dashboard"){sheet.innerHTML=dash();return}
 var t=WB[n],cols=t.cols,rows=t.rows.slice(),sort=-1,asc=true,q="";
 sheet.innerHTML='<div class=tool><input id=q placeholder="Search '+esc(t.title)+'…" aria-label="Search"><span class=meta id=meta></span><a target=_blank rel=noopener href="https://github.com/'+REPO+'/edit/main/data/'+n+'.csv">Edit this table online ↗</a></div><div class=tablewrap><table class=dt><thead></thead><tbody></tbody></table></div>';
 var th=sheet.querySelector("thead"),tb=sheet.querySelector("tbody"),meta=document.getElementById("meta");
 function draw(){var r=rows.filter(function(x){return !q||x.join(" ").toLowerCase().indexOf(q)>-1});
  if(sort>-1)r.sort(function(a,b){var x=a[sort],y=b[sort],c=(/^[\d.]+$/.test(x)&&/^[\d.]+$/.test(y))?x-y:x.localeCompare(y,undefined,{numeric:true});return asc?c:-c});
  th.innerHTML="<tr>"+cols.map(function(c,i){return '<th data-i='+i+' class="'+(sort===i?(asc?"asc":"desc"):"")+'">'+esc(c)+"</th>"}).join("")+"</tr>";
  tb.innerHTML=r.map(function(x){return "<tr>"+x.map(function(v,i){return "<td>"+pill(cols[i],v)+"</td>"}).join("")+"</tr>"}).join("");
  meta.textContent=r.length+" of "+rows.length+" rows · "+cols.length+" columns";
  th.querySelectorAll("th").forEach(function(h){h.onclick=function(){var i=+h.dataset.i;asc=(sort===i)?!asc:true;sort=i;draw()}})}
 document.getElementById("q").oninput=function(){q=this.value.toLowerCase();draw()};draw()}
names.forEach(function(n){var b=document.createElement("button");b.textContent=n==="dashboard"?"▣ Dashboard":WB[n].title;b.dataset.n=n;b.onclick=function(){show(n)};tabs.appendChild(b)});
var h=location.hash.slice(1).replace(/-/g,"_");show(names.indexOf(h)>-1?h:"dashboard");
})();
