#!/usr/bin/env python3
"""Authors data/bizbok.csv: the Business Architecture Guild body of knowledge (BIZBOK Guide) table of contents,
mapped to this template. Topics follow the contents page supplied by the template owner; descriptions are our own words."""
import csv, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SN = {"S01":"Enterprise","S02":"Business","S03":"Data","S04":"Application","S05":"Technology","S06":"AI","S07":"Security","S08":"UI/UX","S09":"Infrastructure","S10":"Integration","S11":"Domain","S12":"Industry"}
def sn(s): return ", ".join(SN[x] for x in s.split(",") if x)
# part|section|topic|what it covers|how this template applies it|where|primary|supporting|coverage
R = """Part 1|1|Introduction|Why business architecture exists and how the guide is organised.|Chapters 0 and 6 set purpose and scope.|Ch 0, 6|S01|S02|Covered
Part 2|2|Business Architecture Blueprints|The nine standard views of the business.|Each blueprint has a register or chapter section, see rows 2.1 to 2.9.|Ch 9, 10|S02|S01|Covered
Part 2|2.1|Business Strategy Mapping|Linking vision, objectives, strategies and tactics to the capabilities that deliver them.|Objectives and vision; strategy to capability trace in requirements.|Ch 6, 14|S01|S02|Covered
Part 2|2.2|Capability Mapping|A stable map of what the business can do, grouped by domain, with heat-map assessment.|Capabilities register and capability map.|Ch 10|S02|S01,S11|Covered
Part 2|2.3|Organization Mapping|Who performs capabilities: units, roles, partners, locations.|Stakeholders and RACI registers.|Ch 7, 16|S02|S01|Covered
Part 2|2.4|Value Mapping|Value streams and the stages that create value for a stakeholder.|Value stream register and flow diagram.|Ch 10|S02|S11|Covered
Part 2|2.5|Information Mapping|Business information concepts and how they relate to capabilities and value.|Data entities, dictionary, conceptual model.|Ch 11|S03|S02|Covered
Part 2|2.6|Initiative Mapping|Linking change initiatives to the capabilities and value streams they affect.|Work packages and gap analysis.|Ch 14, 15|S01|S02|Covered
Part 2|2.7|Product Mapping|Products and services offered and the capabilities behind them.|Business services appear in the capability and value-stream registers; add a products register for product-led organisations.|Ch 10, 18|S02|S12|Partly covered
Part 2|2.8|Stakeholder Mapping|Internal and external parties, their interests and influence.|Stakeholders register with power, interest and engagement.|Ch 7|S02|S01|Covered
Part 2|2.9|Policy Mapping|Policies, regulations and rules that constrain or steer the business.|Business rules, principles and regulatory obligations.|Ch 6, 8, 10|S12|S02,S11,S07|Covered
Part 3|3|Business Architecture Practice Guide|How to run a business architecture practice.|Chapters 5, 7, 16 and 18.|Ch 5, 7, 16, 18|S01|S02|Covered
Part 3|3.1|Common Approaches for Getting Started|Ways to start: by initiative, by value stream, by capability, by strategy.|Chapter 18 start in four steps; vision chapter.|Ch 18|S01|S02|Covered
Part 3|3.2|Business Architecture Governance|Decision rights, review, standards and funding for the practice.|Governance chapter, gates G0 to G9, RACI.|Ch 16|S01|S07|Covered
Part 3|3.3|BA and Business Models|Relating the architecture to how the organisation creates and captures value.|Business model in vision; value stream.|Ch 6, 10|S02|S01|Covered
Part 3|3.4|BA and Business Process Management|Using capabilities and value streams to scope and prioritise process work.|Process register linked to capabilities.|Ch 10|S02|S11|Covered
Part 3|3.5|BA, Case Management and Dynamic Rules-Based Routing|Handling unpredictable cases with rules that route work.|The reference solution is case-centred: case lifecycle and routing rules.|Ch 8, 10|S11|S02,S04|Covered
Part 3|3.6|BA and Lean Six Sigma|Using the architecture to target waste and defects.|KPIs and process improvement requirements.|Ch 14|S02|S01|Covered
Part 3|3.7|BA Metrics: Improving Business Performance Management|Measures tied to capabilities and strategy.|KPI register and dashboard.|Ch 14|S02|S01|Covered
Part 3|3.8|BA and Requirements Alignment|Tracing requirements to capabilities and value streams.|Requirements register traces to capabilities and ADM phase.|Ch 8|S02|S04|Covered
Part 3|3.9|BA Maturity Model|Assessing and growing practice maturity.|DMBOK-style maturity targets and governance; extend with a maturity register.|Ch 16, 18|S01|S02|Partly covered
Part 3|3.10|The Role of the Business Architect|What the business architect does and the skills needed.|Roles in RACI; competency note in chapter 7.|Ch 7, 16|S01|S02|Covered
Part 3|3.11|BA and Strategy Execution|Turning strategy into funded, sequenced change.|Roadmap, work packages, benefits review gate.|Ch 15|S01|S02|Covered
Part 3|3.12|BA and Operating Models|How capabilities, organisation and technology combine to run the business.|Operating model in governance and run chapters.|Ch 4, 16|S01|S02,S09|Covered
Part 3|3.13|BA and Customer Experience Design|Linking customer journeys to value streams and capabilities.|UI/UX stream: personas, journeys.|Ch 2|S08|S02|Covered
Part 4|4|Business Architecture Scenarios|Worked scenarios showing how blueprints answer business questions.|The reference solution is itself a scenario; add more in your instance.|Ch 6, 7, 8, 10, 11, 12, 13, 14, 15|S02|S01|Covered
Part 5|5|Business Architecture Infrastructure Management|Keeping the architecture knowledge reliable and usable.|Chapter 4 and the repository.|Ch 4|S01|S03|Covered
Part 5|5.1|The BA Knowledgebase|The managed store of blueprint content with a shared metamodel.|The Git repository with registers and IDs is the knowledgebase.|Ch 1, 4|S01|S03|Covered
Part 5|5.2|BA Tooling Options|Choosing tools to model, store and publish.|Docs-as-code with a build script; options in the paperless chapter.|Ch 4|S05|S01|Covered
Part 6|6|BA and IT Architecture Alignment|Connecting business and IT architecture.|Chapters 11 to 13 and the crosswalk.|Ch 11, 12, 13|S01|S04|Covered
Part 6|6.1|BA and IT Architecture Alignment Overview|Why and how business drives IT architecture.|Principles and requirement traces.|Ch 6, 8|S01|S04|Covered
Part 6|6.2|BA and Enterprise Architecture Framework Alignment|Mapping to TOGAF and other frameworks.|Crosswalk and chapter 1.|Ch 1, 9|S01|S02|Covered
Part 6|6.3|BA and Systems Development Lifecycle|Business blueprints feeding the lifecycle.|Definition of ready and done; gates.|Ch 5|S04|S02|Covered
Part 6|6.4|BA and Application Portfolio Management|Using capabilities to assess and rationalise applications.|Components mapped to capabilities.|Ch 12|S04|S01|Covered
Part 6|6.5|BA and Service-Oriented Architecture Alignment|Business services realised as technical services.|Service orientation principles; interface catalogue.|Ch 1, 12|S10|S04|Covered
Part 6|6.6|Business Information and Data Architecture Alignment|Aligning business information concepts with data architecture.|Data entities link to capabilities; DMBOK.|Ch 11|S03|S02|Covered
Part 6|6.7|BA and Solution Architecture|Scoping solutions from capabilities and value streams.|Layered solution architecture and building blocks.|Ch 12|S04|S02|Covered
Part 6|6.8|BA and IT Architecture Transformation|Planning IT change from the business view.|Transition architectures and work packages.|Ch 15|S01|S05|Covered
Part 7|7|Business Architecture Case Studies|Real examples of the practice in use.|Add your own in your instance; this template ships one reference solution.|Ch 6, 7, 8, 10, 11, 12, 13, 14, 15|S01|S12|Reference only
Part 8|8|Industry Reference Models|Reusable capability and value models for specific industries.|Industry stream and domain mapping; add your sector model.|Ch 2|S12|S11|Covered
Part 8|8.1|Financial Services|Reference model for banks and similar firms.|Select in your instance through the Industry stream.|Ch 2|S12|S11|Pointer
Part 8|8.2|Manufacturing|Reference model for manufacturers.|Select in your instance through the Industry stream.|Ch 2|S12|S11|Pointer
Part 8|8.3|Healthcare|Reference model for care providers.|Select in your instance through the Industry stream.|Ch 2|S12|S11|Pointer
Part 8|8.4|International Development Organization|Reference model for development bodies.|Select in your instance through the Industry stream.|Ch 2|S12|S11|Pointer
Part 8|8.5|Insurance|Reference model for insurers.|Select in your instance through the Industry stream.|Ch 2|S12|S11|Pointer
Part 8|8.6|Common Reference Model|A cross-industry set of common capabilities.|The capability register can start from a common set.|Ch 2, 10|S12|S02|Pointer
Part 8|8.7|Transportation|Reference model for transport and logistics.|Select in your instance through the Industry stream.|Ch 2|S12|S11|Pointer
Part 8|8.8|Government|Reference model for public bodies.|Select in your instance through the Industry stream.|Ch 2|S12|S11|Pointer
Part 8|8.9|Telecommunications|Reference model for telecom operators.|Select in your instance through the Industry stream.|Ch 2|S12|S11|Pointer
Appendix|A|Glossary|Business architecture terms.|Glossary register and the TOGAF glossary.|Ch 9, 17|S01|S02|Covered
Appendix|B.1|Strategy Execution Framework: BA Role Definition|The business architect's role in executing strategy.|Role description in chapter 7 and RACI.|Ch 7, 16|S01|S02|Covered
Appendix|B.2|BA Roles and Competencies|Roles and the skills they need.|RACI; development path in chapter 5.|Ch 5, 16|S01|S02|Covered
Appendix|B.3|BA Maturity Model|Levels of practice maturity.|See 3.9.|Ch 16|S01|S02|Partly covered
Appendix|B.4|BA Metamodel|The entities and relationships of business architecture.|Our metamodel: capability, value stream, process, rule, data entity, requirement and traces.|Ch 1.8|S03|S01,S02|Covered
Appendix|B.5|Dynamic Rules-Based Routing Map Examples|Examples of rule-driven routing.|Business rules register.|Ch 8|S11|S02|Covered
Appendix|B.6|Alternative Value Mapping Approaches|Other ways to map value beyond the value stream.|Value stream plus capability view.|Ch 10|S02|S11|Covered
Appendix|B.7|BA Tool Evaluator|A structured way to compare modelling tools.|Use the paperless pipeline criteria in chapter 4.|Ch 4|S05|S01|Covered
Appendix|C|Study Questions|Questions for learning the material.|The QA checklist and review questions; add study questions to the deck.|Ch 5|S01|S02|Partly covered""".split("\n")
# ---- detail pass: richer descriptions (own words, from the guide's content summary) and the two appendices the guide adds
R += ["Appendix|D|Version History|A log of what changed in each release of the guide.|Our own version history is Git history and the version in config.json.|Ch 4|S01|S05|Covered",
      "Appendix|E|Editorial Board and Contributors|Who contributed to the guide.|Add a contributors list to your instance if you adopt guild-style peer review.|Ch 16|S01|S02|Pointer"]
DET = {
 "1":"Purpose of the guide, a definition of business architecture (holistic views of capabilities, end-to-end value delivery, information and organisation, and how they relate to strategies, products, policies, initiatives and stakeholders), ten domains, three framework components, six principles and the strategy execution path.",
 "2":"The baseline views of the business. Four foundational views (capability, organisation, value, information) are stable; five extended views (strategy, initiative, product, stakeholder, policy) change more often. Guild advice: start with value mapping or capability mapping, use organisation mapping to set scope in complex structures, and treat information mapping as following the capability map.",
 "2.1":"How strategy, goals, objectives and courses of action are mapped and tied to the rest of the architecture. Covers principles (a strategy belongs to a community of interest; it responds to the external environment), benefits (alignment, fidelity of objectives, early gap detection) and frameworks: Ansoff grid, SWOT, Five Forces, Kaplan-Norton strategy map, Business Motivation Model, Hoshin Kanri.",
 "2.2":"Defining, building and using a capability map: capabilities named as nouns, kept stable, grouped by domain, and cross-mapped to value streams, organisation, information and initiatives.",
 "2.3":"Mapping organisational structure into the architecture, business units to capabilities, plus internal and external parties, so ownership and accountability are visible.",
 "2.4":"Value streams and value stream stages: how a stakeholder gets value end to end, and which capabilities enable each stage. Often delivered before the capability map because it is faster.",
 "2.5":"A business view of information: concepts and their relationships, independent of systems, linked to capabilities and value stream stages.",
 "2.6":"Showing initiatives against the capabilities, value streams and objectives they affect, so scope and overlap are visible.",
 "2.7":"Products and entitlements, cross-mapped to the capabilities that enable them and to value streams.",
 "2.8":"Formal mapping of customers, partners and internal parties to business units, value streams and information.",
 "2.9":"Organising business policies and aligning them to capabilities and rules; most valuable in regulated sectors and government.",
 "3":"Practice-level guidance: getting started, governance, links to business models, process management, case management, Lean Six Sigma, metrics, requirements, maturity, the architect's role, strategy execution, operating models and customer experience.",
 "3.1":"How to begin, with a typical timeline from business planning to deployment; choose a starting scenario and scope first.",
 "3.2":"Team alignment, role definition and collaborative governance across the business.",
 "3.3":"Using the architecture to interpret a business model (how value is created, delivered and captured) into actionable work.",
 "3.4":"How business architecture and process management complement each other: capabilities and value streams frame which processes matter.",
 "3.5":"A business design approach for case-based work that uses dynamic rules-based routing (DRBR): events and rules decide the next action for each case.",
 "3.6":"Aligning Lean Six Sigma improvement work to the capability and value stream views.",
 "3.7":"Using the architecture to measure and improve business performance, with metrics attached to capabilities and objectives.",
 "3.8":"Using the architecture to frame and improve requirements analysis, so requirements trace to capabilities and value.",
 "3.9":"The Business Architecture Maturity Model (BAMM): a framework to rate how mature the practice and its deployment are.",
 "3.10":"What business architecture means for the people practising it: the architect's role and competencies.",
 "3.11":"How the architecture makes strategy execution transparent end to end; the five-step strategy execution framework.",
 "3.12":"How an operating model (people, process, technology) is aligned to the architecture's value-driven, capability-based view.",
 "3.13":"Aligning customer experience design to capabilities and value streams, so journeys map to what the business can deliver.",
 "4":"Approaches for common scenarios such as investment analysis, customer-centric shift, merger or acquisition, new product rollout, globalisation, outsourcing, supply chain streamlining, divestiture, regulatory compliance, change management, cost reduction, joint venture, IT portfolio analysis, digital transformation and digital twin deployment. Each ends in a roadmap.",
 "5":"The infrastructure that keeps business architecture content organised: the knowledgebase and the tools.",
 "5.1":"Organising and managing the architecture domains through a formal mapping approach, customised to the organisation's own terms.",
 "5.2":"Categories of tools that help create blueprints and support the practice, and how to choose.",
 "6":"Approaches to align business and IT architecture so IT solutions meet business needs.",
 "6.1":"The overall alignment approach and a summary of mapping approaches.",
 "6.2":"Using business architecture inside enterprise architecture frameworks, with specific guidance for TOGAF.",
 "6.3":"How business architecture feeds the systems development lifecycle.",
 "6.4":"A business-value way to assess and manage the application portfolio.",
 "6.5":"Using capabilities to inform and express service-oriented architecture from the business side.",
 "6.6":"How business information concepts shape data and application architecture.",
 "6.7":"How business architecture informs and influences solution architecture.",
 "6.8":"Business-driven transformation of business and IT architecture together.",
 "7":"Real-world case studies and lessons learned, added over time by the guild.",
 "8":"Industry reference models used as a baseline to build or enrich an in-house architecture. Each covers value streams, capabilities, information, stakeholders and other domains.",
 "8.1":"Credit unions, banks, card companies, consumer finance, brokerages and investment houses.",
 "8.2":"Discrete and process manufacturers that produce and deliver products.",
 "8.3":"Healthcare providers: diagnosis, treatment and prevention of illness and injury.",
 "8.4":"Mission-based, member-funded and non-governmental bodies working on economic, social and political development.",
 "8.5":"Insurers across subsectors: managing risk and providing coverage and payment.",
 "8.6":"Industry-independent views of value streams, capabilities, information and stakeholders common to most sectors.",
 "8.7":"Shipping, passenger, air, rail, sea, vehicle, logistics and other transport organisations.",
 "8.8":"Local, municipal, state, provincial and national government ecosystems.",
 "8.9":"Organisations that create, sell or support services transmitting information over telecom networks.",
 "A":"Terms and definitions used across the guide.",
 "B.1":"The strategy execution framework: its steps, the business architecture actions in each, deliverables and roles.",
 "B.2":"Roles and competencies typical in a mature practice.",
 "B.3":"The full Business Architecture Maturity Model (BAMM).",
 "B.4":"An expanded, work-in-progress metamodel of business architecture and selected relationships.",
 "B.5":"A worked routing map and worksheet for defining events and actions in case management.",
 "B.6":"Alternative value mapping approaches: value chain, value network and lean value stream.",
 "B.7":"A worksheet to assess business architecture tools for suitability.",
 "C":"Points to the online CBA study guide, which replaced the study questions that used to be embedded.",
}
rows=[]
for l in R:
    pa,se,to,wh,ap,wr,p,s,cv=l.split("|"); rows.append((pa,se,to,DET.get(se,wh),ap,wr,SN[p],sn(s),cv))
with open(f"{ROOT}/data/bizbok.csv","w",newline="",encoding="utf-8") as f:
    w=csv.writer(f); w.writerow(["Part","Section","Topic","What it covers","How this template applies it","Where","Primary stream","Supporting streams","Coverage"]); w.writerows(rows)
print(len(rows),"BIZBOK rows")
