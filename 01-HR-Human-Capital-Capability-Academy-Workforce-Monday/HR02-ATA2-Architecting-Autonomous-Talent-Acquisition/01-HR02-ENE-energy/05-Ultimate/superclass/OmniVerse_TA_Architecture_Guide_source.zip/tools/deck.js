(function(){
var S=[].slice.call(document.querySelectorAll(".slide")),st=document.getElementById("stage"),i=0,ov=false;
function go(n){i=Math.max(0,Math.min(S.length-1,n));S.forEach(function(s,k){s.classList.toggle("on",k===i)});
 document.getElementById("count").textContent=(i+1)+" / "+S.length;document.getElementById("prog").style.width=(100*(i+1)/S.length)+"%";history.replaceState(null,"","#"+(i+1));
 if(ov){S[i].scrollIntoView({block:"nearest"})}}
function toggleOv(){ov=!ov;st.classList.toggle("ov",ov);S[i].scrollIntoView({block:"nearest"})}
document.getElementById("next").onclick=function(){go(i+1)};document.getElementById("prev").onclick=function(){go(i-1)};document.getElementById("ov").onclick=toggleOv;
document.getElementById("fs").onclick=function(){var m=document.querySelector("main.deck");try{if(document.fullscreenElement)document.exitFullscreen();else m.requestFullscreen&&m.requestFullscreen()}catch(x){}};
S.forEach(function(s,k){s.addEventListener("click",function(){if(ov){go(k);toggleOv()}})});
document.addEventListener("keydown",function(e){var k=e.key;
 if(k==="ArrowRight"||k==="PageDown"||k===" "||k==="Enter"){e.preventDefault();go(i+1)}else if(k==="ArrowLeft"||k==="PageUp"){e.preventDefault();go(i-1)}
 else if(k==="Home")go(0);else if(k==="End")go(S.length-1);else if(k==="o"||k==="O")toggleOv();else if(k==="f"||k==="F")document.getElementById("fs").click();else if(k==="Escape"&&ov)toggleOv()});
var x0=null;st.addEventListener("touchstart",function(e){x0=e.touches[0].clientX},{passive:true});st.addEventListener("touchend",function(e){if(x0===null||ov)return;var d=e.changedTouches[0].clientX-x0;if(Math.abs(d)>40)go(i+(d<0?1:-1));x0=null});
var h=parseInt(location.hash.slice(1),10);go(isNaN(h)?0:h-1);
})();
