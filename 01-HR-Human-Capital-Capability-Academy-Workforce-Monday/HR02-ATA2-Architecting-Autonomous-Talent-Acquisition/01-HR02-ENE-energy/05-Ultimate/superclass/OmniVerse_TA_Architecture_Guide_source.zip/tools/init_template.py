#!/usr/bin/env python3
"""Turn this repository into a fresh instance for a new solution.
  python tools/init_template.py --programme "My Programme" --subject "My Solution" --org "My Org" [--region "Any country"]
Writes config.json, resets the 23 project registers to header-only, and replaces the project chapters (00, 04 to 08 and 10 to 16) with guided starters from starter/docs.
Fixed chapters 01 to 03, 09 and 17 to 19 (TOGAF foundations, 12 streams, 9P4V, BA Guild, coverage, template guide, appendices) and the reference registers are never touched."""
import argparse, csv, glob, json, os, shutil
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
ap = argparse.ArgumentParser()
ap.add_argument("--programme", required=True); ap.add_argument("--subject", required=True)
ap.add_argument("--org", default="Your organisation"); ap.add_argument("--region", default="Any country")
ap.add_argument("--keep-sample", action="store_true", help="keep the sample registers and chapters")
a = ap.parse_args()
cfg = {"programme": a.programme, "subject": a.subject, "subject_short": a.subject, "org": a.org, "region": a.region,
       "tagline": f"Business requirements and high-level architecture for {a.subject}.", "version": "v0.1"}
json.dump(cfg, open("config.json", "w", encoding="utf-8"), indent=2)
REFERENCE = {"chapter_map","adm_streams","streams","stream_lens","togaf_intro","togaf_concepts","togaf_glossary","togaf_acronyms","togaf_references","bizbok","bizbok_domains","bizbok_sector_example","bizbok_practice","p4v_spine","p4v_shocks","p4v_pillars","p4v_stages","p4v_pack","p4v_skills","p4v_score","p4v_levels_score","p4v_levels","p4v_gate","p4v_streams","p4v_lens","bizbok_strategy_terms","bizbok_principles","bizbok_strategy_execution","bizbok_scenarios","stream_matrix","stream_counts","crosswalk","glossary","dmbok_areas","ba_checklist"}
if not a.keep_sample:
    for f in glob.glob("data/*.csv"):
        n = os.path.basename(f)[:-4]
        if n in REFERENCE: continue
        hdr = open(f, newline="", encoding="utf-8").readline()
        open(f, "w", encoding="utf-8", newline="").write(hdr)
    PROJECT = {0, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15, 16}
    for f in glob.glob("docs/[01][0-9]-*.md"):
        if int(os.path.basename(f)[:2]) in PROJECT: os.remove(f)
    for f in glob.glob("starter/docs/*.md"): shutil.copy(f, "docs/")
print("Initialised:", cfg["programme"], "/", cfg["subject"], "\nNext: edit data/*.csv and docs/*.md, then python tools/build.py && python tools/check.py")
