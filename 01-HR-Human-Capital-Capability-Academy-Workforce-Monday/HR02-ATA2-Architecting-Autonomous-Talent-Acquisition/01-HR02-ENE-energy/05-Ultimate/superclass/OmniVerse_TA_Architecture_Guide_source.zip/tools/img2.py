import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
NAVY="#101820"; G="#4E8F1D"; LG="#EEF6E4"; P="#E9527F"; GR="#5B6770"; B="#3F6FA8"
def box(ax,x,y,w,h,t,fc=LG,ec=G,tc=NAVY,fs=8.5,bold=False):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0,rounding_size=0.8",fc=fc,ec=ec,lw=1.3))
    ax.text(x+w/2,y+h/2,t,ha="center",va="center",color=tc,fontsize=fs,fontweight="bold" if bold else "normal",linespacing=1.25)
def arr(ax,a,b,both=True,c=NAVY):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle="<->" if both else "-|>",mutation_scale=12,color=c,lw=1.3,shrinkA=0,shrinkB=0))
# ---- context
fig=plt.figure(figsize=(13,8),dpi=170); ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,130); ax.set_ylim(0,80); ax.axis("off")
ax.text(65,76,"System Context – who and what interacts with the platform",ha="center",fontsize=13,fontweight="bold",color=NAVY)
box(ax,47,30,36,20,"Encroachment Management\nPlatform",fc=NAVY,ec=NAVY,tc="white",fs=12,bold=True)
users=[("Field officers",5,60),("Case creators &\nreviewers",5,44),("Approvers &\nfinal approver",5,28),("Finance &\ncollections",5,12),("Legal &\nRegulatory Affairs",36,62),("Executives\n& administrators",72,62)]
for t,x,y in users:
    box(ax,x,y,24,9,t,fc="#FDECF1",ec=P,fs=8.5)
    arr(ax,(x+12,y) if y>50 and x>30 else (x+24,y+4.5),(65,50) if y>50 and x>30 else (47,40),c=P)
ext=[("Asset / GIS system",100,64),("Finance system (AR)",100,50),("Legacy case systems",100,36),("Permit registry",100,22),("Regulator portal",100,8),("Identity provider",56,8),("E-mail / SMS gateway",20,0.5)]
lab={"Asset / GIS system":"assets, geometry","Finance system (AR)":"claims, invoices, payments","Legacy case systems":"open cases (transition)","Permit registry":"permit status","Regulator portal":"submissions, decisions","Identity provider":"SSO, roles","E-mail / SMS gateway":"notifications"}
for t,x,y in ext:
    box(ax,x,y,28 if x>90 else 26,8,t+"\n("+lab[t]+")",fc="white",ec=GR,fs=7.8)
for t,x,y in ext[:5]:
    arr(ax,(83,40) if y>20 else (80,34),(x,y+4),c=GR)
arr(ax,(65,30),(69,16),c=GR); arr(ax,(55,30),(33,8.5),both=False,c=GR)
fig.savefig("assets/context.png"); plt.close(fig)
# ---- conceptual data model
fig=plt.figure(figsize=(13,8.4),dpi=170); ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,130); ax.set_ylim(0,84); ax.axis("off")
ax.text(65,80,"Conceptual Data Model (key entities and relationships)",ha="center",fontsize=13,fontweight="bold",color=NAVY)
E={"Asset":(4,60),"Location":(4,44),"Permit":(4,28),"Party":(4,12),
   "Case":(50,38),"CaseStageHistory":(50,62),"Evidence":(50,14),
   "CostAssessment":(92,62),"Claim":(92,46),"Payment":(92,30),
   "Submission":(92,18),"Decision":(92,2),"Appeal":(58,2)}
W,H=24,8
for n,(x,y) in E.items():
    box(ax,x,y,W,H,n,fc=NAVY if n=="Case" else LG,tc="white" if n=="Case" else NAVY,bold=n=="Case",fs=9)
def c(n,side):
    x,y=E[n]; w=W
    return {"l":(x,y+H/2),"r":(x+w,y+H/2),"t":(x+w/2,y+H),"b":(x+w/2,y)}[side]
def rel(a,sa,b,sb,l1,l2,dy=0):
    p,q=c(a,sa),c(b,sb); p=(p[0],p[1]+dy); arr(ax,p,q,both=False,c=GR)
    ax.text(p[0]+(q[0]-p[0])*0.12,p[1]+(q[1]-p[1])*0.12+1.2,l1,fontsize=7,color=P,fontweight="bold",ha="center")
    ax.text(p[0]+(q[0]-p[0])*0.88,p[1]+(q[1]-p[1])*0.88+1.2,l2,fontsize=7,color=P,fontweight="bold",ha="center")
rel("Case","l","Asset","r","*","1",dy=3.2); rel("Case","l","Location","r","*","1",dy=1.2); rel("Case","l","Permit","r","*","0..1",dy=-1.2); rel("Case","l","Party","r","*","*",dy=-3.2)
rel("Case","t","CaseStageHistory","b","1","*"); rel("Case","b","Evidence","t","1","*")
rel("Case","r","CostAssessment","l","1","1",dy=2); rel("CostAssessment","b","Claim","t","1","0..1"); rel("Claim","b","Payment","t","1","*")
rel("Case","r","Submission","l","1","*",dy=-2); rel("Submission","b","Decision","t","1","0..1"); rel("Decision","l","Appeal","r","1","*")
box(ax,4,2,48,6,"AuditEvent: records every create / update / state change of every entity",fc="#FDECF1",ec=P,fs=7.8)
ax.text(65,74,"Ownership and systems of record per entity are in the entity catalogue (workbook, 'data_entities').",ha="center",fontsize=8.5,color=GR,style="italic")
fig.savefig("assets/erd.png"); plt.close(fig)
