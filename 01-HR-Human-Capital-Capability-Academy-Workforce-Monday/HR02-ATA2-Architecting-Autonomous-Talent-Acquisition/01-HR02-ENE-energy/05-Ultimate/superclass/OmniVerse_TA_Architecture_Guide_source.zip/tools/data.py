# Single source of truth: every table below becomes a CSV (workbook) and a table in the site/slides.
D = {}
def T(name, cols, rows): D[name] = (cols, rows)

MS = {"H":"Must","M":"Should","L":"Could"}
# ---------- requirements -------------------------------------------------
req=[]
def R(i,typ,cls,stmt,pri,acc,comp,adm,dmbok="",src="Generic reference"):
    req.append([i,typ,cls,stmt,MS.get(pri,pri),acc,comp,adm,dmbok,src,"Draft"])
# Business requirements (BABOK: business requirement)
R("BR-001","Business","Business","Provide one authoritative record and process for every encroachment case across all business units.","H","One case register; no parallel registers in use after wave-2 go-live.","C01 Case Management","B / C","Data Governance")
R("BR-002","Business","Business","Reduce the time from detection to regulator submission.","H","Median cycle time reduced by [x]% against baseline within [12] months.","C02 Workflow","B","")
R("BR-003","Business","Business","Recover restoration and lost-benefit costs from violators.","H","Collection rate increased by [x] points; overdue claims escalated automatically.","C06 Claims","B","")
R("BR-004","Business","Business","Meet regulatory submission obligations first time.","H","[x]% of submissions accepted without return for missing information.","C05 Readiness Validator","B","Data Quality")
R("BR-005","Business","Business","Give leadership a trusted, real-time view of performance.","M","Executive dashboard refreshes at or faster than [15] minutes from source.","C09 Reporting","B / C","Data Warehousing & BI")
R("BR-006","Business","Business","Demonstrate governance: every action traceable to a person, time and reason.","H","100% of state changes present in the audit trail.","C12 Audit","B / D","Data Security")
# Stakeholder requirements (user stories, BABOK: stakeholder requirement)
R("SR-001","Stakeholder","Stakeholder","As a field officer, I want to log a case with photos and location on my phone, even offline, so I do not re-key it in the office.","H","Given no network, when I save a case, then it syncs automatically when connectivity returns.","C13 Mobile App","B / C","")
R("SR-002","Stakeholder","Stakeholder","As a reviewer, I want incomplete cases returned with a reason so the creator can fix them quickly.","H","Given a missing mandatory item, when I return the case, then the creator is notified with my comment.","C02 Workflow","B","Data Quality")
R("SR-003","Stakeholder","Stakeholder","As an approver, I want one screen showing evidence, cost and history so I can decide without searching other systems.","M","Given a case awaiting approval, then evidence, cost and history are visible on one page.","C14 Portal","B","")
R("SR-004","Stakeholder","Stakeholder","As a finance officer, I want approved claims to reach the finance system without re-entry.","H","Given an approved claim, then an invoice is created and its number is written back.","C06 Claims","C","Data Integration")
R("SR-005","Stakeholder","Stakeholder","As a collections officer, I want a prioritised list of overdue claims.","M","Overdue claims are listed by age and value with last follow-up shown.","C06 Claims","B","")
R("SR-006","Stakeholder","Stakeholder","As Legal, I want to be told when an appeal is raised with the full case file attached.","M","Given an appeal, then Legal is notified and the case file is linked.","C07 Regulator Gateway","B","")
R("SR-007","Stakeholder","Stakeholder","As an executive, I want to see trends by region and asset type.","M","Dashboards filter by region, asset type and period.","C09 Reporting","B","Data Warehousing & BI")
R("SR-008","Stakeholder","Stakeholder","As an administrator, I want to change rules and SLAs without a software release.","H","Rule changes take effect after approval without deployment.","C03 Rules Engine","C","Metadata")
# Functional (solution requirements)
F=[("FR-001","Provide a single electronic case register capturing date/time, GPS coordinates, location, affected asset, violator or contractor details, description and evidence.","H","Draft save allowed; progression blocked until mandatory fields complete.","C01 Case Management","Data Architecture"),
("FR-002","Support case creation and evidence capture on mobile and tablet, including photos, automatic geotagging and attachments, with offline capture and later sync.","H","Case created and processed from field to closure on mobile or desktop; multiple geotagged photos linked.","C13 Mobile App","Document & Content Mgmt"),
("FR-003","Classify each case and route it automatically to the responsible unit, department and work queue by asset type and location.","H","Every new case has a named owner and queue with no manual step.","C03 Rules Engine","Reference & Master Data"),
("FR-004","Calculate restoration and lost-benefit cost using configurable rules and generate regulator forms.","H","Cost and forms generated from system data without offline calculation.","C04 Cost Engine","Data Architecture"),
("FR-005","Validate completeness against a configurable regulatory checklist and block incomplete cases.","H","A case failing any mandatory item cannot advance.","C05 Readiness Validator","Data Quality"),
("FR-006","Generate financial claims for approved cases and send them to the finance system for invoicing, with tax treatment configurable per jurisdiction.","H","Invoice created in finance system; document number written back.","C06 Claims","Data Integration"),
("FR-007","Enforce the invoice-issuance SLA and flag breaches.","H","Invoices outside the configured SLA are flagged and escalated.","C08 SLA & Notification","Data Quality"),
("FR-008","Assign issued claims to Collections and maintain claim status to settlement.","M","Claim appears in collection queue automatically on issue.","C06 Claims","Data Architecture"),
("FR-009","Record payments received from the finance system and update claim and case status.","H","Payment posting updates balance and case status in one transaction.","C06 Claims","Data Integration"),
("FR-010","Escalate unpaid claims to Regulatory Affairs when the collection period expires.","H","Overdue claims routed without manual trigger.","C08 SLA & Notification","Data Architecture"),
("FR-011","Submit the case package and supporting documents to the regulator electronically and store the submission reference.","H","Submission acknowledged; reference stored on the case.","C07 Regulator Gateway","Data Integration"),
("FR-012","Receive and record regulator decisions and documents and drive the next workflow step from the decision.","H","Case status reflects the decision and triggers the next step.","C07 Regulator Gateway","Data Integration"),
("FR-013","Notify Legal when an appeal is raised and track the objection to closure.","M","Legal notified on appeal; objection status visible on case.","C07 Regulator Gateway","Data Architecture"),
("FR-014","Provide role-based dashboards and scheduled reports for the KPI catalogue with drill-down and export.","H","All KPIs render with filters, drill-down and export.","C09 Reporting","Data Warehousing & BI"),
("FR-015","Escalate cases that breach stage SLAs to the relevant supervisor.","H","Overdue cases escalate per the SLA matrix.","C08 SLA & Notification","Data Architecture"),
("FR-016","Maintain a complete, immutable audit trail of actions, approvals, data changes and uploads.","H","Each state change logs user, time, before and after values; cannot be edited.","C12 Audit","Data Security"),
("FR-017","Show cases and assets on a map with search by location.","M","Cases visible on a map layer with asset context.","C14 Portal","Data Architecture"),
("FR-018","Detect duplicate and repeat cases and flag repeat violators.","M","Probable duplicates flagged at creation; repeat-violator report available.","C01 Case Management","Reference & Master Data"),
("FR-019","Link cases to excavation or work permits where a permit registry exists.","M","Case shows linked permit or a no-permit flag.","C10 Integration Layer","Reference & Master Data"),
("FR-020","Allow controlled bulk import of historical cases and attachments.","L","Imported records pass the same validation and are tagged as migrated.","C10 Integration Layer","Data Integration")]
for i,s,p,a,c,k in F: R(i,"Solution","Functional",s,p,a,c,"C / D",k)
N=[("NFR-001","Comply with the organisation's cybersecurity policy and applicable national cybersecurity regulations.","H","Security sign-off before go-live.","C11 Identity & Security","Data Security"),
("NFR-002","Host on-premise, private cloud or in-country cloud to meet data-residency and sensitivity rules.","H","Hosting model approved by architecture and security.","Infrastructure","Data Storage & Operations"),
("NFR-003","Recover from loss of connection to the runtime server without data loss.","H","Demonstrated in failover tests.","Infrastructure","Data Storage & Operations"),
("NFR-004","Back up and restore application data, documents and reports.","H","Backup and restore tested and documented.","Infrastructure","Data Storage & Operations"),
("NFR-005","Enforce role-based access control and access governance; log all activity.","H","Roles defined; audit log covers all state changes.","C11 Identity & Security","Data Security"),
("NFR-006","Apply data-quality checks at migration and in operation per the data-quality standard.","H","Data-quality KPIs reported and monitored.","C10 Integration Layer","Data Quality"),
("NFR-007","Availability of at least [99.5]% on a 24x7 basis, measured monthly.","H","Monthly availability meets target.","Infrastructure","Data Storage & Operations"),
("NFR-008","Screens load in [3] s or less; dashboards in [10] s or less.","M","Met under peak-load test including mobile networks.","C14 Portal","Data Warehousing & BI"),
("NFR-009","Support [X] named and [Y] concurrent users at peak with growth headroom.","H","Confirmed in sizing; load test passed.","Infrastructure","Data Storage & Operations"),
("NFR-010","Retain case records and evidence for [10] years or as the regulator requires.","H","Retention policy configured and verified.","C15 Document Repository","Document & Content Mgmt"),
("NFR-011","Disaster recovery with RTO [4] h and RPO [1] h.","H","DR test meets targets.","Infrastructure","Data Storage & Operations"),
("NFR-012","UI in local language(s) and English, with right-to-left support where needed.","M","Language switch works on every screen.","C14 Portal","Metadata"),
("NFR-013","Accessibility to WCAG 2.1 AA for web screens.","M","Accessibility test passed.","C14 Portal","")  ,
("NFR-014","Open, standards-based APIs; no proprietary-only interfaces for core data.","M","Documented REST APIs for all core entities.","C10 Integration Layer","Data Integration"),
("NFR-015","Personal data minimised, protected and handled per local privacy law.","H","Privacy impact assessment approved; field-level protection verified.","C11 Identity & Security","Data Security"),
("NFR-016","Configuration changes controlled, versioned and auditable.","M","Every rule change has an approver, date and version.","C03 Rules Engine","Metadata")]
for i,s,p,a,c,k in N: R(i,"Solution","Non-functional",s,p,a,c,"D",k)
# Transition requirements
R("TR-001","Transition","Transition","Migrate open cases and agreed history from legacy systems with reconciliation.","H","100% of open cases reconciled by count and value; exceptions logged.","C10 Integration Layer","E / F","Data Integration")
R("TR-002","Transition","Transition","Train every user group before it goes live.","H","[90]% of users complete role-based training before access is granted.","Change & Training","F","")
R("TR-003","Transition","Transition","Run old and new processes in parallel for an agreed period.","M","Parallel-run exit criteria approved by business owner.","Change & Training","F","")
R("TR-004","Transition","Transition","Decommission superseded registers and spreadsheets.","M","Retired systems set to read-only, then archived, with sign-off.","Change & Training","G / H","Data Storage & Operations")
R("TR-005","Transition","Transition","Provide hypercare support after each go-live wave.","M","Hypercare period with named support team and daily triage.","Change & Training","G","")
T("requirements",["ID","Level","BABOK class","Requirement","MoSCoW","Acceptance criteria","Realised by","TOGAF ADM phase","DMBOK area","Source","Status"],req)

# ---------- stakeholders --------------------------------------------------
T("stakeholders",["Stakeholder","Role in change","Concern (TOGAF)","Power","Interest","Engagement approach"],[
["Business owner (infrastructure protection)","Sponsor / owner","Fewer incidents, recovery of cost, compliance","High","High","Co-design; approve scope and priorities"],
["Business units / subsidiaries","Users and data providers","Common process without losing local needs","Medium","High","Working group; wave-based rollout"],
["Field officers","Primary users","Simple mobile capture, works offline","Low","High","Field champions; pilot; short training"],
["Reviewers and approvers","Users","Clear queues, decide with full context","Medium","High","Workshops; UAT"],
["Finance","Users and system owner (finance)","Correct invoicing, tax, reconciliation","High","Medium","Interface design sessions"],
["Collections","Users","Prioritised follow-up and escalation","Medium","High","Workshops; UAT"],
["Regulatory Affairs / Legal","Users and regulator liaison","Accepted submissions, appeal handling","High","High","Early interface agreement with regulator"],
["Executives","Consumers of insight","Trusted KPIs, trends","High","Medium","Dashboard reviews"],
["Enterprise architecture","Design authority","Standards, reuse, no sprawl","High","High","ADM governance, ADR reviews"],
["Data owners / stewards","Data governance","Quality, ownership, lineage","Medium","High","Data governance council"],
["Security and compliance","Assurance","Cyber, privacy, residency","High","Medium","Security architecture review"],
["Delivery team and vendors","Builders","Clear scope, stable requirements","Medium","High","Backlog refinement; change control"],
["Regulator (external)","Receiver of submissions","Complete, standard-format cases","High","Low","Via Regulatory Affairs"],
["Violators / contractors (external)","Subject of claims","Fair, transparent process","Low","Medium","Notices and appeal path via Legal"]])

# ---------- principles (TOGAF format) ------------------------------------
T("principles",["ID","Domain","Name","Statement","Rationale","Implications"],[
["P-B1","Business","One case, one record","Every encroachment case has a single authoritative record.","Removes conflicting versions and rework.","Retire parallel registers; define one case identifier."],
["P-B2","Business","Process before tool","Standardise the process first, then automate it.","Automating a broken process locks in the problem.","Joint working group agrees process before configuration."],
["P-B3","Business","Evidence at the source","Evidence is captured at the moment and place of detection.","Evidence quality drops with time.","Mobile, offline-capable capture."],
["P-D1","Data","Data is an enterprise asset","Each data entity has a named owner and steward.","Accountability drives quality.","Data governance council; ownership in the data dictionary."],
["P-D2","Data","System of record stays put","Master data remains in its system of record; the platform holds references and snapshots.","Avoids duplicate masters and reconciliation.","Integrate by reference; no re-keying of asset or finance master data."],
["P-D3","Data","Quality at entry","Validate when data is captured, not when it is reported.","Cheaper and more reliable.","Mandatory fields, reference lists and rules in the capture step."],
["P-D4","Data","Protect by classification","Controls follow the data classification.","Proportionate protection.","Classify every entity and attribute; field-level protection for personal data."],
["P-A1","Application","Configure before code","Rules, SLAs, cost tables and checklists are configuration.","Adapts to each country without releases.","Rules engine and configuration governance."],
["P-A2","Application","Integrate through one layer","All system exchange goes via the integration layer.","Avoids point-to-point sprawl.","Standard connectors, monitoring and error handling."],
["P-A3","Application","Reuse, buy, then build","Prefer existing enterprise platforms, then products, then custom code.","Lower cost and risk.","Fit-gap against existing platforms before build."],
["P-T1","Technology","Secure and sovereign by design","Security and data residency are design inputs, not afterthoughts.","Sensitive evidence and personal data.","In-country hosting option; encryption; least privilege."],
["P-T2","Technology","Open standards","Use open, documented standards and APIs.","Avoids lock-in.","REST/JSON, standard identity protocols."],
["P-T3","Technology","Paperless by default","Every artefact is created, reviewed and approved online.","Speed, traceability, no version drift.","Artefacts in a versioned repository; approvals by pull request."]])

# ---------- capabilities --------------------------------------------------
T("capabilities",["L1 domain","L2 capability","Description","Target maturity (1-5)","Supported by"],[
["Case Lifecycle","Case registration","Detect, record and classify cases","4","C01, C13, C14"],
["Case Lifecycle","Evidence management","Capture, store and retain evidence","4","C15, C13"],
["Case Lifecycle","Assessment and costing","Calculate restoration and lost-benefit cost","4","C04"],
["Case Lifecycle","Approval and control","Delegated approvals and stage gates","4","C02"],
["Financial Recovery","Claim management","Raise claims and hand off to finance","4","C06, C10"],
["Financial Recovery","Collections","Track, follow up and escalate unpaid claims","4","C06, C08"],
["Regulatory","Readiness validation","Check completeness before submission","5","C05"],
["Regulatory","Regulator exchange","Submit, receive decisions, track appeals","4","C07"],
["Insight and Control","Performance reporting","KPIs and dashboards","4","C09"],
["Insight and Control","SLA and escalation","Time targets and automatic escalation","4","C08"],
["Insight and Control","Audit and assurance","Immutable audit trail","5","C12"],
["Data and Integration","Master and reference data","Assets, locations, parties, code lists","4","C03, C10"],
["Data and Integration","Data quality management","Rules, scoring and remediation","4","C10, C09"],
["Data and Integration","Integration management","Interfaces, monitoring, error handling","4","C10"],
["Enablement","Identity and access","Authentication, roles, delegation","4","C11"],
["Enablement","Change and training","Adoption and capability building","3","Change & Training"]])
T("value_stream",["Stage","Trigger / entry","Key activities","Stakeholders","Value item","Exit criterion"],[
["1 Detect","Report, patrol or monitoring alert","Verify, register, capture evidence","Field officer, case creator","Risk identified and evidenced","Case registered with mandatory data"],
["2 Validate and route","Case registered","Classify, de-duplicate, assign owner","Reviewer","Right owner, no duplicates","Case assigned to a queue"],
["3 Assess","Case assigned","Calculate cost and lost benefit","Reviewer, approver","Defensible cost","Cost assessment approved"],
["4 Approve","Assessment ready","Review and approve or return","Approver","Governed decision","Case approved"],
["5 Claim","Case approved","Raise claim; finance issues invoice","Finance","Recoverable amount invoiced","Invoice issued within SLA"],
["6 Collect","Invoice issued","Follow up; record payment; escalate","Collections","Cash recovered","Settled or escalated"],
["7 Submit","Readiness passed","Assemble package; submit; track","Final approver, Regulatory Affairs","Compliance","Submission acknowledged"],
["8 Decide and close","Regulator decision","Record decision; manage appeal; close","Regulatory Affairs, Legal","Resolution and learning","Case closed"]])
T("processes",["ID","Process","Level","Owner","Trigger","Output","Systems"],[
["PR-01","Register encroachment case","L2","Case creator","Detection","Case record with evidence","C13, C14, C01"],
["PR-02","Validate and route case","L2","Reviewer","Case registered","Assigned case","C03, C01"],
["PR-03","Assess cost and lost benefit","L2","Reviewer","Case assigned","Cost assessment","C04"],
["PR-04","Approve case or assessment","L2","Approver","Approval requested","Decision","C02"],
["PR-05","Raise financial claim","L2","Finance","Case approved","Invoice","C06, finance system"],
["PR-06","Collect and follow up","L2","Collections","Invoice issued","Payment or escalation","C06, C08"],
["PR-07","Validate regulatory readiness","L2","Final approver","Cost approved","Ready or returned","C05"],
["PR-08","Submit to regulator","L2","Regulatory Affairs","Ready for submission","Acknowledged submission","C07"],
["PR-09","Manage decision and appeal","L2","Regulatory Affairs / Legal","Decision received","Outcome, appeal record","C07, C02"],
["PR-10","Close case","L2","Case owner","Financial and operational closure","Closed case","C01"],
["PR-11","Manage rules and reference data","L2","Administrator / data steward","Change request","Approved configuration","C03"],
["PR-12","Monitor performance","L2","Management","Schedule","Dashboards and actions","C09"]])
T("business_rules",["ID","Rule","Type","Source","Enforced by"],[
["BRL-01","A case cannot move to Assessment until all mandatory fields and at least one geotagged photo are present.","Constraint","Policy","C05"],
["BRL-02","A creator cannot approve their own case (separation of duties).","Constraint","Governance","C02, C11"],
["BRL-03","Cost = sum of restoration items at current rate table + lost-benefit calculation; rate tables are versioned.","Computation","Tariff policy","C04"],
["BRL-04","An approved claim is sent to the finance system within [1] working day.","Time rule","Finance policy","C06, C08"],
["BRL-05","Invoices must be issued within [12] days of request; breaches escalate to the supervisor.","Time rule","Finance policy","C08"],
["BRL-06","Unpaid claims escalate to Regulatory Affairs when the collection period of [x] days expires.","Time rule","Regulation / policy","C08"],
["BRL-07","A case cannot be submitted to the regulator unless the readiness checklist passes.","Constraint","Regulation","C05"],
["BRL-08","Approval authority depends on claim value and case type per the delegation matrix.","Authority","Governance","C02"],
["BRL-09","Two cases with the same asset, location (within [x] m) and violator within [x] days are flagged as probable duplicates.","Inference","Data quality","C01"],
["BRL-10","A violator with [n] or more cases in [12] months is flagged as a repeat violator.","Inference","Policy","C01, C09"],
["BRL-11","Closed cases are read-only; corrections need an approved reopen with reason.","Constraint","Governance","C01, C12"],
["BRL-12","Evidence is retained for [10] years or the regulator's period, whichever is longer.","Retention","Regulation","C15"]])

# ---------- data architecture (DMBOK + TOGAF Phase C) ---------------------
T("data_entities",["Entity","Description","Data domain","Data owner (role)","Steward (role)","System of record","Classification","Retention"],[
["Case","The encroachment case and its status","Case","Head of infrastructure protection","Case governance lead","Platform","Confidential","[10] years after closure"],
["CaseStageHistory","Each status or stage change","Case","Head of infrastructure protection","Case governance lead","Platform","Confidential","[10] years"],
["Party","Violator, contractor, owner or subscriber","Party","Head of infrastructure protection","Data steward","Platform (reference to customer master)","Confidential / personal","[10] years"],
["Asset","Protected asset affected","Asset","Asset owner","Asset data steward","Asset / GIS system","Confidential","Per asset policy"],
["Location","Coordinates, area, city, corridor","Location","Asset owner","GIS steward","Asset / GIS system","Confidential","Per asset policy"],
["Evidence","Photos, video, documents","Content","Head of infrastructure protection","Records manager","Document repository","Confidential","[10] years"],
["CostAssessment","Restoration and lost-benefit cost","Financial","Finance head","Finance steward","Platform","Confidential","[10] years"],
["CostRule","Rate tables and calculation rules","Reference","Finance head","Finance steward","Platform","Internal","Versioned, [10] years"],
["Claim","Financial claim raised for a case","Financial","Finance head","Finance steward","Platform","Confidential","[10] years"],
["InvoiceRef","Reference to invoice in finance system","Financial","Finance head","Finance steward","Finance system","Confidential","Per finance policy"],
["Payment","Payment received against a claim","Financial","Finance head","Finance steward","Finance system (reference held)","Confidential","Per finance policy"],
["Submission","Case package sent to regulator","Regulatory","Regulatory Affairs head","Regulatory steward","Platform","Confidential","[10] years"],
["Decision","Regulator decision and documents","Regulatory","Regulatory Affairs head","Regulatory steward","Platform","Confidential","[10] years"],
["Appeal","Objection and its outcome","Regulatory","Legal head","Legal steward","Platform","Confidential","[10] years"],
["Permit","Excavation or work permit reference","Reference","Permit registry owner","Permit steward","Permit registry","Internal","Per registry"],
["SLAPolicy","Stage SLAs and escalation matrix","Reference","Business owner","Process steward","Platform","Internal","Versioned"],
["User / Role","Users, roles and delegations","Security","Security head","Access governance lead","Identity provider","Internal","Life of account + [x] years"],
["AuditEvent","Immutable log of actions","Security","Security head","Audit lead","Platform audit store","Restricted","[10] years"],
["ReferenceCode","Code lists (case type, asset type, status, violation type)","Reference","Data governance council","Reference data steward","Platform","Public / internal","Versioned"]])
T("data_dictionary",["Entity","Attribute","Type","Mandatory","Rule / domain","Personal data","DQ dimension"],[
["Case","CaseID","Identifier","Yes","Unique; system-generated; format [prefix-year-seq]","No","Uniqueness"],
["Case","DetectedAt","Datetime (UTC)","Yes","Not in the future; not before asset commissioning date","No","Validity"],
["Case","CaseType","Code","Yes","ReferenceCode list","No","Validity"],
["Case","Status","Code","Yes","Allowed transitions per workflow","No","Consistency"],
["Case","Latitude / Longitude","Decimal","Yes","Within operating area; valid CRS","No","Accuracy"],
["Case","OwnerQueue","Code","Yes","Derived by routing rule","No","Completeness"],
["Case","Description","Text","Yes","Min [20] characters","No","Completeness"],
["Party","PartyType","Code","Yes","Violator / Contractor / Owner","No","Validity"],
["Party","LegalName","Text","Yes","Matches registry where available","Yes","Accuracy"],
["Party","NationalOrTaxID","Text","Cond.","Format per country; masked in UI","Yes","Validity"],
["Party","Contact","Text","No","Valid e-mail or phone format","Yes","Validity"],
["Asset","AssetID","Identifier","Yes","Exists in asset / GIS system","No","Integrity"],
["Asset","AssetType","Code","Yes","ReferenceCode list","No","Validity"],
["Evidence","EvidenceID","Identifier","Yes","Unique","No","Uniqueness"],
["Evidence","CapturedAt","Datetime (UTC)","Yes","From device timestamp; compared with case time","No","Timeliness"],
["Evidence","GeoTag","Point","Yes (photos)","Within [x] m of case location","No","Accuracy"],
["Evidence","Hash","Text","Yes","Checksum computed on upload; detects tampering","No","Integrity"],
["CostAssessment","RestorationCost","Decimal","Yes","Computed from rate table version","No","Accuracy"],
["CostAssessment","LostBenefit","Decimal","Yes","Computed by rule","No","Accuracy"],
["CostAssessment","RateTableVersion","Text","Yes","Existing approved version","No","Consistency"],
["Claim","ClaimAmount","Decimal","Yes","Equals approved assessment","No","Consistency"],
["Claim","TaxTreatment","Code","Yes","Per jurisdiction setting","No","Validity"],
["Claim","InvoiceNumber","Text","Cond.","Written back from finance system","No","Integrity"],
["Payment","PaidAmount","Decimal","Yes","Not above outstanding balance","No","Validity"],
["Submission","SubmissionRef","Text","Yes","From regulator acknowledgement","No","Integrity"],
["Decision","DecisionCode","Code","Yes","Regulator code list","No","Validity"],
["AuditEvent","EventTime","Datetime (UTC)","Yes","Server-generated; cannot be edited","No","Integrity"],
["AuditEvent","UserID","Identifier","Yes","Authenticated user","Yes","Integrity"]])
T("dq_rules",["ID","Dimension","Rule","Applies to","Threshold","Action on failure","Owner"],[
["DQ-01","Completeness","All mandatory case fields populated before stage change","Case","100%","Block stage change","Case governance lead"],
["DQ-02","Validity","CaseType, AssetType, Status within code lists","Case, Asset","100%","Reject entry","Reference data steward"],
["DQ-03","Uniqueness","No duplicate CaseID; probable duplicates flagged","Case","0 duplicate IDs; flags reviewed in [2] days","Flag and review","Data steward"],
["DQ-04","Accuracy","Geotag within [x] m of recorded case location","Evidence","[95]%","Warn and require comment","GIS steward"],
["DQ-05","Integrity","AssetID exists in asset / GIS system","Case","100%","Reject entry","Asset data steward"],
["DQ-06","Consistency","ClaimAmount equals approved assessment","Claim","100%","Block claim","Finance steward"],
["DQ-07","Timeliness","Evidence captured within [24] h of detection","Evidence","[90]%","Report in KPI","Case governance lead"],
["DQ-08","Timeliness","Invoice issued within SLA","Claim","[95]%","Escalate","Finance steward"],
["DQ-09","Validity","National or tax ID format valid for country","Party","[98]%","Warn; correct within [5] days","Data steward"],
["DQ-10","Integrity","Payment postings reconcile to finance system","Payment","100%","Daily reconciliation exception report","Finance steward"],
["DQ-11","Consistency","Status transitions follow the allowed matrix","Case","100%","Block","Process steward"],
["DQ-12","Integrity","Evidence checksum matches stored file","Evidence","100%","Alert security","Records manager"]])
T("dmbok_areas",["DMBOK knowledge area","What it means here","Artefacts in this repository","Maturity target"],[
["Data Governance","Ownership, policies, decision rights, council","Data owners and stewards (data_entities); RACI; governance page","3"],
["Data Architecture","Enterprise data model and flows","Entity catalogue; conceptual model; data flow","3"],
["Data Modeling & Design","Conceptual, logical, physical models","Data dictionary; naming standard","3"],
["Data Storage & Operations","Databases, backup, DR, retention","Technology architecture; NFRs; retention schedule","3"],
["Data Security","Classification, access, audit, privacy","Classification; security architecture; audit trail","4"],
["Data Integration & Interoperability","Interfaces, ETL, APIs","Interface catalogue; integration patterns","3"],
["Document & Content Management","Evidence and document lifecycle","Document repository; retention classes","3"],
["Reference & Master Data","Code lists, assets, parties","ReferenceCode; system-of-record rules","3"],
["Data Warehousing & BI","Analytics and dashboards","KPI catalogue; reporting layer","3"],
["Metadata Management","Business glossary, lineage","Glossary; dictionary; configuration versioning","2"],
["Data Quality","Rules, measurement, remediation","DQ rules; quality KPIs","3"]])

# ---------- application / technology -------------------------------------
T("components",["ID","Component","Layer","ABB (what)","SBB options (examples only)","Key responsibilities"],[
["C01","Case Management","Application","Case register and record services","Workflow suite; low-code platform; custom service","Master case record, parties, status, duplicates"],
["C02","Workflow & Approval Engine","Application","Stage gates and tasks","BPM suite; workflow engine","Tasks, approvals, delegation, return for correction"],
["C03","Rules Engine & Configuration","Application","Routing, SLA and checklist rules","Rules engine; configuration tables","Classification, routing, versioned configuration"],
["C04","Cost & Lost-Benefit Engine","Application","Calculation service","Rules or calculation service","Rate tables, calculations, regulator form data"],
["C05","Regulatory Readiness Validator","Application","Checklist validation","Rules engine","Blocks incomplete cases"],
["C06","Claims & Collections","Application","Claim lifecycle","Platform module or custom service","Claims, follow-up, aging, escalation"],
["C07","Regulator Gateway","Integration","Submission and decision exchange","API gateway; managed file transfer","Package assembly, submission, acknowledgement, decisions"],
["C08","SLA, Escalation & Notification","Application","Timers and messaging","Scheduler; notification service","SLA clocks, escalation, multi-channel alerts"],
["C09","Reporting & Analytics","Application","KPI and dashboards","BI tool; warehouse or lake","Dashboards, scheduled reports, drill-down"],
["C10","Integration Layer","Integration","Secure exchange and data quality","API gateway; ESB or iPaaS; ETL","Interfaces, transformation, DQ, monitoring"],
["C11","Identity & Security","Cross-cutting","Authentication, authorisation, encryption","Directory and SSO; KMS; SIEM","RBAC, MFA, keys, security monitoring"],
["C12","Audit Service","Cross-cutting","Immutable audit","Append-only store","Audit trail of every action"],
["C13","Mobile App","Presentation","Field capture","PWA or native app","Offline capture, geotagging, sync"],
["C14","Web Portal","Presentation","Role-based UI","Enterprise portal or SPA","Screens, map view, embedded dashboards, notifications"],
["C15","Document Repository","Data","Evidence and document store","Enterprise DMS","Storage, retention, document audit"]])
T("interfaces",["ID","Interface","From","To","Direction","Mode","Frequency","Data","Classification"],[
["IF-01","Asset and location lookup","Asset / GIS system","Platform","In","API / service","On demand","Asset ID, type, geometry","Confidential"],
["IF-02","Claim to invoice","Platform","Finance system","Out","API / messaging","Event","Claim, party reference, tax code","Confidential"],
["IF-03","Invoice and payment status","Finance system","Platform","In","API / messaging","Event / daily","Invoice number, payment","Confidential"],
["IF-04","Legacy case sync","Existing case systems","Platform","In","API / batch","Near real time then retire","Open cases, history","Confidential"],
["IF-05","Permit lookup","Permit registry","Platform","In","API","On demand","Permit status","Internal"],
["IF-06","Customer reference","Customer / utility data platform","Platform","In","API / batch","Daily","Account reference","Confidential / personal"],
["IF-07","Regulator submission","Platform","Regulator portal","Out","Secure API / file","Event","Case package, forms","Confidential"],
["IF-08","Regulator decision","Regulator portal","Platform","In","Secure API / file","Event / daily","Acknowledgement, decision","Confidential"],
["IF-09","Authentication","Identity provider","Platform","In","SSO protocol","Per login","Identity, roles","Internal"],
["IF-10","Notifications","Platform","E-mail / SMS gateway","Out","SMTP / API","Event","Message","Internal"],
["IF-11","Analytics feed","Platform","Warehouse / lake","Out","ETL / CDC","[15] min","Case, claim, SLA facts","Confidential"]])
T("tech_standards",["Area","Standard","Notes"],[
["Hosting","On-premise, private cloud or in-country cloud region","Chosen by data-residency policy"],
["Identity","Enterprise SSO (SAML or OIDC), MFA for privileged and external users","No local passwords"],
["Integration","REST/JSON APIs, managed file transfer for bulk, event messaging for status","No point-to-point links"],
["Data at rest","Encryption with organisation-held keys","Field-level for personal data"],
["Data in transit","TLS 1.2 or higher","Mutual TLS for regulator link where required"],
["Database","Relational for transactions; lake or warehouse for analytics","Open formats for analytics storage"],
["Documents","Enterprise DMS with retention classes and legal hold","Checksums on upload"],
["Geospatial","Open geospatial standards (OGC services)","Coordinate reference system set per country"],
["Mobile","Offline-first PWA or native app with encrypted cache","Remote wipe"],
["Observability","Central logging, metrics, tracing, alerting","Feeds security monitoring"],
["Resilience","Clustered tiers, replicated data, tested DR","RTO and RPO per NFR-011"],
["DevOps","Infrastructure as code, CI/CD, automated tests","Environments: dev, test, UAT, pre-prod, prod"],
["Accessibility","WCAG 2.1 AA","Tested before go-live"],
["Documentation","Docs-as-code in a versioned repository","Paperless Architecture Initiative"]])
T("adr",["ID","Decision","Context","Options considered","Decision rationale","Status"],[
["ADR-01","Configure or build the case core on a workflow platform","Encroachment needs custom stages and regulator exchange","Extend CRM; buy packaged product; workflow platform","Best fit and control; avoids CRM customisation","Proposed"],
["ADR-02","Single integration layer","Many surrounding systems","Point-to-point; integration layer","One place for security, monitoring, reuse","Proposed"],
["ADR-03","Separate document repository for evidence","Retention and legal hold","Files in database; DMS","Retention, audit, scale","Proposed"],
["ADR-04","Finance system remains system of record for invoices and payments","Avoid duplicate ledgers and tax risk","Invoice in platform; finance system","Single financial truth","Proposed"],
["ADR-05","Rules and SLAs as configuration","Many jurisdictions and regulators","Hard-coded; configuration","Change without release","Proposed"],
["ADR-06","Hosting follows data-residency policy","Sensitive evidence and personal data","Public cloud abroad; in-country","Compliance","Proposed"],
["ADR-07","Offline-first mobile capture","Poor connectivity in the field","Online-only; offline-first","Adoption and evidence quality","Proposed"],
["ADR-08","Artefacts as code in a versioned repository","Paperless, traceable change","Office files; wiki; repository","Review by pull request; one source of truth","Accepted"]])
T("kpis",["ID","KPI","Definition / formula","Frequency","Owner","Target"],[
["K-01","Total / open / closed cases","Count by status","Real time","Case governance lead","n/a"],
["K-02","Case closure rate","Closed cases / cases opened in period","Monthly","Business owner","[x]%"],
["K-03","Average detection-to-submission time","Mean days from DetectedAt to submission","Weekly","Business owner","[x] days"],
["K-04","Average approval turnaround","Mean time in approval stage","Weekly","Approver lead","[x] days"],
["K-05","Regulator first-time acceptance rate","Submissions accepted without return / all submissions","Monthly","Regulatory Affairs","[x]%"],
["K-06","Assessed vs approved cost","Sum assessed / sum approved","Monthly","Finance head","n/a"],
["K-07","Claims issued (count, value)","Claims raised in period","Daily","Finance head","n/a"],
["K-08","Collection rate","Collected / invoiced","Monthly","Collections lead","[x]%"],
["K-09","Outstanding receivables","Invoiced less collected","Daily","Finance head","[x]"],
["K-10","Invoice issuance within SLA","Invoices within SLA / invoices due","Weekly","Finance head","[95]%"],
["K-11","SLA achievement","Stage completions within SLA / all","Monthly","Process steward","[90]%"],
["K-12","Repeat-violation rate","Repeat cases / all cases","Monthly","Business owner","Decrease"],
["K-13","Data quality score","Passed DQ checks / checks run","Monthly","Data steward","[98]%"],
["K-14","Mobile capture share","Cases created on mobile / all","Monthly","Change lead","[x]%"],
["K-15","Platform availability","Uptime / scheduled time","Monthly","Service owner","[99.5]%"]])
T("risks",["ID","Risk","Likelihood (1-5)","Impact (1-5)","Score","Mitigation","Owner"],[
["RK-01","Regulator interface not ready or not certified","3","5","15","Agree specification early; manual submission fallback","Regulatory Affairs"],
["RK-02","Business units do not agree a common process","3","5","15","Joint working group; wave-based rollout","Business owner"],
["RK-03","Asset and GIS data quality too low for validation","4","4","16","DQ baseline; steward fixes; tolerance rules","Data steward"],
["RK-04","Field users do not adopt mobile capture","3","4","12","Offline-first design; champions; pilot","Change lead"],
["RK-05","Finance integration delayed","3","4","12","Prioritise claim and payment APIs in wave 1","Finance head"],
["RK-06","Security or residency clearance delays go-live","2","5","10","Early security review; gate in plan","Security head"],
["RK-07","User numbers unknown, so sizing and licensing wrong","4","3","12","Collect counts per unit before sizing","Delivery lead"],
["RK-08","Scope creep across units and regulators","4","3","12","Change control; MoSCoW; backlog governance","Business analyst"],
["RK-09","Legacy migration quality","3","4","12","Reconciliation; migration rehearsals","Data steward"],
["RK-10","Personal data breach","2","5","10","Classification, field-level protection, monitoring","Security head"],
["RK-11","Key subject-matter experts unavailable","3","3","9","Named SMEs and backups in plan","Business owner"],
["RK-12","Benefits not measured","3","3","9","Baseline before go-live; benefit owner named","Business owner"]])
T("work_packages",["ID","Work package","Transition architecture","Phase / wave","Depends on","Deliverable"],[
["WP-01","Mobilise, governance and architecture vision","TA0 Baseline","Preliminary / A","None","Charter, vision, principles, stakeholder plan"],
["WP-02","Requirements baseline and process standard","TA0 Baseline","B / BA planning","WP-01","Approved BRD and process model"],
["WP-03","Data model, glossary and DQ baseline","TA0 Baseline","C","WP-02","Entity catalogue, dictionary, DQ baseline"],
["WP-04","Integration foundations (identity, asset/GIS, finance)","TA1 Core","D / wave 1","WP-03","Working interfaces IF-01, 02, 03, 09"],
["WP-05","Case, workflow, rules and cost core","TA1 Core","E / wave 1","WP-03, WP-04","Core platform in test"],
["WP-06","Mobile capture and evidence repository","TA1 Core","E / wave 1","WP-05","Mobile app, DMS"],
["WP-07","Pilot go-live in lead units","TA1 Core","F / wave 1","WP-05, WP-06","Live in lead units; hypercare"],
["WP-08","Regulator gateway and readiness validation","TA2 Regulatory","wave 2","RK-01 closed","Electronic submission live"],
["WP-09","Claims, collections and escalations","TA2 Regulatory","wave 2","WP-04","Claims and collections live"],
["WP-10","Dashboards and analytics","TA2 Regulatory","wave 2","WP-05","KPI dashboards"],
["WP-11","Roll-out to remaining units; retire legacy","TA3 Target","wave 3","WP-07..10","Legacy read-only, then archived"],
["WP-12","Run, measure, improve","TA3 Target","G / H","WP-11","Benefit report; change log"]])
T("gap_analysis",["Domain","Baseline (typical)","Target","Gap","Closing work package"],[
["Business","Different processes per unit","One standard process","Process standardisation","WP-02"],
["Business","No SLAs or inconsistent SLAs","Configured SLAs with escalation","SLA definition","WP-02, WP-05"],
["Data","Several registers, spreadsheets","One case record, owned data","Consolidation, ownership","WP-03, WP-11"],
["Data","Free-text locations and parties","Validated codes and geotags","Reference data, validation","WP-03"],
["Application","Several disconnected tools","One case platform","Build or configure core","WP-05"],
["Application","No regulator exchange","Electronic submission","Gateway","WP-08"],
["Integration","Manual re-keying to finance","Automated claim and payment","Interfaces","WP-04, WP-09"],
["Technology","No mobile capture","Offline-first mobile","Mobile app","WP-06"],
["Security","Weak audit trail","Immutable audit, RBAC","Audit and access design","WP-05"],
["People","Limited digital skills","Trained role-based users","Training, champions","WP-07, WP-11"]])
T("raci",["Activity","Business owner","Business analyst","Enterprise architect","Data steward","Security","Finance","Delivery lead"],[
["Approve scope and priorities","A","R","C","C","C","C","I"],
["Elicit and document requirements","A","R","C","C","C","C","I"],
["Approve requirements baseline","A","R","C","C","C","C","I"],
["Define architecture principles and ADRs","C","C","A/R","C","C","I","C"],
["Define data entities, glossary and DQ rules","C","R","C","A/R","C","C","I"],
["Define interfaces and integration patterns","C","C","A","C","C","R","R"],
["Security and privacy design review","I","I","C","C","A/R","I","C"],
["Configure and build","I","C","C","C","C","C","A/R"],
["Test and UAT","A","R","I","C","C","C","R"],
["Compliance review at gates","I","C","A/R","C","R","I","C"],
["Go-live decision","A","C","C","C","C","C","R"],
["Benefit tracking","A/R","C","I","I","I","C","I"],
["Change control","A","R","C","C","C","C","R"]])
T("crosswalk",["Stage","TOGAF 10 ADM","BABOK v3 knowledge area","DMBOK2 area","Primary artefacts","Quality gate"],[
["Plan","Preliminary","Business Analysis Planning and Monitoring","Data Governance","Principles, BA approach, stakeholder plan, RACI","G0 Mobilise"],
["Vision","A Architecture Vision","Strategy Analysis","Data Governance","Vision, BACCM, stakeholder map, value stream, risks","G1 Vision approved"],
["Elicit","B Business Architecture","Elicitation and Collaboration","Metadata","Elicitation plan, interviews, workshops, glossary","G2 Requirements elicited"],
["Define","B Business Architecture","Requirements Analysis and Design Definition","Data Modeling & Design","BRD, process model, business rules, user stories","G3 Requirements baseline"],
["Data","C Information Systems (Data)","Requirements Analysis and Design Definition","Data Architecture; Reference & Master Data; Data Quality","Entity catalogue, dictionary, DQ rules, classification","G4 Data design approved"],
["Application","C Information Systems (Application)","Requirements Analysis and Design Definition","Data Integration & Interoperability","Component and interface catalogues, HLDD","G5 HLDD approved"],
["Technology","D Technology Architecture","Requirements Analysis and Design Definition","Data Storage & Operations; Data Security","Technology standards, security, resilience","G6 Security and tech approved"],
["Plan change","E Opportunities & Solutions; F Migration Planning","Strategy Analysis; Requirements Life Cycle Management","Data Integration","Gap analysis, work packages, roadmap, transition requirements","G7 Roadmap approved"],
["Deliver","G Implementation Governance","Solution Evaluation","Data Quality; Data Security","Compliance reviews, test results, acceptance","G8 Release readiness"],
["Improve","H Architecture Change Management","Solution Evaluation; Requirements Life Cycle Management","Data Governance; Metadata","KPI reports, change requests, ADR updates","G9 Benefit review"],
["Control","Requirements Management","Requirements Life Cycle Management","Metadata Management","Traceability matrix, change log","Continuous"]])
T("ba_checklist",["ID","Check","Applies at","Evidence"],[
["QA-01","Each requirement has a unique ID, one statement, one owner","G3","Requirements table"],
["QA-02","Each requirement is atomic, testable and unambiguous","G3","Review comment log"],
["QA-03","Each requirement has acceptance criteria (Given/When/Then or measurable)","G3","Acceptance column"],
["QA-04","Each requirement is classified (business, stakeholder, solution, transition) and prioritised (MoSCoW)","G3","Classification and MoSCoW columns"],
["QA-05","Each requirement traces to an objective, a component, a data entity and a test","G3, G8","Traceability matrix"],
["QA-06","No requirement names a product unless a constraint is approved","G3","Review"],
["QA-07","Terms are defined once in the glossary and used consistently","G2","Glossary"],
["QA-08","Stakeholders are identified with concerns and engagement approach","G1","Stakeholder table"],
["QA-09","Business rules are separate from process steps and numbered","G3","Business rules table"],
["QA-10","Every data entity has an owner, steward, classification and retention","G4","Entity catalogue"],
["QA-11","Every mandatory attribute has a data-quality rule","G4","Dictionary and DQ rules"],
["QA-12","Every interface has an owner, direction, mode, frequency and classification","G5","Interface catalogue"],
["QA-13","Decisions are recorded as ADRs with options and rationale","G5","ADR register"],
["QA-14","Security, privacy and residency reviewed against NFRs","G6","Security review record"],
["QA-15","Risks have owner, score and mitigation","G1, G7","Risk register"],
["QA-16","Assumptions and dependencies listed with fall-backs","G1, G7","Assumptions table"],
["QA-17","Requirements verified (peer review) and validated (stakeholder sign-off)","G3","Sign-off record"],
["QA-18","Placeholders in [brackets] are either filled or listed as open items","G3, G8","Open items list"],
["QA-19","Change requests assessed for impact on scope, data, cost and risk","Continuous","Change log"],
["QA-20","Client, vendor and personal details are absent from reference artefacts","Publication","Review"]])
T("glossary",["Term","Meaning"],[
["Encroachment","Unauthorised or unsafe activity near, on or over protected infrastructure"],
["BRD","Business Requirements Document"],["HLDD","High-Level Design Document"],
["TOGAF ADM","The Open Group Architecture Framework: Architecture Development Method"],
["ABB / SBB","Architecture building block (what) / solution building block (how)"],
["BACCM","Business Analysis Core Concept Model: change, need, solution, stakeholder, value, context"],
["MoSCoW","Must, Should, Could, Won't: prioritisation scale"],
["DMBOK","Data Management Body of Knowledge (DAMA International)"],
["Data owner","Role accountable for a data domain"],["Data steward","Role that manages data quality and definitions day to day"],
["SLA","Service-level agreement: a time target for a stage or action"],
["RTO / RPO","Recovery time objective / recovery point objective"],
["DMS","Document management system"],["ESB / iPaaS","Enterprise service bus / integration platform as a service"],
["RBAC","Role-based access control"],["ADR","Architecture decision record"],
["DoR / DoD","Definition of ready / definition of done"],
["Paperless architecture","Architecture artefacts created, reviewed, approved and consumed online from a versioned repository, with no file exchange"]])
