import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Wedge
BLK="#0B0B0B"; GRN="#78B62E"; GRN2="#92D337"; PINK="#ED547C"; SKY="#B9D8F2"; NAVY="#496592"; TEAL="#6EC399"
LIGHT="#EEF6E3"; GREY="#5B6770"; AMBER="#FFF3D6"
def new(w,h,W,H,dpi=170):
    fig=plt.figure(figsize=(w,h),dpi=dpi); ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,W); ax.set_ylim(0,H); ax.axis("off"); return fig,ax
def box(ax,x,y,w,h,txt,fc=LIGHT,ec=GRN,tc=BLK,fs=8.5,bold=False,lw=1.3,ls="-"):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0,rounding_size=0.8",fc=fc,ec=ec,lw=lw,ls=ls))
    ax.text(x+w/2,y+h/2,txt,ha="center",va="center",color=tc,fontsize=fs,fontweight="bold" if bold else "normal",linespacing=1.25)
def arrow(ax,a,b,c=GRN,lw=1.6,style="<->"):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle=style,mutation_scale=12,color=c,lw=lw))

# ---------- 1 architecture
fig,ax=new(13,9.2,130,92)
def layer(y,h,title):
    ax.add_patch(FancyBboxPatch((2,y),92,h,boxstyle="round,pad=0,rounding_size=1",fc="white",ec=BLK,lw=1.4))
    ax.add_patch(FancyBboxPatch((2,y),13,h,boxstyle="round,pad=0,rounding_size=1",fc=BLK,ec=BLK))
    ax.text(8.5,y+h/2,title,color=GRN2,fontsize=8.5,fontweight="bold",ha="center",va="center",linespacing=1.3)
ax.text(65,89,"Reference Architecture – Infrastructure Encroachment Management Platform",ha="center",fontsize=13,fontweight="bold",color=BLK)
layer(74,11,"1. Users &\nChannels")
for i,t in enumerate(["Field Officers\n(mobile / tablet)","Case Creators &\nReviewers","Approvers &\nFinal Approver","Finance &\nCollections","Legal &\nRegulatory Affairs","Executives\n& Admins"]): box(ax,16.5+i*12.9,75.5,12,8,t,fs=7.3)
layer(62,10,"2. Presentation")
for i,t in enumerate(["Responsive Web Portal\n(role-based, bilingual)","Offline-capable\nMobile / PWA","Embedded Dashboards\n& Reports","Notification Centre\n(in-app / email / SMS)"]): box(ax,16.5+i*19.4,63.5,18,7,t,fs=7.8)
layer(40,20,"3. Application\n& Workflow\nServices")
svc=["Case Management\n& Register","Workflow &\nApproval Engine","Classification &\nRouting Rules","Cost & Lost-Benefit\nCalculation Engine","Regulatory Checklist\n& Readiness Validator","Claims &\nCollections Service","Regulatory Submission\n& Decision Tracker","SLA, Escalation &\nNotification Service"]
for i,t in enumerate(svc): box(ax,16.5+(i%4)*19.4,50.2-(i//4)*9.6,18,8.2,t,fs=7.6)
layer(28,10,"4. Integration\nLayer")
for i,t in enumerate(["API Gateway\n(REST / SOAP)","Enterprise Service Bus\n/ iPaaS","Secure File Transfer\n& Connectors","ETL / Data Quality\nServices"]): box(ax,16.5+i*19.4,29.5,18,7,t,fs=7.8)
layer(14,12,"5. Data &\nContent")
for i,t in enumerate(["Operational Database\n(cases, workflow, audit)","Data Lake / Warehouse\n(analytics, history)","Document & Evidence\nRepository (DMS)","Geospatial Store\n(map layers, geotags)"]): box(ax,16.5+i*19.4,16,18,8,t,fs=7.8)
ax.add_patch(FancyBboxPatch((2,1.5),92,10,boxstyle="round,pad=0,rounding_size=1",fc=AMBER,ec="#E0A526",lw=1.4))
ax.text(48,9.4,"Cross-Cutting: Security, Governance & Operations",ha="center",fontsize=8.8,fontweight="bold",color=BLK)
for i,t in enumerate(["Identity & Access\n(SSO, RBAC, MFA)","Encryption &\nKey Management","Immutable Audit\nTrail & Logging","Monitoring, Backup\n& DR","Hosting: On-prem /\nPrivate / Sovereign Cloud"]): box(ax,4+i*17.6,2.4,16.4,5.6,t,fc="white",ec="#E0A526",fs=7)
ax.add_patch(FancyBboxPatch((98,14),30,71,boxstyle="round,pad=0,rounding_size=1",fc="#F3F5F7",ec=GREY,lw=1.4,ls="--"))
ax.text(113,82,"Enterprise & External Systems",ha="center",fontsize=9,fontweight="bold",color=BLK)
for i,t in enumerate(["Asset / GIS System\n(network assets, maps)","ERP – Finance (AR)\n(invoice, payment, tax)","CRM / Field Service /\nExisting Case Systems","Excavation & Permit\nRegistry","Customer / Utility\nData Platform","Regulator Portal\n(external, secure channel)","Identity Provider\n(Directory / SSO)","Email / SMS Gateway"]): box(ax,100.5,74-i*8.4,25,6.6,t,fc="white",ec=GREY,fs=7.6)
arrow(ax,(94,33),(98,33),BLK,1.8)
for ya,yb in ((74,72),(62,60),(40,38),(28,26)): arrow(ax,(48,ya),(48,yb),GRN,1.3)
fig.savefig("site/assets/arch.png"); plt.close(fig)

# ---------- 2 lifecycle
fig,ax=new(13,3.6,130,36)
steps=["1. Detect &\nRegister Case\n(field / desk)","2. Validate &\nRoute to Owner","3. Assess Cost &\nLost Benefit","4. Review &\nApprove","5. Issue\nFinancial Claim","6. Collect &\nFollow Up","7. Regulatory\nSubmission","8. Decision, Appeal\n& Closure"]
w=13.6;g=1.9
for i,t in enumerate(steps):
    x=3+i*(w+g); end=i in (0,7)
    box(ax,x,12,w,14,t,fc=BLK if end else LIGHT,tc=GRN2 if end else BLK,fs=8,ec=BLK if end else GRN)
    if i<7: arrow(ax,(x+w,19),(x+w+g,19),PINK,2,"-|>")
ax.text(65,32,"End-to-End Case Lifecycle (generic to-be flow)",ha="center",fontsize=11,fontweight="bold",color=BLK)
ax.text(65,5,"Controls throughout: mandatory-data checks · SLA timers & escalation · role-based approvals · notifications · immutable audit trail · live dashboards",ha="center",fontsize=8.5,color=GREY,style="italic")
fig.savefig("site/assets/flow.png"); plt.close(fig)

# ---------- 3 TOGAF ADM
fig,ax=new(13,7.8,130,78)
ax.text(65,74,"TOGAF ADM applied to the Encroachment Platform",ha="center",fontsize=13,fontweight="bold",color=BLK)
box(ax,44,31,42,16,"Requirements Management\n(central, continuous)\nIDs · priority · traceability",fc=BLK,tc=GRN2,fs=10,bold=True,ec=BLK)
W_=20;H_=17
top=[("Preliminary","Principles, governance,\ntailoring",8),("A. Architecture\nVision","Scope, stakeholders,\nvalue, vision",32),("B. Business\nArchitecture","Capabilities,\nprocesses, roles",56),("C. Information\nSystems","Data and application\narchitecture",80),("D. Technology\nArchitecture","Platforms,\nhosting, security",104)]
bot=[("E. Opportunities\n& Solutions","Work packages,\ngap analysis",104),("F. Migration\nPlanning","Roadmap, waves,\nbusiness case",80),("G. Implementation\nGovernance","Contract,\ncompliance review",56),("H. Change\nManagement","Adoption,\ncontinuous improvement",32)]
def node(t,d,x,y):
    ax.add_patch(FancyBboxPatch((x,y),W_,H_,boxstyle="round,pad=0,rounding_size=0.8",fc=LIGHT,ec=GRN,lw=1.4))
    ax.text(x+W_/2,y+12,t,ha="center",va="center",fontsize=8.3,fontweight="bold",color=BLK,linespacing=1.15)
    ax.text(x+W_/2,y+4.2,d,ha="center",va="center",fontsize=6.6,color=GREY,linespacing=1.15)
for t,d,x in top: node(t,d,x,54)
for t,d,x in bot: node(t,d,x,6)
for i in range(4): arrow(ax,(top[i][2]+W_,62),(top[i+1][2],62),PINK,1.8,"-|>")
arrow(ax,(114,54),(114,23),PINK,1.8,"-|>")
for i in range(3): arrow(ax,(bot[i][2],14),(bot[i+1][2]+W_,14),PINK,1.8,"-|>")
arrow(ax,(32,23),(24,54),PINK,1.2,"-|>")
fig.savefig("site/assets/adm.png"); plt.close(fig)

# ---------- 4 conceptual data model
fig,ax=new(13,7.4,130,74)
ax.text(65,70,"Conceptual Data Model (DAMA-DMBOK: Data Architecture & Modelling)",ha="center",fontsize=13,fontweight="bold",color=BLK)
EW,EH=26,12
ent={"PARTY\n(violator / contractor)":(4,50),"ASSET &\nLOCATION":(36,50),"EVIDENCE\n(photo, document, form)":(68,50),"WORKFLOW TASK\n& SLA CLOCK":(100,50),
     "CASE":(52,28),"REGULATORY\nSUBMISSION":(100,28),
     "COST\nASSESSMENT":(4,6),"CLAIM &\nINVOICE REF":(36,6),"PAYMENT":(68,6),"DECISION &\nAPPEAL":(100,6)}
def edge(k,toward):
    x,y=ent[k]; cx,cy=x+EW/2,y+EH/2; dx,dy=toward[0]-cx,toward[1]-cy
    t=min((EW/2)/abs(dx) if dx else 1e9,(EH/2)/abs(dy) if dy else 1e9); return (cx+dx*t,cy+dy*t)
def ctr(k): x,y=ent[k]; return (x+EW/2,y+EH/2)
links=[("CASE","PARTY\n(violator / contractor)","involves"),("CASE","ASSET &\nLOCATION","affects"),("CASE","EVIDENCE\n(photo, document, form)","has"),("CASE","WORKFLOW TASK\n& SLA CLOCK","driven by"),("CASE","COST\nASSESSMENT","priced by"),("COST\nASSESSMENT","CLAIM &\nINVOICE REF","becomes"),("CLAIM &\nINVOICE REF","PAYMENT","settled by"),("CASE","REGULATORY\nSUBMISSION","submitted as"),("REGULATORY\nSUBMISSION","DECISION &\nAPPEAL","results in")]
for a,b,l in links:
    p=edge(a,ctr(b)); q=edge(b,ctr(a)); ax.add_patch(FancyArrowPatch(p,q,arrowstyle="-",color=NAVY,lw=1.3))
    ax.text((p[0]+q[0])/2,(p[1]+q[1])/2,l,fontsize=6.8,color=NAVY,ha="center",va="center",style="italic",bbox=dict(fc="white",ec="none",pad=0.8))
for k,(x,y) in ent.items():
    c=k=="CASE"; box(ax,x,y,EW,EH,k,fc=BLK if c else LIGHT,tc=GRN2 if c else BLK,fs=8.3,bold=True,ec=BLK if c else GRN)
fig.savefig("site/assets/datamodel.png"); plt.close(fig)

# ---------- 5 paperless pipeline
fig,ax=new(13,3.8,130,38)
ax.text(65,34,"Paperless Architecture Initiative – Docs-as-Code Pipeline",ha="center",fontsize=12,fontweight="bold",color=BLK)
st=[("Author","Markdown, CSV,\nJSON in the\nrepository"),("Review","Pull request =\narchitecture review\n(ARB gate)"),("Validate","Checks: IDs,\ntraceability,\nlinks, no client data"),("Publish","GitHub Actions /\nPages builds the\nsite"),("Consume","Online document,\ndeck and workbook\nin any browser"),("Improve","Issues, comments,\nversion history,\nreleases")]
w=18;g=3.2
for i,(h,d) in enumerate(st):
    x=2+i*(w+g)
    ax.add_patch(FancyBboxPatch((x,8),w,20,boxstyle="round,pad=0,rounding_size=1",fc=BLK if i in (0,4) else LIGHT,ec=GRN,lw=1.5))
    ax.text(x+w/2,23,h,ha="center",fontsize=10,fontweight="bold",color=GRN2 if i in (0,4) else BLK)
    ax.text(x+w/2,15,d,ha="center",va="center",fontsize=7.6,color="white" if i in (0,4) else GREY,linespacing=1.25)
    if i<5: arrow(ax,(x+w,18),(x+w+g,18),PINK,2,"-|>")
fig.savefig("site/assets/pipeline.png"); plt.close(fig)
print("ok")


# ---- trim whitespace around the lifecycle diagram so it fills its slide
from PIL import Image, ImageChops
def autocrop(path, pad=40):
    im = Image.open(path).convert("RGB")
    bg = Image.new("RGB", im.size, (255, 255, 255))
    box = ImageChops.difference(im, bg).getbbox()
    if box:
        l, t, r, b = box
        im.crop((max(0, l-pad), max(0, t-pad), min(im.width, r+pad), min(im.height, b+pad))).save(path)
autocrop("site/assets/flow.png")
