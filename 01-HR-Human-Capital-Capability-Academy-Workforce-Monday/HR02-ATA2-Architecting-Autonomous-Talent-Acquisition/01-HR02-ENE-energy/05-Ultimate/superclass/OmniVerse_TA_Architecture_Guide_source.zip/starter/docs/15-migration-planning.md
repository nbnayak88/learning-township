# Migration Planning (Phase F)

*TOGAF Phases E and F. Starter: replace this guidance with your content.*

## Content
Work packages, transition architectures and roadmap.

{{csv:work_packages}}
