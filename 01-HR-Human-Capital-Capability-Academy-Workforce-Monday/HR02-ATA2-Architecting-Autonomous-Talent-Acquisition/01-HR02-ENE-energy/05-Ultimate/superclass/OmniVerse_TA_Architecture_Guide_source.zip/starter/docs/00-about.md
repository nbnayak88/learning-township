# About this Document

*Purpose, scope and readers. Starter: replace this guidance with your content.*

## Content
State why this document exists for {{cfg:subject}}, who reads it, and which frameworks it follows (TOGAF, BABOK, DAMA-DMBOK2). Replace every [placeholder] with a local value.
