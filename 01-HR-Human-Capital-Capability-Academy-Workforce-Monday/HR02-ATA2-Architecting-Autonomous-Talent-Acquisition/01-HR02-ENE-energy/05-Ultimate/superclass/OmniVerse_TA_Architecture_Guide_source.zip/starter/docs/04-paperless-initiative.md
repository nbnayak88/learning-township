# Paperless Architecture Initiative (Preliminary Phase)

*Docs-as-code. Starter: replace this guidance with your content.*

## Content
How this instance is edited, reviewed and published online.
