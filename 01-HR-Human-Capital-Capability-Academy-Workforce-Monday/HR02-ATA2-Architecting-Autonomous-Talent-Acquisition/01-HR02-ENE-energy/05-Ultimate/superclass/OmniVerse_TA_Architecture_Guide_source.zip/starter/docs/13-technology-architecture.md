# Technology Architecture (Phase D)

*TOGAF Phase D. Starter: replace this guidance with your content.*

## Content
Standards, security, hosting and resilience.

{{csv:tech_standards}}

{{csv:adr}}
