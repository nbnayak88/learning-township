# Data Architecture (Phase C)

*TOGAF Phase C and DMBOK2. Starter: replace this guidance with your content.*

## Content
Entities, dictionary, quality rules and governance.

{{csv:data_entities}}

{{csv:dq_rules}}
