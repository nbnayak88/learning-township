# Business Architecture (Phase B)

*TOGAF Phase B. Starter: replace this guidance with your content.*

## Content
Capabilities, value stream, processes and rules.

{{csv:capabilities}}

{{csv:processes}}
