# Quality Standards (Preliminary Phase)

*BA guild practice. Starter: replace this guidance with your content.*

## Content
Definition of ready and done, checklists.

{{csv:ba_checklist}}
