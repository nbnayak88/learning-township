# Governance and Change (Phases G and H)

*TOGAF Phases G and H. Starter: replace this guidance with your content.*

## Content
Roles, gates, change control.

{{csv:raci}}
