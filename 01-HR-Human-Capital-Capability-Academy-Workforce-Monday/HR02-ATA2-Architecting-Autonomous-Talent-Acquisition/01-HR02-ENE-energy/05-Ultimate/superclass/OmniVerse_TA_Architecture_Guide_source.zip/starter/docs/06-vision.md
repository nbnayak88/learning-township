# Architecture Vision (Phase A)

*TOGAF Preliminary and Phase A. Starter: replace this guidance with your content.*

## Content
Problem, vision, objectives, scope, principles and stakeholders for {{cfg:subject}}.

{{csv:principles}}

{{csv:stakeholders}}
