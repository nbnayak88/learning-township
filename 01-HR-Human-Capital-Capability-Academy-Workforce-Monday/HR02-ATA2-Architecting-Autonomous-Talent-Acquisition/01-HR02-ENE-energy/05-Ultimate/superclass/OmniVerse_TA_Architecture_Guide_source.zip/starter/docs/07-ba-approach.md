# Business Analysis Approach (Requirements Management)

*BABOK v3. Starter: replace this guidance with your content.*

## Content
Elicitation, analysis, traceability and prioritisation approach. See chapter 1 for terms.
