# Application Architecture (Phase C)

*TOGAF Phase C. Starter: replace this guidance with your content.*

## Content
Components, building blocks and interfaces.

{{csv:components}}

{{csv:interfaces}}
