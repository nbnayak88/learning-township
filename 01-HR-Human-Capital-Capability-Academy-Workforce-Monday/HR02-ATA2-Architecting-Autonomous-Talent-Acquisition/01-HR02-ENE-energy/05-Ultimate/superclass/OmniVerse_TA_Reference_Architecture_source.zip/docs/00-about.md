# About this Document

> **In brief.** A vendor-agnostic reference architecture for OmniVerse Energy's Autonomous Talent Acquisition Platform: SmartRecruiters as the hiring hub, 28 partner categories behind capability interfaces, delivered with SAP Activate.

## 0.1 Purpose
This reference architecture describes the business, data, application and technology architecture of {{cfg:subject}}, a fictional programme for **OmniVerse Energy**, an illustrative energy company hiring in about 14 countries. It shows how a hiring hub (SmartRecruiters) connects to assessment centres, job boards, AI interview tools, background-verification providers and every other partner category on the SmartRecruiters marketplace, without tying the enterprise to any single vendor. All names of partners are **examples only**; none is recommended, endorsed or claimed to be listed.

OmniVerse Energy is the fictional rename of the energy case study used across SuccessLabs Academy. Figures marked in [square brackets] are illustrative placeholders to replace with local values.

## 0.2 Who reads it
| Reader | Uses it for |
|---|---|
| Chief People Officer and sponsor | Vision, scope, waves, decisions to approve (Chapters 6, 14, 15) |
| Head of Global TA and regional TA leads | Process, requirements and partner choices (Chapters 8, 10, 21) |
| Enterprise architects | Domain architecture, patterns, standards, decisions (Chapters 11 to 13, 20) |
| Security, privacy and legal | Controls, residency, AI rules (Chapter 22) |
| Delivery team and implementation partner | Activate plan, work packages, gates (Chapters 15 and 23) |
| Procurement | Selection scorecard and exit plans (Chapter 21) |

## 0.3 Frameworks followed
- **TOGAF** ADM for the method and the four domains; chapter titles show the phase, for example "Name (Phase X)".
- **BABOK** for requirements and analysis; **DAMA-DMBOK2** for data; **BIZBOK** for capability and value-stream views; **9P4V** for the nine pillars and four values.
- **SAP Activate** (Discover, Prepare, Explore, Realize, Deploy, Run) for delivery, with fit-to-standard and a clean core.

## 0.4 How to read it
Chapters 1 to 5 are foundations and method, kept generic. Chapters 6 to 16 walk the ADM for this programme. Chapters 20 to 23 are the deep dives: integration patterns, the partner ecosystem, responsible AI and privacy, and the SAP Activate case study. Every register is a table you can sort in the Workbook view.

{{img:ecosystem.png|Vendor-agnostic partner ecosystem: 28 marketplace categories behind capability interfaces}}

## 0.5 Facts used and what is assumed
| Statement | Status |
|---|---|
| SAP completed its acquisition of SmartRecruiters on 11 September 2025 | Public fact |
| SmartRecruiters remains a standalone product that works with SuccessFactors and other HCM systems | Public statement by SAP |
| The developer platform offers Customer, Assessment, Job Board, Offer, Marketplace, Approvals, User and Configuration APIs, webhooks and OAuth 2.0 | Public developer documentation; confirm at design time |
| OmniVerse Energy, its 14 countries, volumes, targets and dates | Fictional, illustrative |
| Partner names in registers | Examples only, no endorsement |
