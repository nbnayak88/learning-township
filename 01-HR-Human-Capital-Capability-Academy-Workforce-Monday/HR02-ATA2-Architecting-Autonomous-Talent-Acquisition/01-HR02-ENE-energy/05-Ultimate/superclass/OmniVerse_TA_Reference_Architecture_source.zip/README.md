<p align="center"><img src="assets/logo.png" alt="SuccessLabs Academy" width="160"></p>

# Autonomous Talent Acquisition Reference Architecture

**Architecture created, reviewed, approved and used online, from one versioned source. Nothing to upload. Nothing to download.**

Reference implementation: **OmniVerse Energy Autonomous Talent Acquisition Platform** (fictional), a vendor-agnostic reference architecture for SmartRecruiters as the hiring hub with 28 partner categories (assessment, job boards, AI interview, background verification and more), delivered with SAP Activate.

**Read it online:** https://nbnayak88.github.io/paperless-architecture-initiative/

| View | What it is | Source |
|---|---|---|
| **Document** | 20 chapters in TOGAF ADM order: foundations (TOGAF, 12 architecture streams, 9P4V), Preliminary, Phase A vision, requirements, Phase B business (with the Business Architecture Guild), Phase C data and application, Phase D technology, Phases E and F opportunities and migration, Phases G and H governance and change, coverage, template guide, appendices | `docs/*.md` |
| **Deck** | Browser slide deck (← → keys, F full screen, O overview) | Generated from the same data |
| **Workbook** | 60+ registers and matrices with search, sort, filter and a dashboard | `data/*.csv` |

## Standards applied
- **TOGAF® 10 ADM**: Preliminary, A to H, Requirements Management; principles, building blocks, gap analysis, architecture contract.
- **BABOK® v3 and the IIBA Business Analysis Standard**: six knowledge areas, Core Concept Model, requirement classes, traceability, prioritisation.
- **DAMA-DMBOK2**: all eleven data management knowledge areas applied.
- **Business Architecture Guild (BIZBOK® Guide)**: nine blueprints, practice guide, BA and IT alignment, industry reference models (chapter 9), plus this template's quality gates G0 to G9 (chapter 5).

- **9P4V Framework (SuccessLabs Academy; Nayak, 2025)**: vision, value, victory, venture through nine pillars; the transformation spine applied to every chapter (chapter 3).

## How to work (all in the browser)
| To do this | Do this |
|---|---|
| Fix or add text | Edit the file in `docs/` on GitHub, open a pull request |
| Change a requirement, risk, entity, KPI, rule | Edit the CSV in `data/`, open a pull request |
| Review and approve | Comment and approve on the pull request |
| Publish | Merge. GitHub Actions rebuilds and publishes the site |
| Record a decision | Add a row to `data/adr.csv` |

## Repository layout
```
docs/        chapters (Markdown)
data/        registers and catalogues (CSV): the source of truth for tables, deck and workbook
tools/       build.py (site generator), deck.py, check.py (link and content checks), seed data
site/        generated web site (published by the workflow)
assets/      logo and diagram sources
diagrams.py  diagram generator
.github/     workflow that builds, checks and publishes on every merge
```

Local preview (optional): `pip install markdown && python tools/build.py`, then open `site/index.html`.

## Confidentiality
This repository is **generic and public**: no client, organisation, regulator, vendor or personal details; local values are `[placeholders]`. Engagement-specific work belongs in a **private repository created from this template**. `tools/check.py` fails the build on broken links, incomplete requirements and any term listed in `tools/blocklist.txt`.

## Trademarks
TOGAF is a registered trademark of The Open Group. BABOK is a registered trademark of IIBA. DAMA and DMBOK are marks of DAMA International. This work applies their public concepts in its own words and does not reproduce their text.

© SuccessLabs Academy · *Architecting for a Better World*
