# AI skill library for OmniVibe Consumer Ltd.

18 skills in Claude skill format (folder per skill with SKILL.md). Proposed baseline; fictional enterprise.

- ovc-demand-and-requisition-drafting-agent: Demand and requisition drafting agent (Agent skill)
- ovc-job-content-and-criteria-drafting-assistant: Job content and criteria drafting assistant (Agent skill)
- ovc-sourcing-and-matching-agent: Sourcing and matching agent (Agent skill)
- ovc-candidate-screening-summary-assistant: Candidate screening summary assistant (Agent skill)
- ovc-interview-scheduling-agent: Interview scheduling agent (Agent skill)
- ovc-candidate-q-a-assistant: Candidate Q&A assistant (Agent skill)
- ovc-interview-evidence-consistency-checker: Interview evidence consistency checker (Agent skill)
- ovc-offer-drafting-and-band-check-assistant: Offer drafting and band-check assistant (Agent skill)
- ovc-hire-handoff-reconciliation-agent: Hire handoff reconciliation agent (Agent skill)
- ovc-onboarding-readiness-tracking-agent: Onboarding readiness tracking agent (Agent skill)
- ovc-fairness-and-adverse-impact-monitoring-agent: Fairness and adverse-impact monitoring agent (Agent skill)
- ovc-recruiting-insight-narrative-agent: Recruiting insight narrative agent (Agent skill)
- ovc-requirement-writer: Requirement writer (Utility skill)
- ovc-user-story-writer: User story writer (Utility skill)
- ovc-test-script-writer: Test script writer (Utility skill)
- ovc-fit-gap-classifier: Fit-gap classifier (Utility skill)
- ovc-activate-deliverable-drafter: SAP Activate deliverable drafter (Utility skill)
- ovc-talent-architecture-mapper: Talent architecture mapper (Utility skill)
