---
name: ovc-requirement-writer
description: Use to write or review a business requirement for OmniVibe Consumer Ltd. so it names one persona, one stage, one testable behaviour, a priority and a verification method.
---
# Requirement writer

Case: OmniVibe Consumer Ltd. (Consumer Discretionary). Sector populations include: seasonal store associates; store managers and assistant managers; beauty advisers and consultants; e-commerce and digital-merchandising specialists; distribution-centre operatives; micro-fulfilment pickers.

## When to use
Use to write or review a business requirement for OmniVibe Consumer Ltd. so it names one persona, one stage, one testable behaviour, a priority and a verification method.

## Steps
1. Ask for persona ID, stage (DEM, REQ, SRC, APP, ASM, OFR, HND, ONB, GOV, MEA) and population.
2. Write one sentence with one testable behaviour; split anything with two.
3. Add priority (Must, Should, Could) and verification (Inspection, Demonstration, Test, Walkthrough, Analysis).
4. Check it against existing requirement IDs for duplicates.
5. Return the requirement and the user story and test it should link to.

## Output
Requirement text, priority, verification, duplicate check result.

## Guardrails
- Use only the inputs supplied; mark anything else as Not provided.
- Do not decide on hiring, pay, employment records or access.
- Do not infer protected characteristics or use proxies.
- Everything is proposed and not tenant-tested.

## Human check
A named human reviews the result against the workbook before it is used.
