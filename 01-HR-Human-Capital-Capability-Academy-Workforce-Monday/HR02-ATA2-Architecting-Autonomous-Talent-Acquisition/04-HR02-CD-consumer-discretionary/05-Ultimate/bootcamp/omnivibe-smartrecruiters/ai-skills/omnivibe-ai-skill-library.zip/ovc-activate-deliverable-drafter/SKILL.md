---
name: ovc-activate-deliverable-drafter
description: Use to draft a SAP Activate deliverable (SL-<PHASE>-<TYPE>-<NN>) for OmniVibe Consumer Ltd. with acceptance criteria, evidence and gate.
---
# SAP Activate deliverable drafter

Case: OmniVibe Consumer Ltd. (Consumer Discretionary). Sector populations include: seasonal store associates; store managers and assistant managers; beauty advisers and consultants; e-commerce and digital-merchandising specialists; distribution-centre operatives; micro-fulfilment pickers.

## When to use
Use to draft a SAP Activate deliverable (SL-<PHASE>-<TYPE>-<NN>) for OmniVibe Consumer Ltd. with acceptance criteria, evidence and gate.

## Steps
1. Ask for the deliverable ID or title from the workbook sheet Deliverables.
2. Draft: purpose, scope, inputs, activities, owners, risks, acceptance criteria, evidence list.
3. Name the gate and approvers; state stop or pivot conditions.
4. Mark status Not started until evidence exists.

## Output
Draft deliverable with acceptance criteria and evidence list.

## Guardrails
- Use only the inputs supplied; mark anything else as Not provided.
- Do not decide on hiring, pay, employment records or access.
- Do not infer protected characteristics or use proxies.
- Everything is proposed and not tenant-tested.

## Human check
A named human reviews the result against the workbook before it is used.
