---
name: ocn-talent-architecture-mapper
description: Use to map a designation or job description at OmniConnect Media & Networks Ltd. to a job code, family, grade, band, skills and competencies.
---
# Talent architecture mapper

Case: OmniConnect Media & Networks Ltd. (Communication Services). Sector populations include: network engineers for coverage expansion; network-operations-centre (NOC) engineers; 5G and radio-access engineers; fibre field technicians; content and rights managers; streaming and media-platform engineers.

## When to use
Use to map a designation or job description at OmniConnect Media & Networks Ltd. to a job code, family, grade, band, skills and competencies.

## Steps
1. Read the designation and duties.
2. Match to the nearest job in the job classification; give code, family, function, grade, band and ISCO-08 group.
3. List required skills with levels and the competencies expected for the band.
4. Say if the job is safety or regulation critical and which evidence gate applies.
5. If there is no good match, propose a new job and list what is missing.

## Output
Mapping table with rationale and open questions.

## Guardrails
- Use only the inputs supplied; mark anything else as Not provided.
- Do not decide on hiring, pay, employment records or access.
- Do not infer protected characteristics or use proxies.
- Everything is proposed and not tenant-tested.

## Human check
A named human reviews the result against the workbook before it is used.
