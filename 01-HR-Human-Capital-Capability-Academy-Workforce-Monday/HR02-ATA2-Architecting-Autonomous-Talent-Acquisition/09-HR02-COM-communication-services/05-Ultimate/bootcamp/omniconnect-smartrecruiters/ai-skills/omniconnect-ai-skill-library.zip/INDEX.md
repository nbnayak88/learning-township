# AI skill library for OmniConnect Media & Networks Ltd.

18 skills in Claude skill format (folder per skill with SKILL.md). Proposed baseline; fictional enterprise.

- ocn-demand-and-requisition-drafting-agent: Demand and requisition drafting agent (Agent skill)
- ocn-job-content-and-criteria-drafting-assistant: Job content and criteria drafting assistant (Agent skill)
- ocn-sourcing-and-matching-agent: Sourcing and matching agent (Agent skill)
- ocn-candidate-screening-summary-assistant: Candidate screening summary assistant (Agent skill)
- ocn-interview-scheduling-agent: Interview scheduling agent (Agent skill)
- ocn-candidate-q-a-assistant: Candidate Q&A assistant (Agent skill)
- ocn-interview-evidence-consistency-checker: Interview evidence consistency checker (Agent skill)
- ocn-offer-drafting-and-band-check-assistant: Offer drafting and band-check assistant (Agent skill)
- ocn-hire-handoff-reconciliation-agent: Hire handoff reconciliation agent (Agent skill)
- ocn-onboarding-readiness-tracking-agent: Onboarding readiness tracking agent (Agent skill)
- ocn-fairness-and-adverse-impact-monitoring-agent: Fairness and adverse-impact monitoring agent (Agent skill)
- ocn-recruiting-insight-narrative-agent: Recruiting insight narrative agent (Agent skill)
- ocn-requirement-writer: Requirement writer (Utility skill)
- ocn-user-story-writer: User story writer (Utility skill)
- ocn-test-script-writer: Test script writer (Utility skill)
- ocn-fit-gap-classifier: Fit-gap classifier (Utility skill)
- ocn-activate-deliverable-drafter: SAP Activate deliverable drafter (Utility skill)
- ocn-talent-architecture-mapper: Talent architecture mapper (Utility skill)
