# AI skill library for OmniEsports Holdings Inc.

18 skills in Claude skill format (folder per skill with SKILL.md). Proposed baseline; fictional enterprise.

- oes-demand-and-requisition-drafting-agent: Demand and requisition drafting agent (Agent skill)
- oes-job-content-and-criteria-drafting-assistant: Job content and criteria drafting assistant (Agent skill)
- oes-sourcing-and-matching-agent: Sourcing and matching agent (Agent skill)
- oes-candidate-screening-summary-assistant: Candidate screening summary assistant (Agent skill)
- oes-interview-scheduling-agent: Interview scheduling agent (Agent skill)
- oes-candidate-q-a-assistant: Candidate Q&A assistant (Agent skill)
- oes-interview-evidence-consistency-checker: Interview evidence consistency checker (Agent skill)
- oes-offer-drafting-and-band-check-assistant: Offer drafting and band-check assistant (Agent skill)
- oes-hire-handoff-reconciliation-agent: Hire handoff reconciliation agent (Agent skill)
- oes-onboarding-readiness-tracking-agent: Onboarding readiness tracking agent (Agent skill)
- oes-fairness-and-adverse-impact-monitoring-agent: Fairness and adverse-impact monitoring agent (Agent skill)
- oes-recruiting-insight-narrative-agent: Recruiting insight narrative agent (Agent skill)
- oes-requirement-writer: Requirement writer (Utility skill)
- oes-user-story-writer: User story writer (Utility skill)
- oes-test-script-writer: Test script writer (Utility skill)
- oes-fit-gap-classifier: Fit-gap classifier (Utility skill)
- oes-activate-deliverable-drafter: SAP Activate deliverable drafter (Utility skill)
- oes-talent-architecture-mapper: Talent architecture mapper (Utility skill)
