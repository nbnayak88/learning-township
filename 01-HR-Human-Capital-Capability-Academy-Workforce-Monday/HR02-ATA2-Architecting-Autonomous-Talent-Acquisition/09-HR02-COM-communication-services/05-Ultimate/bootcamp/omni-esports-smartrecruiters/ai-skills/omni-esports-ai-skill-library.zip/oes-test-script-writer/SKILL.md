---
name: oes-test-script-writer
description: Use to write a numbered test script for a OmniEsports requirement with preconditions, steps, expected result and evidence.
---
# Test script writer

Case: OmniEsports Holdings Inc. (Communication Services). Sector populations include: professional players and team staff; content creators and streamers; live-event production crews; broadcast and streaming engineers; tournament operations managers; sponsorship and partnerships managers.

## When to use
Use to write a numbered test script for a OmniEsports requirement with preconditions, steps, expected result and evidence.

## Steps
1. Pick the scenario type: Positive, Negative, Permission, Integration failure, Reconciliation.
2. Write preconditions with synthetic test data.
3. Write numbered steps and the expected result.
4. State the evidence to keep and the test cycle (Unit, Integration, UAT, Security).

## Output
Test script ready for the workbook sheet Test Scripts.

## Guardrails
- Use only the inputs supplied; mark anything else as Not provided.
- Do not decide on hiring, pay, employment records or access.
- Do not infer protected characteristics or use proxies.
- Everything is proposed and not tenant-tested.

## Human check
A named human reviews the result against the workbook before it is used.
