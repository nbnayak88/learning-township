# AI skill library for OmniGrid Utilities Ltd.

18 skills in Claude skill format (folder per skill with SKILL.md). Proposed baseline; fictional enterprise.

- ogu-demand-and-requisition-drafting-agent: Demand and requisition drafting agent (Agent skill)
- ogu-job-content-and-criteria-drafting-assistant: Job content and criteria drafting assistant (Agent skill)
- ogu-sourcing-and-matching-agent: Sourcing and matching agent (Agent skill)
- ogu-candidate-screening-summary-assistant: Candidate screening summary assistant (Agent skill)
- ogu-interview-scheduling-agent: Interview scheduling agent (Agent skill)
- ogu-candidate-q-a-assistant: Candidate Q&A assistant (Agent skill)
- ogu-interview-evidence-consistency-checker: Interview evidence consistency checker (Agent skill)
- ogu-offer-drafting-and-band-check-assistant: Offer drafting and band-check assistant (Agent skill)
- ogu-hire-handoff-reconciliation-agent: Hire handoff reconciliation agent (Agent skill)
- ogu-onboarding-readiness-tracking-agent: Onboarding readiness tracking agent (Agent skill)
- ogu-fairness-and-adverse-impact-monitoring-agent: Fairness and adverse-impact monitoring agent (Agent skill)
- ogu-recruiting-insight-narrative-agent: Recruiting insight narrative agent (Agent skill)
- ogu-requirement-writer: Requirement writer (Utility skill)
- ogu-user-story-writer: User story writer (Utility skill)
- ogu-test-script-writer: Test script writer (Utility skill)
- ogu-fit-gap-classifier: Fit-gap classifier (Utility skill)
- ogu-activate-deliverable-drafter: SAP Activate deliverable drafter (Utility skill)
- ogu-talent-architecture-mapper: Talent architecture mapper (Utility skill)
