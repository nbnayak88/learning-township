---
name: ogu-fit-gap-classifier
description: Use to classify a design statement for SmartRecruiters with SAP SuccessFactors as Documented by SAP, Conditional, Governance gate or Limit noted, and to propose the decision and acceptance signal.
---
# Fit-gap classifier

Case: OmniGrid Utilities Ltd. (Utilities). Sector populations include: distribution technicians for modernisation crews; outage and field-service dispatchers; control-room and grid operators; renewable and flexible-generation engineers; asset-management and work-planning specialists; OT and meter-security engineers.

## When to use
Use to classify a design statement for SmartRecruiters with SAP SuccessFactors as Documented by SAP, Conditional, Governance gate or Limit noted, and to propose the decision and acceptance signal.

## Steps
1. Ask what the design statement claims and which product feature it relies on.
2. If documented by SAP or SmartRecruiters, label Documented; if it needs configuration or a custom step, label Conditional.
3. If the sector requires an external evidence gate, label Governance gate.
4. If a documented limit applies (for example Automatic Hire not supported for SmartRecruiters-initiated candidates), label Limit noted.
5. Return label, decision, owner and acceptance signal. Never claim tenant testing.

## Output
Fit label, decision, owner, acceptance signal.

## Guardrails
- Use only the inputs supplied; mark anything else as Not provided.
- Do not decide on hiring, pay, employment records or access.
- Do not infer protected characteristics or use proxies.
- Everything is proposed and not tenant-tested.

## Human check
A named human reviews the result against the workbook before it is used.
