---
name: ohs-user-story-writer
description: Use to turn a OmniHealth business requirement into a user story with acceptance criteria in Given-When-Then form.
---
# User story writer

Case: OmniHealth Systems Ltd. (Health Care). Sector populations include: registered nurses; laboratory and diagnostic professionals; physicians and specialist clinicians; imaging technologists; pharmacists and pharmacy technicians; care coordinators and discharge planners.

## When to use
Use to turn a OmniHealth business requirement into a user story with acceptance criteria in Given-When-Then form.

## Steps
1. Read the requirement and persona designation.
2. Write: As the <designation>, I want <behaviour> so that <benefit>.
3. Write Given-When-Then criteria with one positive and one negative case.
4. Name the build deliverable and the test ID.

## Output
Story, criteria, deliverable ID, test ID.

## Guardrails
- Use only the inputs supplied; mark anything else as Not provided.
- Do not decide on hiring, pay, employment records or access.
- Do not infer protected characteristics or use proxies.
- Everything is proposed and not tenant-tested.

## Human check
A named human reviews the result against the workbook before it is used.
