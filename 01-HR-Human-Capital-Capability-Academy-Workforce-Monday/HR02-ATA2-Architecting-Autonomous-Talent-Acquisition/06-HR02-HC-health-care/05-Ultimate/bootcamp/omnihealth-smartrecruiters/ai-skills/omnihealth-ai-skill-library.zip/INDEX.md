# AI skill library for OmniHealth Systems Ltd.

18 skills in Claude skill format (folder per skill with SKILL.md). Proposed baseline; fictional enterprise.

- ohs-demand-and-requisition-drafting-agent: Demand and requisition drafting agent (Agent skill)
- ohs-job-content-and-criteria-drafting-assistant: Job content and criteria drafting assistant (Agent skill)
- ohs-sourcing-and-matching-agent: Sourcing and matching agent (Agent skill)
- ohs-candidate-screening-summary-assistant: Candidate screening summary assistant (Agent skill)
- ohs-interview-scheduling-agent: Interview scheduling agent (Agent skill)
- ohs-candidate-q-a-assistant: Candidate Q&A assistant (Agent skill)
- ohs-interview-evidence-consistency-checker: Interview evidence consistency checker (Agent skill)
- ohs-offer-drafting-and-band-check-assistant: Offer drafting and band-check assistant (Agent skill)
- ohs-hire-handoff-reconciliation-agent: Hire handoff reconciliation agent (Agent skill)
- ohs-onboarding-readiness-tracking-agent: Onboarding readiness tracking agent (Agent skill)
- ohs-fairness-and-adverse-impact-monitoring-agent: Fairness and adverse-impact monitoring agent (Agent skill)
- ohs-recruiting-insight-narrative-agent: Recruiting insight narrative agent (Agent skill)
- ohs-requirement-writer: Requirement writer (Utility skill)
- ohs-user-story-writer: User story writer (Utility skill)
- ohs-test-script-writer: Test script writer (Utility skill)
- ohs-fit-gap-classifier: Fit-gap classifier (Utility skill)
- ohs-activate-deliverable-drafter: SAP Activate deliverable drafter (Utility skill)
- ohs-talent-architecture-mapper: Talent architecture mapper (Utility skill)
