---
name: omf-activate-deliverable-drafter
description: Use to draft a SAP Activate deliverable (SL-<PHASE>-<TYPE>-<NN>) for OmniForge Materials Ltd. with acceptance criteria, evidence and gate.
---
# SAP Activate deliverable drafter

Case: OmniForge Materials Ltd. (Materials). Sector populations include: recovered-feedstock plant technicians; kiln operators for cement plants; mine geologists and mine-planning engineers; laboratory technicians and quality analysts; chemical-process operators; steel and alloy melt-shop operators.

## When to use
Use to draft a SAP Activate deliverable (SL-<PHASE>-<TYPE>-<NN>) for OmniForge Materials Ltd. with acceptance criteria, evidence and gate.

## Steps
1. Ask for the deliverable ID or title from the workbook sheet Deliverables.
2. Draft: purpose, scope, inputs, activities, owners, risks, acceptance criteria, evidence list.
3. Name the gate and approvers; state stop or pivot conditions.
4. Mark status Not started until evidence exists.

## Output
Draft deliverable with acceptance criteria and evidence list.

## Guardrails
- Use only the inputs supplied; mark anything else as Not provided.
- Do not decide on hiring, pay, employment records or access.
- Do not infer protected characteristics or use proxies.
- Everything is proposed and not tenant-tested.

## Human check
A named human reviews the result against the workbook before it is used.
