# AI skill library for OmniForge Materials Ltd.

18 skills in Claude skill format (folder per skill with SKILL.md). Proposed baseline; fictional enterprise.

- omf-demand-and-requisition-drafting-agent: Demand and requisition drafting agent (Agent skill)
- omf-job-content-and-criteria-drafting-assistant: Job content and criteria drafting assistant (Agent skill)
- omf-sourcing-and-matching-agent: Sourcing and matching agent (Agent skill)
- omf-candidate-screening-summary-assistant: Candidate screening summary assistant (Agent skill)
- omf-interview-scheduling-agent: Interview scheduling agent (Agent skill)
- omf-candidate-q-a-assistant: Candidate Q&A assistant (Agent skill)
- omf-interview-evidence-consistency-checker: Interview evidence consistency checker (Agent skill)
- omf-offer-drafting-and-band-check-assistant: Offer drafting and band-check assistant (Agent skill)
- omf-hire-handoff-reconciliation-agent: Hire handoff reconciliation agent (Agent skill)
- omf-onboarding-readiness-tracking-agent: Onboarding readiness tracking agent (Agent skill)
- omf-fairness-and-adverse-impact-monitoring-agent: Fairness and adverse-impact monitoring agent (Agent skill)
- omf-recruiting-insight-narrative-agent: Recruiting insight narrative agent (Agent skill)
- omf-requirement-writer: Requirement writer (Utility skill)
- omf-user-story-writer: User story writer (Utility skill)
- omf-test-script-writer: Test script writer (Utility skill)
- omf-fit-gap-classifier: Fit-gap classifier (Utility skill)
- omf-activate-deliverable-drafter: SAP Activate deliverable drafter (Utility skill)
- omf-talent-architecture-mapper: Talent architecture mapper (Utility skill)
