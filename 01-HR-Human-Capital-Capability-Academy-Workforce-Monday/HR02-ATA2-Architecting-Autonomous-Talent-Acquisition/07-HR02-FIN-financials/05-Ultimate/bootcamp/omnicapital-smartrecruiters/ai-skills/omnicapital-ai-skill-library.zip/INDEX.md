# AI skill library for OmniCapital Financial Group Ltd.

18 skills in Claude skill format (folder per skill with SKILL.md). Proposed baseline; fictional enterprise.

- ocf-demand-and-requisition-drafting-agent: Demand and requisition drafting agent (Agent skill)
- ocf-job-content-and-criteria-drafting-assistant: Job content and criteria drafting assistant (Agent skill)
- ocf-sourcing-and-matching-agent: Sourcing and matching agent (Agent skill)
- ocf-candidate-screening-summary-assistant: Candidate screening summary assistant (Agent skill)
- ocf-interview-scheduling-agent: Interview scheduling agent (Agent skill)
- ocf-candidate-q-a-assistant: Candidate Q&A assistant (Agent skill)
- ocf-interview-evidence-consistency-checker: Interview evidence consistency checker (Agent skill)
- ocf-offer-drafting-and-band-check-assistant: Offer drafting and band-check assistant (Agent skill)
- ocf-hire-handoff-reconciliation-agent: Hire handoff reconciliation agent (Agent skill)
- ocf-onboarding-readiness-tracking-agent: Onboarding readiness tracking agent (Agent skill)
- ocf-fairness-and-adverse-impact-monitoring-agent: Fairness and adverse-impact monitoring agent (Agent skill)
- ocf-recruiting-insight-narrative-agent: Recruiting insight narrative agent (Agent skill)
- ocf-requirement-writer: Requirement writer (Utility skill)
- ocf-user-story-writer: User story writer (Utility skill)
- ocf-test-script-writer: Test script writer (Utility skill)
- ocf-fit-gap-classifier: Fit-gap classifier (Utility skill)
- ocf-activate-deliverable-drafter: SAP Activate deliverable drafter (Utility skill)
- ocf-talent-architecture-mapper: Talent architecture mapper (Utility skill)
