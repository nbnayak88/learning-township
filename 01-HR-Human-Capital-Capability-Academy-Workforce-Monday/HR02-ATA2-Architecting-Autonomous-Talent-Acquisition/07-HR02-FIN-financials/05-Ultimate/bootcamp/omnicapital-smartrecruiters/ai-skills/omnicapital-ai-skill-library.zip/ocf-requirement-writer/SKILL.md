---
name: ocf-requirement-writer
description: Use to write or review a business requirement for OmniCapital Financial Group Ltd. so it names one persona, one stage, one testable behaviour, a priority and a verification method.
---
# Requirement writer

Case: OmniCapital Financial Group Ltd. (Financials). Sector populations include: financial-crime investigators; retail-banking advisers; wealth and investment advisers; insurance underwriters and claims handlers; payments and treasury operations analysts; model-risk and responsible-AI reviewers.

## When to use
Use to write or review a business requirement for OmniCapital Financial Group Ltd. so it names one persona, one stage, one testable behaviour, a priority and a verification method.

## Steps
1. Ask for persona ID, stage (DEM, REQ, SRC, APP, ASM, OFR, HND, ONB, GOV, MEA) and population.
2. Write one sentence with one testable behaviour; split anything with two.
3. Add priority (Must, Should, Could) and verification (Inspection, Demonstration, Test, Walkthrough, Analysis).
4. Check it against existing requirement IDs for duplicates.
5. Return the requirement and the user story and test it should link to.

## Output
Requirement text, priority, verification, duplicate check result.

## Guardrails
- Use only the inputs supplied; mark anything else as Not provided.
- Do not decide on hiring, pay, employment records or access.
- Do not infer protected characteristics or use proxies.
- Everything is proposed and not tenant-tested.

## Human check
A named human reviews the result against the workbook before it is used.
