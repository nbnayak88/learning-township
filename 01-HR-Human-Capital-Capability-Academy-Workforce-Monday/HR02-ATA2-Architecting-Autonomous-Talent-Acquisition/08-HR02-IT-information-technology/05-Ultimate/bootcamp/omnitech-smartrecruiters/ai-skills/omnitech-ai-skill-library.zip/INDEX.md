# AI skill library for OmniTech Solutions Ltd.

18 skills in Claude skill format (folder per skill with SKILL.md). Proposed baseline; fictional enterprise.

- ots-demand-and-requisition-drafting-agent: Demand and requisition drafting agent (Agent skill)
- ots-job-content-and-criteria-drafting-assistant: Job content and criteria drafting assistant (Agent skill)
- ots-sourcing-and-matching-agent: Sourcing and matching agent (Agent skill)
- ots-candidate-screening-summary-assistant: Candidate screening summary assistant (Agent skill)
- ots-interview-scheduling-agent: Interview scheduling agent (Agent skill)
- ots-candidate-q-a-assistant: Candidate Q&A assistant (Agent skill)
- ots-interview-evidence-consistency-checker: Interview evidence consistency checker (Agent skill)
- ots-offer-drafting-and-band-check-assistant: Offer drafting and band-check assistant (Agent skill)
- ots-hire-handoff-reconciliation-agent: Hire handoff reconciliation agent (Agent skill)
- ots-onboarding-readiness-tracking-agent: Onboarding readiness tracking agent (Agent skill)
- ots-fairness-and-adverse-impact-monitoring-agent: Fairness and adverse-impact monitoring agent (Agent skill)
- ots-recruiting-insight-narrative-agent: Recruiting insight narrative agent (Agent skill)
- ots-requirement-writer: Requirement writer (Utility skill)
- ots-user-story-writer: User story writer (Utility skill)
- ots-test-script-writer: Test script writer (Utility skill)
- ots-fit-gap-classifier: Fit-gap classifier (Utility skill)
- ots-activate-deliverable-drafter: SAP Activate deliverable drafter (Utility skill)
- ots-talent-architecture-mapper: Talent architecture mapper (Utility skill)
