---
name: ow-test-script-writer
description: Use to write a numbered test script for a OmniWorks requirement with preconditions, steps, expected result and evidence.
---
# Test script writer

Case: OmniWorks Industrial Systems Ltd. (Industrials). Sector populations include: field-service technicians; industrial-automation engineers; aerospace assembly technicians; defence-programme engineers; rail and transport-mobility engineers; infrastructure project engineers.

## When to use
Use to write a numbered test script for a OmniWorks requirement with preconditions, steps, expected result and evidence.

## Steps
1. Pick the scenario type: Positive, Negative, Permission, Integration failure, Reconciliation.
2. Write preconditions with synthetic test data.
3. Write numbered steps and the expected result.
4. State the evidence to keep and the test cycle (Unit, Integration, UAT, Security).

## Output
Test script ready for the workbook sheet Test Scripts.

## Guardrails
- Use only the inputs supplied; mark anything else as Not provided.
- Do not decide on hiring, pay, employment records or access.
- Do not infer protected characteristics or use proxies.
- Everything is proposed and not tenant-tested.

## Human check
A named human reviews the result against the workbook before it is used.
