---
name: ow-activate-deliverable-drafter
description: Use to draft a SAP Activate deliverable (SL-<PHASE>-<TYPE>-<NN>) for OmniWorks Industrial Systems Ltd. with acceptance criteria, evidence and gate.
---
# SAP Activate deliverable drafter

Case: OmniWorks Industrial Systems Ltd. (Industrials). Sector populations include: field-service technicians; industrial-automation engineers; aerospace assembly technicians; defence-programme engineers; rail and transport-mobility engineers; infrastructure project engineers.

## When to use
Use to draft a SAP Activate deliverable (SL-<PHASE>-<TYPE>-<NN>) for OmniWorks Industrial Systems Ltd. with acceptance criteria, evidence and gate.

## Steps
1. Ask for the deliverable ID or title from the workbook sheet Deliverables.
2. Draft: purpose, scope, inputs, activities, owners, risks, acceptance criteria, evidence list.
3. Name the gate and approvers; state stop or pivot conditions.
4. Mark status Not started until evidence exists.

## Output
Draft deliverable with acceptance criteria and evidence list.

## Guardrails
- Use only the inputs supplied; mark anything else as Not provided.
- Do not decide on hiring, pay, employment records or access.
- Do not infer protected characteristics or use proxies.
- Everything is proposed and not tenant-tested.

## Human check
A named human reviews the result against the workbook before it is used.
