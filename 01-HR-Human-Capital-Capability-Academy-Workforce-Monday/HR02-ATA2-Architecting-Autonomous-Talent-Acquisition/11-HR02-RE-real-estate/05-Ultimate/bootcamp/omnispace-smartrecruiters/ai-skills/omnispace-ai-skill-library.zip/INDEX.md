# AI skill library for OmniSpace Real Estate Ltd.

18 skills in Claude skill format (folder per skill with SKILL.md). Proposed baseline; fictional enterprise.

- osp-demand-and-requisition-drafting-agent: Demand and requisition drafting agent (Agent skill)
- osp-job-content-and-criteria-drafting-assistant: Job content and criteria drafting assistant (Agent skill)
- osp-sourcing-and-matching-agent: Sourcing and matching agent (Agent skill)
- osp-candidate-screening-summary-assistant: Candidate screening summary assistant (Agent skill)
- osp-interview-scheduling-agent: Interview scheduling agent (Agent skill)
- osp-candidate-q-a-assistant: Candidate Q&A assistant (Agent skill)
- osp-interview-evidence-consistency-checker: Interview evidence consistency checker (Agent skill)
- osp-offer-drafting-and-band-check-assistant: Offer drafting and band-check assistant (Agent skill)
- osp-hire-handoff-reconciliation-agent: Hire handoff reconciliation agent (Agent skill)
- osp-onboarding-readiness-tracking-agent: Onboarding readiness tracking agent (Agent skill)
- osp-fairness-and-adverse-impact-monitoring-agent: Fairness and adverse-impact monitoring agent (Agent skill)
- osp-recruiting-insight-narrative-agent: Recruiting insight narrative agent (Agent skill)
- osp-requirement-writer: Requirement writer (Utility skill)
- osp-user-story-writer: User story writer (Utility skill)
- osp-test-script-writer: Test script writer (Utility skill)
- osp-fit-gap-classifier: Fit-gap classifier (Utility skill)
- osp-activate-deliverable-drafter: SAP Activate deliverable drafter (Utility skill)
- osp-talent-architecture-mapper: Talent architecture mapper (Utility skill)
